// Local preview config for the indicators-consolidation worktree.
//
// The worktree shares `node_modules` with the main clone by junction, so it also
// shares `node_modules/.vite` — and two dev servers re-optimising into one cache
// thrash each other. This gives this server its own cache dir and its own port,
// and changes nothing else about the build.
//
// ⚠️ NOT COMMITTED WITH THE FEATURE. It exists to run the preview.
import base from './vite.config.js'

export default {
  ...base,
  cacheDir: '.vite-base',
  server: {
    ...(base.server || {}),
    port: 5191,
    strictPort: true,
  },
}
