// app/src/components/chart/portalHost.js
//
// ⚠️ BUILD-UNBLOCK STUB (added by the Tracings work 2026-08-28). A separate,
// in-progress session left `PopoutWindow.jsx` importing `PortalHostContext` from
// this module without creating the file, which broke `vite build` for the whole
// app. This provides exactly the export that consumer needs so the tree builds.
//
// Contract (from the only current usage, PopoutWindow.jsx):
//   <PortalHostContext.Provider value={container.ownerDocument.body}> … </Provider>
// The value is the DOM node that portaled menus/dropdowns inside a popped-out
// window should mount into (that window's own <body>), so a floating menu opens in
// THIS window rather than the opener. No consumer reads it yet; the default is null
// and callers should fall back to document.body when the context is unset.
//
// The other session can extend this module (e.g. add a usePortalHost() helper and
// wire consumers) — this stub only unblocks the build.
import { createContext } from 'react'

export const PortalHostContext = createContext(null)
