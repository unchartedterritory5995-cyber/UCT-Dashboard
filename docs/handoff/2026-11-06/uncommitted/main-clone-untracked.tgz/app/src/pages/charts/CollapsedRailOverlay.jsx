// Thin "minimized panel" rails for merged mode. When a pane is collapsed
// (mergedCollapse.collapseWidget) it leaves the tiling and its neighbour grows to
// fill; the workspace insets that neighbour's content by RAIL_PX so nothing renders
// under the rail. This overlay draws the reserved strip — a gold accent on the edge
// facing the board plus a flat chevron tab, ThinkorSwim-style. Click to restore the
// pane to its exact prior size.
//
// Positioned in the same pixel space as MergedSeamOverlay (grid margin 0, so a
// widget box is {x·colWidth, y·rowHeight, w·colWidth, h·rowHeight}).

import UIcon from '../../components/ui/UIcon'
import { RAIL_PX } from './mergedCollapse'
import styles from './ChartsWorkspace.module.css'

// Expand chevron points AWAY from the pinned edge (into the board it will reopen).
const EXPAND_CHEVRON = {
  left: { name: 'chevronRight', rot: 0 },
  right: { name: 'chevronRight', rot: 180 },
  top: { name: 'chevronDown', rot: 0 },
  bottom: { name: 'chevronUp', rot: 0 },
}
const EDGE_CLASS = {
  left: 'collapsedRailLeft', right: 'collapsedRailRight',
  top: 'collapsedRailTop', bottom: 'collapsedRailBottom',
}

export default function CollapsedRailOverlay({ widgets, colWidth, rowHeight, labelFor, onExpand }) {
  if (!colWidth || !rowHeight) return null
  const rails = widgets.filter(w => w.collapsed)
  if (!rails.length) return null

  return (
    <div className={styles.railOverlay}>
      {rails.map(w => {
        const edge = w.collapseEdge
        const vertical = edge === 'left' || edge === 'right'
        const boxLeft = w.x * colWidth
        const boxTop = w.y * rowHeight
        const boxW = w.w * colWidth
        const boxH = w.h * rowHeight
        const style = vertical
          ? {
            left: edge === 'left' ? boxLeft : boxLeft + boxW - RAIL_PX,
            top: boxTop, width: RAIL_PX, height: boxH,
          }
          : {
            left: boxLeft, top: edge === 'top' ? boxTop : boxTop + boxH - RAIL_PX,
            width: boxW, height: RAIL_PX,
          }
        const chev = EXPAND_CHEVRON[edge]
        const label = labelFor ? labelFor(w) : 'panel'
        return (
          <button
            key={w.id}
            type="button"
            className={`${styles.collapsedRail} ${vertical ? styles.collapsedRailV : styles.collapsedRailH} ${styles[EDGE_CLASS[edge]]}`}
            style={style}
            title={`Restore ${label}`}
            aria-label={`Restore ${label} panel`}
            onClick={(e) => { e.preventDefault(); e.stopPropagation(); onExpand(w.id) }}
          >
            <span className={styles.collapsedRailTab}>
              <UIcon name={chev.name} size={11} gold={false}
                style={chev.rot ? { transform: `rotate(${chev.rot}deg)` } : undefined} />
            </span>
          </button>
        )
      })}
    </div>
  )
}
