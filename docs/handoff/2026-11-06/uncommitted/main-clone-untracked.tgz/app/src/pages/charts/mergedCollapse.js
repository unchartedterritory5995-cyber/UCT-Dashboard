// Pure geometry for merged-mode "minimize a pane" — the ThinkorSwim divider
// collapse button. Companion to mergedSeams.js (which owns the drag-to-resize).
//
// A COLLAPSE hides one widget (a "pane") and lets its immediate neighbours grow
// to reclaim its exact box, leaving a thin rail pinned at the pane's outer edge.
// Clicking the rail's chevron restores the pane and shrinks the neighbours back.
//
// Integer + gapless by construction: we only offer a collapse when the widget's
// far-side neighbours NEST inside its row band (vertical seam) or column band
// (horizontal seam). Then each neighbour grows by exactly the pane's whole width
// / height into the strip the pane vacated — no fractional columns, no overlap,
// and expand is exact (we stash each grown neighbour's prior box on the pane).
//
// When a neighbour is ragged (taller/wider than the pane, so growing it would
// spill into a row/col the pane never owned), the pane is NOT collapsible and the
// chevron is withheld — a layout is never left gapped or overlapping.
//
// All functions here are pure (no React, no DOM).

// Rail thickness in px — the reserved strip a minimized pane leaves behind. Shared
// by CollapsedRailOverlay (the strip) and the workspace's neighbour inset (so the
// neighbour's content stops at the rail edge instead of rendering under it).
export const RAIL_PX = 22

const rightEdge = (w) => w.x + w.w
const bottomEdge = (w) => w.y + w.h
const rowsNestIn = (n, C) => n.y >= C.y && bottomEdge(n) <= bottomEdge(C)
const colsNestIn = (n, C) => n.x >= C.x && rightEdge(n) <= rightEdge(C)
const overlapRows = (a, C) => a.y < bottomEdge(C) && bottomEdge(a) > C.y
const overlapCols = (a, C) => a.x < rightEdge(C) && rightEdge(a) > C.x

// The widgets that would grow to fill C's box if C collapsed on `edge`.
// edge 'left'/'right' → a vertical (column) collapse; 'top'/'bottom' → horizontal.
function absorbers(C, widgets, edge) {
  const others = widgets.filter(w => w.id !== C.id && !w.collapsed)
  if (edge === 'left') {
    // C sits on the left of a vertical seam; neighbours start at C's right edge.
    return others.filter(w => w.x === rightEdge(C) && overlapRows(w, C))
  }
  if (edge === 'right') {
    // C sits on the right; neighbours end at C's left edge.
    return others.filter(w => rightEdge(w) === C.x && overlapRows(w, C))
  }
  if (edge === 'top') {
    return others.filter(w => w.y === bottomEdge(C) && overlapCols(w, C))
  }
  // bottom
  return others.filter(w => bottomEdge(w) === C.y && overlapCols(w, C))
}

// Can widget C collapse on `edge` cleanly? (≥1 neighbour, all nesting inside C.)
export function canCollapse(C, widgets, edge) {
  if (!C || C.collapsed) return false
  const abs = absorbers(C, widgets, edge)
  if (!abs.length) return false
  const nest = (edge === 'left' || edge === 'right') ? rowsNestIn : colsNestIn
  return abs.every(n => nest(n, C))
}

// Given one seam (from mergedSeams.computeSeams) + its type ('v'|'h'), return the
// pane the seam's chevron should collapse: the NARROWEST collapsible widget
// adjacent to the seam, or null if none qualifies. Ties break to the near side
// (left/top). `edge` is where the rail pins.
export function seamCollapseTarget(seam, type, widgets) {
  const byId = (id) => widgets.find(w => w.id === id)
  const cands = []
  const consider = (ids, edge) => {
    for (const id of ids || []) {
      const C = byId(id)
      if (C && canCollapse(C, widgets, edge)) {
        cands.push({ id, edge, size: type === 'v' ? C.w : C.h })
      }
    }
  }
  if (type === 'v') {
    consider(seam.leftIds, 'left')
    consider(seam.rightIds, 'right')
  } else {
    consider(seam.topIds, 'top')
    consider(seam.bottomIds, 'bottom')
  }
  if (!cands.length) return null
  // Narrowest wins; on a tie prefer the near side (left/top) for a stable choice.
  cands.sort((a, b) => a.size - b.size || nearBias(a.edge) - nearBias(b.edge))
  return cands[0]
}

const nearBias = (edge) => (edge === 'left' || edge === 'top') ? 0 : 1

// Collapse widget `id` on `edge`. Returns a NEW widgets array: the pane keeps its
// box but gains { collapsed, collapseEdge, collapseRestore }, and each absorbing
// neighbour grows to swallow the pane's strip. No-op (returns input) if the
// collapse isn't clean.
export function collapseWidget(widgets, id, edge) {
  const C = widgets.find(w => w.id === id)
  if (!canCollapse(C, widgets, edge)) return widgets
  const abs = absorbers(C, widgets, edge)
  const absIds = new Set(abs.map(a => a.id))
  const restore = abs.map(a => ({ id: a.id, x: a.x, y: a.y, w: a.w, h: a.h }))
  return widgets.map(w => {
    if (w.id === id) {
      return { ...w, collapsed: true, collapseEdge: edge, collapseRestore: restore }
    }
    if (!absIds.has(w.id)) return w
    // Grow the neighbour into C's vacated strip.
    if (edge === 'left') return { ...w, x: C.x, w: w.w + C.w }          // extend left
    if (edge === 'right') return { ...w, w: w.w + C.w }                 // extend right
    if (edge === 'top') return { ...w, y: C.y, h: w.h + C.h }           // extend up
    return { ...w, h: w.h + C.h }                                       // extend down
  })
}

// Restore a collapsed pane: undo the neighbour growth from its stashed boxes and
// clear the collapse fields. Neighbours that no longer exist are skipped (the
// pane still reappears at its preserved box).
export function expandWidget(widgets, id) {
  const C = widgets.find(w => w.id === id)
  if (!C || !C.collapsed) return widgets
  const restoreById = new Map((C.collapseRestore || []).map(r => [r.id, r]))
  return widgets.map(w => {
    if (w.id === id) {
      // eslint-disable-next-line no-unused-vars
      const { collapsed, collapseEdge, collapseRestore, ...rest } = w
      return rest
    }
    const r = restoreById.get(w.id)
    return r ? { ...w, x: r.x, y: r.y, w: r.w, h: r.h } : w
  })
}

// Restore every collapsed pane (used when leaving merged mode). Order-independent
// enough for practical layouts; each expand only touches its own stashed boxes.
export function expandAll(widgets) {
  let out = widgets
  for (const w of widgets) {
    if (w.collapsed) out = expandWidget(out, w.id)
  }
  return out
}

// The rail rectangle (grid units) for a collapsed pane, given the thin rail size
// expressed in grid units on its pinned edge. The overlay converts to pixels.
export function railRect(C, railCols, railRows) {
  const edge = C.collapseEdge
  if (edge === 'left') return { x: C.x, y: C.y, w: railCols, h: C.h }
  if (edge === 'right') return { x: rightEdge(C) - railCols, y: C.y, w: railCols, h: C.h }
  if (edge === 'top') return { x: C.x, y: C.y, w: C.w, h: railRows }
  return { x: C.x, y: bottomEdge(C) - railRows, w: C.w, h: railRows }   // bottom
}
