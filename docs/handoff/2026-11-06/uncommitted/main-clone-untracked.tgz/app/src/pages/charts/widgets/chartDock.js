/**
 * Pure helpers + constants for the Chart Detail Dock (Profile / News /
 * Fundamentals inline panels). Kept out of ChartDetailDock.jsx so that file only
 * exports React components (react-refresh / fast-refresh requirement).
 */

// Which glyph fronts each panel (validated against the UIcon registry) + which
// dock it lives in.
export const DOCK_PANELS = [
  { key: 'profile', label: 'Stock Profile', icon: 'info', side: 'right' },
  { key: 'news', label: 'News & Catalysts', icon: 'bolt', side: 'right' },
  { key: 'fundamentals', label: 'Fundamentals', icon: 'scale', side: 'bottom' },
]

export const DEFAULT_RIGHT_W = 330
export const DEFAULT_BOTTOM_H = 116     // thin by default (Quarterly/Annual strip)
export const TALL_BOTTOM_H = 300        // Analyst / Ownership need room
export const MIN_RIGHT_W = 260
export const MIN_BOTTOM_H = 96

// Coerce whatever is in opts.dock into a known shape (older layouts have none).
export function normalizeDock(raw) {
  const d = raw && typeof raw === 'object' ? raw : {}
  const right = d.right === 'profile' || d.right === 'news' ? d.right : null
  const fundView = ['quarterly', 'annual', 'analyst', 'ownership'].includes(d.fundView) ? d.fundView : 'quarterly'
  const newsFilter = ['all', 'up', 'down'].includes(d.newsFilter) ? d.newsFilter : 'all'
  return {
    right,                                   // 'profile' | 'news' | null (which right panel)
    bottom: !!d.bottom,                      // fundamentals open?
    rightW: Number.isFinite(d.rightW) ? d.rightW : DEFAULT_RIGHT_W,
    bottomH: Number.isFinite(d.bottomH) ? d.bottomH : DEFAULT_BOTTOM_H,
    fundView,                                // which fundamentals tab
    newsFilter,                              // news up/down filter
  }
}

export function dockIsOpen(dock, key) {
  if (key === 'fundamentals') return !!dock.bottom
  return dock.right === key
}

// Pure toggler shared by the TF-bar popover and the in-dock switch.
export function toggleDockPanel(dock, key) {
  if (key === 'fundamentals') return { ...dock, bottom: !dock.bottom }
  // Profile/News share the right dock: clicking the open one closes it, the other switches.
  return { ...dock, right: dock.right === key ? null : key }
}

// The Fundamentals dock is thin for Quarterly/Annual and taller for the denser
// Analyst/Ownership panels — auto-fit the height as the tab changes, but never
// fight a size the user has deliberately dragged past the target band.
export function fundViewHeight(prevView, nextView, currentH) {
  const wasTall = prevView === 'analyst' || prevView === 'ownership'
  const willTall = nextView === 'analyst' || nextView === 'ownership'
  if (willTall && !wasTall && currentH < TALL_BOTTOM_H) return TALL_BOTTOM_H
  if (!willTall && wasTall && currentH > DEFAULT_BOTTOM_H + 60) return DEFAULT_BOTTOM_H
  return currentH
}
