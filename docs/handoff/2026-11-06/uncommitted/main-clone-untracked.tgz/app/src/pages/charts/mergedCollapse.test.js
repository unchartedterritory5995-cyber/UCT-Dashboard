import { describe, it, expect } from 'vitest'
import { computeSeams } from './mergedSeams'
import {
  canCollapse, seamCollapseTarget, collapseWidget, expandWidget, expandAll, railRect,
} from './mergedCollapse'

// A clean two-pane board: narrow left pane + wide right pane, both full height.
const twoPane = () => ([
  { id: 'L', type: 'themes', x: 0, y: 0, w: 4, h: 20 },
  { id: 'R', type: 'chart', x: 4, y: 0, w: 20, h: 20 },
])

describe('canCollapse', () => {
  it('a full-height pane whose neighbour spans the same rows is collapsible', () => {
    const ws = twoPane()
    expect(canCollapse(ws[0], ws, 'left')).toBe(true)   // collapse L, R grows left
    expect(canCollapse(ws[1], ws, 'right')).toBe(true)  // collapse R, L grows right
  })

  it('is false when the neighbour is ragged (taller than the pane)', () => {
    // L only spans the top half; R is full height, so growing R left would spill
    // into rows L never owned → not clean.
    const ws = [
      { id: 'L', x: 0, y: 0, w: 4, h: 10 },
      { id: 'R', x: 4, y: 0, w: 20, h: 20 },
      { id: 'B', x: 0, y: 10, w: 4, h: 10 },
    ]
    expect(canCollapse(ws[0], ws, 'left')).toBe(false)
  })

  it('is true for a nested split (two stacked neighbours that tile the pane rows)', () => {
    // L full height on the left; the right side is two stacked panes that together
    // cover exactly L's rows → both nest inside L, so L is collapsible.
    const ws = [
      { id: 'L', x: 0, y: 0, w: 4, h: 20 },
      { id: 'R1', x: 4, y: 0, w: 20, h: 8 },
      { id: 'R2', x: 4, y: 8, w: 20, h: 12 },
    ]
    expect(canCollapse(ws[0], ws, 'left')).toBe(true)
  })

  it('is false with no neighbour on that edge', () => {
    const ws = twoPane()
    expect(canCollapse(ws[1], ws, 'left')).toBe(false)  // nothing to R's right
  })
})

describe('seamCollapseTarget picks the narrower pane', () => {
  it('targets the narrow left pane on the shared seam', () => {
    const ws = twoPane()
    const { vertical } = computeSeams(ws, 24, 20)
    expect(vertical).toHaveLength(1)
    const t = seamCollapseTarget(vertical[0], 'v', ws)
    expect(t).toEqual({ id: 'L', edge: 'left', size: 4 })
  })

  it('when both sides qualify, the narrower one wins', () => {
    // Left 6-wide, right 18-wide → collapse the left.
    const ws = [
      { id: 'L', x: 0, y: 0, w: 6, h: 20 },
      { id: 'R', x: 6, y: 0, w: 18, h: 20 },
    ]
    const { vertical } = computeSeams(ws, 24, 20)
    const t = seamCollapseTarget(vertical[0], 'v', ws)
    expect(t.id).toBe('L')
  })
})

describe('collapseWidget / expandWidget round-trip', () => {
  it('collapsing L grows R to fill and marks L collapsed', () => {
    const ws = twoPane()
    const out = collapseWidget(ws, 'L', 'left')
    const L = out.find(w => w.id === 'L')
    const R = out.find(w => w.id === 'R')
    expect(L.collapsed).toBe(true)
    expect(L.collapseEdge).toBe('left')
    expect(L.x).toBe(0)              // pane box preserved
    expect(L.w).toBe(4)
    expect(R).toMatchObject({ x: 0, w: 24 })  // grew left to fill the whole board
  })

  it('expand exactly restores the original geometry', () => {
    const ws = twoPane()
    const collapsed = collapseWidget(ws, 'L', 'left')
    const restored = expandWidget(collapsed, 'L')
    // Same boxes, and no collapse residue.
    expect(restored.find(w => w.id === 'L')).toEqual(ws[0])
    expect(restored.find(w => w.id === 'R')).toEqual(ws[1])
    expect(restored.find(w => w.id === 'L').collapsed).toBeUndefined()
  })

  it('collapsing the right pane grows the left neighbour rightward', () => {
    const ws = twoPane()
    const out = collapseWidget(ws, 'R', 'right')
    expect(out.find(w => w.id === 'L')).toMatchObject({ x: 0, w: 24 })
    expect(out.find(w => w.id === 'R').collapsed).toBe(true)
  })

  it('horizontal collapse (top pane) grows the pane below upward', () => {
    const ws = [
      { id: 'T', x: 0, y: 0, w: 24, h: 6 },
      { id: 'B', x: 0, y: 6, w: 24, h: 14 },
    ]
    const out = collapseWidget(ws, 'T', 'top')
    expect(out.find(w => w.id === 'B')).toMatchObject({ y: 0, h: 20 })
    expect(expandWidget(out, 'T').find(w => w.id === 'B')).toMatchObject({ y: 6, h: 14 })
  })

  it('is a no-op when the collapse is not clean', () => {
    const ws = [
      { id: 'L', x: 0, y: 0, w: 4, h: 10 },
      { id: 'R', x: 4, y: 0, w: 20, h: 20 },
      { id: 'B', x: 0, y: 10, w: 4, h: 10 },
    ]
    expect(collapseWidget(ws, 'L', 'left')).toBe(ws)
  })

  it('nested split: collapsing L grows BOTH stacked neighbours, expand restores both', () => {
    const ws = [
      { id: 'L', x: 0, y: 0, w: 4, h: 20 },
      { id: 'R1', x: 4, y: 0, w: 20, h: 8 },
      { id: 'R2', x: 4, y: 8, w: 20, h: 12 },
    ]
    const out = collapseWidget(ws, 'L', 'left')
    expect(out.find(w => w.id === 'R1')).toMatchObject({ x: 0, w: 24 })
    expect(out.find(w => w.id === 'R2')).toMatchObject({ x: 0, w: 24 })
    const back = expandWidget(out, 'L')
    expect(back.find(w => w.id === 'R1')).toMatchObject({ x: 4, w: 20 })
    expect(back.find(w => w.id === 'R2')).toMatchObject({ x: 4, w: 20 })
  })
})

describe('expandAll restores every collapsed pane', () => {
  it('clears all collapse state', () => {
    let ws = twoPane()
    ws = collapseWidget(ws, 'L', 'left')
    ws = expandAll(ws)
    expect(ws.some(w => w.collapsed)).toBe(false)
    expect(ws.find(w => w.id === 'R')).toMatchObject({ x: 4, w: 20 })
  })
})

describe('railRect', () => {
  it('pins a thin strip at the collapsed edge', () => {
    const collapsed = collapseWidget(twoPane(), 'L', 'left').find(w => w.id === 'L')
    expect(railRect(collapsed, 0.3, 0.3)).toEqual({ x: 0, y: 0, w: 0.3, h: 20 })
  })
  it('pins to the far edge for a right collapse', () => {
    const ws = twoPane()
    const collapsed = collapseWidget(ws, 'R', 'right').find(w => w.id === 'R')
    // R box is x=4,w=20 → right edge 24; rail sits just inside it.
    expect(railRect(collapsed, 0.3, 0.3)).toEqual({ x: 23.7, y: 0, w: 0.3, h: 20 })
  })
})
