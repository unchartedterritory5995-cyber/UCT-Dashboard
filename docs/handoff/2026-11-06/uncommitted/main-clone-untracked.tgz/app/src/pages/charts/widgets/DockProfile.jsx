/**
 * DockProfile — the Stock Profile panel rebuilt for the RIGHT dock of a chart.
 * NOT the standalone widget: no logo, no ticker, no company name, no ⚙, no
 * Notebook door — the chart already names the stock. Redesigned for the narrow
 * dock: a hero stat band, the AI company story, a single aligned key-stat list
 * (fixes the mis-aligned 2-column grid), and clickable sympathy chips.
 *
 * Takes the chart's resolved `sym` directly, so it mirrors the chart exactly.
 * Earnings history is intentionally omitted here — the Fundamentals bottom dock
 * owns the quarter-by-quarter detail.
 */
import { useEffect, useMemo, useState } from 'react'
import useStockBrief from '../../../hooks/useStockBrief'
import useMobileSWR from '../../../hooks/useMobileSWR'
import {
  fmtAge, fmtEarnDate, fmtPct, fmtShares, fmtVol, websiteDomain,
} from '../../../utils/profileFormat'
import styles from './dockPanels.module.css'

const jsonFetcher = (url) => fetch(url).then(r => (r.ok ? r.json() : null))

export default function DockProfile({ sym, onPickSymbol }) {
  const [fastPoll, setFastPoll] = useState(false)
  const { status, stats, profile } = useStockBrief(sym || null, { generating: fastPoll })
  useEffect(() => { setFastPoll(status === 'generating') }, [status])

  const { data: fund } = useMobileSWR(
    sym ? `/api/fundamentals/${encodeURIComponent(sym)}` : null,
    jsonFetcher,
    { refreshInterval: 600000, dedupingInterval: 60000, revalidateOnFocus: false },
  )
  const { data: peersData } = useMobileSWR(
    sym ? `/api/groups/peers?sym=${encodeURIComponent(sym)}&n=10` : null,
    jsonFetcher,
    { refreshInterval: 0, dedupingInterval: 3600000, revalidateOnFocus: false },
  )
  const peers = useMemo(() => {
    const raw = Array.isArray(peersData?.peers) ? peersData.peers : []
    return raw.map(p => (typeof p === 'string' ? p : p?.sym)).filter(Boolean).filter(s => s !== sym).slice(0, 10)
  }, [peersData, sym])

  const stat = useMemo(() => ([
    { label: 'Market Cap', value: fund?.market_cap || '—' },
    { label: 'Next Earnings', value: fmtEarnDate(fund?.next_earnings) },
    { label: 'Float', value: fmtShares(fund?.float_shares) },
    { label: 'Short Interest', value: fund?.short_pct_float != null ? `${Number(fund.short_pct_float).toFixed(1)}%` : '—' },
    { label: 'Inst. Own', value: fund?.inst_own_pct != null ? `${Number(fund.inst_own_pct).toFixed(1)}%` : '—' },
    { label: 'Age', value: fmtAge(fund?.inception) },
    fund?.hq && { label: 'Headquarters', value: fund.hq },
    fund?.ceo && { label: 'CEO', value: fund.ceo },
    fund?.employees != null && { label: 'Employees', value: Number(fund.employees).toLocaleString() },
    fund?.website && {
      label: 'Website',
      value: <a className={styles.link} href={fund.website} target="_blank" rel="noreferrer">{websiteDomain(fund.website)}</a>,
    },
  ].filter(Boolean)), [fund])

  const year = new Date().getFullYear()
  const hasStats = !!stats && (stats.ytd_gain_pct != null || stats.avg_dollar_vol != null)
  const rangeUp = stats?.range_dir !== 'down'
  const dir = (d) => (d > 0 ? styles.pos : d < 0 ? styles.neg : styles.muted)

  if (!sym) return <div className={styles.emptyState}>No symbol.</div>

  return (
    <div className={styles.profile}>
      {/* hero stats */}
      <div className={styles.heroRow}>
        <div className={styles.hero}>
          <div className={styles.heroLabel}>{year} Gain</div>
          <div className={`${styles.heroVal} ${dir(stats?.ytd_gain_pct)}`}>{hasStats ? fmtPct(stats?.ytd_gain_pct) : '—'}</div>
        </div>
        <div className={styles.hero}>
          <div className={styles.heroLabel}>{rangeUp ? 'Low → High' : 'High → Low'}</div>
          <div className={`${styles.heroVal} ${rangeUp ? styles.pos : styles.neg}`}>{stats?.range_pct != null ? fmtPct(stats.range_pct) : '—'}</div>
        </div>
        <div className={styles.hero}>
          <div className={styles.heroLabel}>Avg Daily $ Vol</div>
          <div className={styles.heroVal}>{fmtVol(stats?.avg_dollar_vol)}</div>
        </div>
      </div>

      {/* AI company story */}
      {(profile?.company_desc || profile?.run_story) ? (
        <div className={styles.prose}>
          {profile.company_desc && <p className={styles.desc}>{profile.company_desc}</p>}
          {profile.run_story && <p className={styles.story}>{profile.run_story}</p>}
        </div>
      ) : status === 'generating' ? (
        <div className={styles.generating}><span className={styles.spinner} /> Writing company profile…</div>
      ) : null}

      {/* key stats — one aligned list */}
      <div className={styles.sectionLabel}>Key Stats</div>
      <div className={styles.stats}>
        {stat.map(it => (
          <div key={it.label} className={styles.statRow}>
            <span className={styles.statKey}>{it.label}</span>
            <span className={styles.statLeader} />
            <span className={styles.statVal}>{it.value}</span>
          </div>
        ))}
      </div>

      {/* sympathy stocks */}
      {peers.length > 0 && (
        <>
          <div className={styles.sectionLabel}>Sympathy Stocks</div>
          <div className={styles.chips}>
            {peers.map(t => (
              <button key={t} type="button" className={styles.chip} onClick={() => onPickSymbol?.(t)} title={`Show ${t}`}>{t}</button>
            ))}
          </div>
        </>
      )}
    </div>
  )
}
