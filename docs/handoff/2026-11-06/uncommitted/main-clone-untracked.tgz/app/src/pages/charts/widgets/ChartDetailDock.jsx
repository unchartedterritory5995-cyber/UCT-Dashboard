/**
 * ChartDetailDock — the three stock-specific widgets (Stock Profile, News &
 * Catalysts, Fundamentals) reborn as inline panels DOCKED into the Chart widget,
 * instead of standalone widgets that always had to be linked to a chart anyway.
 *
 *   • Profile / News share a RIGHT dock — the chart compresses left (the
 *     TradingView "stock info panel" pattern).
 *   • Fundamentals opens a thin BOTTOM dock — the time axis + volume shift up.
 *
 * The panels are PURPOSE-BUILT for the dock (DockProfile / DockNews /
 * DockFundamentals) — chrome-free (no logo, ticker, company name, gear, or
 * notebook door; the chart already names the stock) — and are fed the chart's
 * resolved `sym` directly, so they mirror the chart exactly.
 *
 * The chart (StockChart) uses lightweight-charts `autoSize`, so shrinking its flex
 * column reflows it automatically — no imperative resize. Open/closed state + dock
 * sizes + the fundamentals tab + news filter persist through the widget's
 * `opts.dock` blob (routed via the same onOptsChange pipe as opts.tf).
 */
import { useCallback, useRef, useState } from 'react'
import UIcon from '../../../components/ui/UIcon'
import DockProfile from './DockProfile'
import DockNews from './DockNews'
import DockFundamentals from './DockFundamentals'
import { DOCK_PANELS, MIN_RIGHT_W, MIN_BOTTOM_H, dockIsOpen, toggleDockPanel, fundViewHeight } from './chartDock'
import styles from './ChartDetailDock.module.css'

/* ── The TF-bar entry point: a "Panels" button + a small toggle popover. ──────
   Rendered inside ChartPane's tfBarRight slot; drives the dock that WRAPS the
   pane, so state is lifted to ChartWidget (dock / setDock) and passed to both. */
export function ChartPanelsButton({ dock, setDock, btnClassName }) {
  const [open, setOpen] = useState(false)
  const [pos, setPos] = useState(null)   // {top,right} in viewport px — the popover is
                                         // position:fixed so it escapes the chart canvas's
                                         // stacking context (an in-flow popover paints behind it).
  const btnRef = useRef(null)
  const anyOpen = !!dock.right || !!dock.bottom
  const toggle = useCallback(() => {
    setOpen(o => {
      const next = !o
      if (next) {
        const r = btnRef.current?.getBoundingClientRect()
        if (r) setPos({ top: Math.round(r.bottom + 6), right: Math.round(window.innerWidth - r.right) })
      }
      return next
    })
  }, [])
  return (
    <span className={styles.panelsWrap}>
      <button
        ref={btnRef}
        type="button"
        className={btnClassName}
        onClick={toggle}
        title="Info panels — Profile · News · Fundamentals"
        aria-label="Info panels"
        aria-expanded={open}
        style={anyOpen ? { color: 'var(--accent, #c9a84c)' } : undefined}
      >
        <UIcon name="columns" size={15} gold={false} />
      </button>
      {open && pos && (
        <>
          <div className={styles.panelsBackdrop} onClick={() => setOpen(false)} />
          <div className={styles.panelsPop} role="menu" style={{ top: pos.top, right: pos.right }}>
            <div className={styles.panelsHint}>Show in this chart</div>
            {DOCK_PANELS.map(p => {
              const on = dockIsOpen(dock, p.key)
              return (
                <button
                  key={p.key}
                  type="button"
                  role="menuitemcheckbox"
                  aria-checked={on}
                  className={`${styles.panelsRow}${on ? ' ' + styles.panelsRowActive : ''}`}
                  onClick={() => setDock(d => toggleDockPanel(d, p.key))}
                >
                  <span className={styles.panelsRowIcon}>
                    <UIcon name={p.icon} size={14} gold={on} />
                  </span>
                  <span className={styles.panelsRowLabel}>{p.label}</span>
                  {on && <span className={styles.panelsCheck}><UIcon name="check" size={13} /></span>}
                </button>
              )
            })}
          </div>
        </>
      )}
    </span>
  )
}

// One drag handle → live-resize a dock. Size is kept in local state during the
// drag (so the chart reflows smoothly) and committed to opts on release, rather
// than firing a persisted layout write on every pointer move.
function useDockResize(axis, current, commit, rootRef, min) {
  const [live, setLive] = useState(null)
  const startRef = useRef(null)
  const onDown = useCallback((e) => {
    e.preventDefault()
    const rect = rootRef.current?.getBoundingClientRect()
    startRef.current = {
      pos: axis === 'x' ? e.clientX : e.clientY,
      size: current,
      max: rect ? (axis === 'x' ? rect.width * 0.62 : rect.height * 0.6) : 9999,
    }
    setLive(current)
    const onMove = (ev) => {
      const s = startRef.current
      if (!s) return
      const delta = (axis === 'x' ? s.pos - ev.clientX : s.pos - ev.clientY)
      setLive(Math.max(min, Math.min(s.max, s.size + delta)))
    }
    const onUp = () => {
      window.removeEventListener('pointermove', onMove)
      window.removeEventListener('pointerup', onUp)
      startRef.current = null
      setLive(v => { if (v != null) commit(v); return null })
    }
    window.addEventListener('pointermove', onMove)
    window.addEventListener('pointerup', onUp)
  }, [axis, current, commit, rootRef, min])
  return { size: live == null ? current : live, onDown }
}

export default function ChartDetailDock({ sym, dock, setDock, onPickSymbol, children }) {
  const rootRef = useRef(null)

  const commitRightW = useCallback((w) => setDock(d => ({ ...d, rightW: Math.round(w) })), [setDock])
  const commitBottomH = useCallback((h) => setDock(d => ({ ...d, bottomH: Math.round(h) })), [setDock])
  const rightResize = useDockResize('x', dock.rightW, commitRightW, rootRef, MIN_RIGHT_W)
  const bottomResize = useDockResize('y', dock.bottomH, commitBottomH, rootRef, MIN_BOTTOM_H)

  const closeRight = useCallback(() => setDock(d => ({ ...d, right: null })), [setDock])
  const closeBottom = useCallback(() => setDock(d => ({ ...d, bottom: false })), [setDock])
  const switchRight = useCallback((key) => setDock(d => ({ ...d, right: key })), [setDock])
  const setNewsFilter = useCallback((f) => setDock(d => ({ ...d, newsFilter: f })), [setDock])
  const setFundView = useCallback((v) => setDock(d => ({ ...d, fundView: v, bottomH: fundViewHeight(d.fundView, v, d.bottomH) })), [setDock])

  const rightOpen = dock.right === 'profile' || dock.right === 'news'
  const bottomOpen = !!dock.bottom

  return (
    <div className={styles.dockRoot} ref={rootRef}>
      <div className={styles.dockUpper}>
        <div className={styles.dockChartCol}>{children}</div>

        {rightOpen && (
          <div className={styles.dockRight} style={{ width: rightResize.size }}>
            <div className={styles.resizerV} onPointerDown={rightResize.onDown} />
            <div className={styles.dockHeader}>
              <div className={styles.seg}>
                <button
                  type="button"
                  className={`${styles.segBtn}${dock.right === 'profile' ? ' ' + styles.segBtnActive : ''}`}
                  onClick={() => switchRight('profile')}
                >
                  <UIcon name="info" size={12} gold={dock.right === 'profile'} />Profile
                </button>
                <button
                  type="button"
                  className={`${styles.segBtn}${dock.right === 'news' ? ' ' + styles.segBtnActive : ''}`}
                  onClick={() => switchRight('news')}
                >
                  <UIcon name="bolt" size={12} gold={dock.right === 'news'} />News
                </button>
              </div>
              <div className={styles.dockSpacer} />
              <button type="button" className={styles.dockClose} onClick={closeRight} title="Close panel" aria-label="Close panel">
                <UIcon name="x" size={13} />
              </button>
            </div>
            <div className={styles.dockBody}>
              {dock.right === 'profile'
                ? <DockProfile sym={sym} onPickSymbol={onPickSymbol} />
                : <DockNews sym={sym} filter={dock.newsFilter} onFilter={setNewsFilter} />}
            </div>
          </div>
        )}
      </div>

      {bottomOpen && (
        <div className={styles.dockBottom} style={{ height: bottomResize.size }}>
          <div className={styles.resizerH} onPointerDown={bottomResize.onDown} />
          <DockFundamentals sym={sym} view={dock.fundView} onView={setFundView} onClose={closeBottom} />
        </div>
      )}
    </div>
  )
}
