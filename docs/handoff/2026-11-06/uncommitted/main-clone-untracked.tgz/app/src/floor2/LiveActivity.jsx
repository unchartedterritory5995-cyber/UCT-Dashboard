import { useState, useEffect, useRef } from 'react'
import { Avatar, user, timeAgo } from './util'

const ACTORS = ['mentor', 'blake', 'dana', 'marcus', 'priya', 'sam', 'leo', 'nina']
const EMO = ['🔥', '🚀', '💯', '🧠', '🙌', '👀']
const KINDS = ['reacted', 'commented', 'replied', 'answered', 'posted', 'bookmarked']

let _n = 0
const nid = () => `act${++_n}`

function makeEvent(posts, at = Date.now(), fresh = true) {
  const p = posts[Math.floor(Math.random() * posts.length)]
  const actor = ACTORS[Math.floor(Math.random() * ACTORS.length)]
  const kind = KINDS[Math.floor(Math.random() * KINDS.length)]
  return {
    id: nid(), actor, kind,
    emoji: kind === 'reacted' ? EMO[Math.floor(Math.random() * EMO.length)] : null,
    postId: p.id, title: p.title, at, fresh,
  }
}

function verb(e) {
  switch (e.kind) {
    case 'reacted': return <>reacted <span className="emo">{e.emoji}</span> to</>
    case 'commented': return 'commented on'
    case 'replied': return 'replied in'
    case 'answered': return <span style={{ color: 'var(--gain)' }}>answered</span>
    case 'posted': return 'posted'
    case 'bookmarked': return 'bookmarked'
    default: return 'in'
  }
}

export default function LiveActivity({ posts, onOpen }) {
  const [events, setEvents] = useState(() => {
    const gaps = [25, 70, 140, 260, 420, 680] // seconds ago
    return gaps.map((s) => makeEvent(posts, Date.now() - s * 1000, false))
  })
  const postsRef = useRef(posts)
  postsRef.current = posts

  useEffect(() => {
    // simulate a live stream: a new event every few seconds + age the times
    const add = setInterval(() => {
      setEvents((prev) => [makeEvent(postsRef.current), ...prev.map((e) => ({ ...e, fresh: false }))].slice(0, 9))
    }, 5000)
    const tick = setInterval(() => setEvents((prev) => [...prev]), 15000) // refresh relative times
    return () => { clearInterval(add); clearInterval(tick) }
  }, [])

  return (
    <div className="rail-card live-card">
      <h4><span className="live-dot" /> LIVE ACTIVITY</h4>
      <div className="act-list">
        {events.map((e) => (
          <button key={e.id} className={`act-row ${e.fresh ? 'fresh' : ''}`} onClick={() => onOpen(e.postId)}>
            <Avatar id={e.actor} size={26} />
            <div className="act-text">
              <b>{user(e.actor).name}</b> {verb(e)} <span className="act-target">{e.title}</span>
              <div className="act-time">{timeAgo(e.at)}</div>
            </div>
          </button>
        ))}
      </div>
    </div>
  )
}
