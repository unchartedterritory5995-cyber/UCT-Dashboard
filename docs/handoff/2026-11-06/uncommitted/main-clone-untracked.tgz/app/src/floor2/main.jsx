import React from 'react'
import { createRoot } from 'react-dom/client'
import Floor2 from './Floor2'
import './styles.css'
import './standalone.css'

// Standalone, backend-free prototype entry. Mounts ONLY the redesign so it can
// run on the existing Vite dev server (localhost:5173/floor2.html) without auth,
// the intro animation, or the API. Nothing here is imported by the real app.
createRoot(document.getElementById('floor2-root')).render(
  <React.StrictMode>
    <Floor2 />
  </React.StrictMode>,
)
