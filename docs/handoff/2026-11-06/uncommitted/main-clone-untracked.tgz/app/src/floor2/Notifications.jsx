import { Avatar, Author, timeAgo } from './util'

export default function Notifications({ notifications, onOpen, onMarkAll }) {
  const unread = notifications.filter((n) => !n.seen).length
  return (
    <div>
      <div className="notif-head">
        <h2>Notifications</h2>
        {unread > 0 && <button className="mark-read" onClick={onMarkAll}>Mark all read</button>}
      </div>
      {notifications.length === 0 ? (
        <div className="empty"><h3>No notifications yet</h3>When people react to or reply to your posts, you will see it here.</div>
      ) : (
        <div className="notif-list">
          {notifications.map((n) => (
            <div key={n.id} className={`notif ${n.seen ? '' : 'unread'}`} onClick={() => onOpen(n.postId)}>
              <Avatar id={n.actor} size={30} />
              <div className="notif-body">
                <Author id={n.actor} showHandle={false} />{' '}
                {n.kind === 'reaction'
                  ? <>reacted <span className="emo">{n.emoji}</span> to your post</>
                  : n.kind === 'comment'
                    ? 'commented on your post'
                    : 'replied to your post'}{' '}
                <span className="on-post">“{n.postTitle}”</span>
                <div className="notif-time">{timeAgo(Date.now() - n.ago)}</div>
              </div>
              <span className={`notif-dot ${n.seen ? 'read' : ''}`} />
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
