import { CATEGORIES } from './data'
import { Avatar } from './util'
import {
  IconHome, IconHelp, IconChat, IconBulb, IconTrophy, IconBook, IconBookmark, IconUser, IconBell,
} from './icons'

const ICONS = { home: IconHome, help: IconHelp, chat: IconChat, bulb: IconBulb, trophy: IconTrophy, book: IconBook }

export default function Sidebar({ posts, view, onPick, notifUnread = 0 }) {
  const countFor = (key) => key === 'all' ? posts.length : posts.filter((p) => p.category === key).length
  const myPosts = posts.filter((p) => p.author === 'you').length
  const bookmarks = posts.filter((p) => p.saved).length

  const item = (key, label, Icon, count, badge) => (
    <button key={key} className={`nav-item ${view === key ? 'active' : ''}`} onClick={() => onPick(key)}>
      <Icon size={19} /> {label}
      {badge ? <span className="nav-badge">{badge}</span> : <span className="count">{count}</span>}
    </button>
  )

  return (
    <aside className="sidebar">
      <div className="side-section">Browse</div>
      {CATEGORIES.map((c) => item(c.key, c.label, ICONS[c.icon] || IconChat, countFor(c.key)))}

      <div className="side-divider" />
      <div className="side-section">Yours</div>
      {item('myposts', 'My Posts', IconUser, myPosts)}
      {item('bookmarks', 'Bookmarks', IconBookmark, bookmarks)}
      {item('notifications', 'Notifications', IconBell, 0, notifUnread || null)}

      <div className="side-divider" />
      <div className="presence-card">
        <div className="presence-top"><span className="presence-dot" /> 128 on the floor</div>
        <div className="presence-avatars">
          {['mentor', 'blake', 'dana', 'marcus', 'priya'].map((id) => <Avatar key={id} id={id} size={26} />)}
          <span className="presence-more">+123</span>
        </div>
        <div className="presence-sub">3 mentors here now</div>
      </div>
    </aside>
  )
}
