import { USERS, NOW } from './data'

export const REACTION_PALETTE = ['🔥', '🚀', '💯', '🧠', '👀', '🙌', '😂', '💎', '🫡', '🤯']

export function timeAgo(epoch) {
  const s = Math.max(1, Math.floor((Date.now() - epoch) / 1000))
  if (s < 60) return 'just now'
  const m = Math.floor(s / 60)
  if (m < 60) return `${m}m ago`
  const h = Math.floor(m / 60)
  if (h < 24) return `${h}h ago`
  const d = Math.floor(h / 24)
  if (d < 30) return `${d}d ago`
  const mo = Math.floor(d / 30)
  if (mo < 12) return `${mo}mo ago`
  return `${Math.floor(mo / 12)}y ago`
}

// A post/comment is "new" if created within the last ~4 hours (for the NEW badge).
export const isFresh = (epoch) => Date.now() - epoch < 4 * 3600 * 1000
// "Old" enough that replying to it visibly revives it.
export const isOld = (epoch) => Date.now() - epoch > 21 * 24 * 3600 * 1000

export function user(id) {
  return USERS[id] || { id, name: id, handle: id, role: 'member', color: '#94a3b8', initials: '?' }
}

export function Avatar({ id, size = 26 }) {
  const u = user(id)
  const style = {
    width: size, height: size, fontSize: size * 0.4,
    background: u.role === 'mentor'
      ? 'linear-gradient(145deg, #3a3110, #241d07)'
      : `linear-gradient(145deg, ${u.color}, ${shade(u.color, -22)})`,
    color: u.role === 'mentor' ? '#ddc06a' : '#0d0f14',
    border: u.role === 'mentor' ? '1px solid rgba(201,168,76,.5)' : 'none',
  }
  return <span className="avatar" style={style} title={u.name}>{u.initials}</span>
}

function shade(hex, pct) {
  const n = parseInt(hex.slice(1), 16)
  let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255
  r = Math.max(0, Math.min(255, r + (r * pct) / 100))
  g = Math.max(0, Math.min(255, g + (g * pct) / 100))
  b = Math.max(0, Math.min(255, b + (b * pct) / 100))
  return `rgb(${r | 0},${g | 0},${b | 0})`
}

// Render body text with $TICKER highlighting. body is a string or array of paragraphs.
export function Body({ body, className }) {
  const paras = Array.isArray(body) ? body : [body]
  return (
    <div className={className}>
      {paras.map((p, i) => <p key={i}>{highlightTickers(p)}</p>)}
    </div>
  )
}

export function highlightTickers(text) {
  const parts = String(text).split(/(\$[A-Z]{1,5}\b)/g)
  return parts.map((part, i) =>
    /^\$[A-Z]{1,5}$/.test(part)
      ? <span key={i} className="tk" data-ticker={part.slice(1)}>{part}</span>
      : part,
  )
}

export function Author({ id, showHandle = true }) {
  const u = user(id)
  return (
    <span className="author">
      <span className="name">{u.name}</span>
      {u.role === 'mentor' && <span className="mentor-tag">Mentor</span>}
      {showHandle && u.role !== 'mentor' && <span style={{ color: 'var(--faint)' }}>@{u.handle}</span>}
    </span>
  )
}

// ---- search + sort helpers --------------------------------------------------
export function countComments(commentsOrPost) {
  // Tolerant: accepts a comments array OR a post object.
  const comments = Array.isArray(commentsOrPost) ? commentsOrPost : (commentsOrPost?.comments || [])
  let n = 0
  const walk = (list) => list.forEach((c) => { n++; walk(c.replies) })
  walk(comments)
  return n
}

export function lastActivity(post) {
  let latest = post.createdAt
  const walk = (list) => list.forEach((c) => { if (c.createdAt > latest) latest = c.createdAt; walk(c.replies) })
  walk(post.comments)
  return latest
}

// Normalize away punctuation/dashes/$ so "gap up" == "gap-up" == "gap—up".
const normText = (s) => String(s).toLowerCase().replace(/[^a-z0-9]+/g, ' ')
const escRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')

// Word-based, order-independent, punctuation-agnostic: every query word must
// appear somewhere in the post (title, body, tickers, or any comment).
export function matchesQuery(post, q) {
  const tokens = normText(q).split(' ').filter(Boolean)
  if (!tokens.length) return true
  let hay = `${post.title} ${Array.isArray(post.body) ? post.body.join(' ') : post.body} ${post.tickers.join(' ')}`
  const walk = (list) => list.forEach((c) => { hay += ` ${Array.isArray(c.body) ? c.body.join(' ') : c.body}`; walk(c.replies) })
  walk(post.comments)
  const h = normText(hay)
  return tokens.every((t) => h.includes(t))
}

// Wrap query words (2+ chars) in a gold highlight, ignoring punctuation.
export function highlightMatch(text, query) {
  const tokens = [...new Set(normText(query).split(' ').filter((t) => t.length >= 2))]
  if (!tokens.length) return text
  const re = new RegExp(`(${tokens.map(escRe).join('|')})`, 'ig')
  const set = new Set(tokens)
  return String(text).split(re).map((p, i) =>
    p && set.has(p.toLowerCase()) ? <mark key={i} className="search-hl">{p}</mark> : p,
  )
}

// Hot score: engagement decayed by age (Reddit-ish).
export function hotScore(post) {
  const ageH = (Date.now() - lastActivity(post)) / 3600000
  const engagement = post.votes + countComments(post.comments) * 2.2
  return engagement / Math.pow(ageH + 2, 0.85) + (post.pinned ? 1e6 : 0)
}
