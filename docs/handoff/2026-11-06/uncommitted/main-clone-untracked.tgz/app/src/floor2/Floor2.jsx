import { useReducer, useState, useMemo, useCallback, useRef, useEffect } from 'react'
import './styles.css'
import { SEED_POSTS, SEED_NOTIFICATIONS } from './data'
import { countComments, lastActivity, matchesQuery, hotScore } from './util'
import Header from './Header'
import Sidebar from './Sidebar'
import Feed from './Feed'
import PostDetail from './PostDetail'
import RightRail from './RightRail'
import Composer from './Composer'
import Notifications from './Notifications'
import TickerHover from './TickerHover'

// ---------- immutable helpers ----------
function applyVote(item, dir) {
  const my = item.myVote || 0
  if (my === dir) return { ...item, votes: item.votes - dir, myVote: 0 }
  return { ...item, votes: item.votes + dir - my, myVote: dir }
}
function toggleReaction(reactions, emoji) {
  const found = reactions.find((r) => r.emoji === emoji)
  if (found) {
    return reactions.map((r) => r.emoji === emoji
      ? { ...r, reacted: !r.reacted, count: r.count + (r.reacted ? -1 : 1) } : r)
  }
  return [...reactions, { emoji, count: 1, reacted: true }]
}
function mapComment(list, id, fn) {
  return list.map((c) => c.id === id ? fn(c) : { ...c, replies: mapComment(c.replies, id, fn) })
}
function addReply(list, parentId, node) {
  return list.map((c) => c.id === parentId
    ? { ...c, replies: [...c.replies, node] }
    : { ...c, replies: addReply(c.replies, parentId, node) })
}

let _newId = 1000
const nid = () => `n${++_newId}`

function reducer(posts, a) {
  switch (a.type) {
    case 'VOTE_POST':
      return posts.map((p) => p.id === a.postId ? applyVote(p, a.dir) : p)
    case 'REACT_POST':
      return posts.map((p) => p.id === a.postId ? { ...p, reactions: toggleReaction(p.reactions, a.emoji) } : p)
    case 'SAVE_POST':
      return posts.map((p) => p.id === a.postId ? { ...p, saved: !p.saved } : p)
    case 'MARK_ANSWER':
      return posts.map((p) => p.id === a.postId
        ? { ...p, answerId: p.answerId === a.commentId ? null : a.commentId } : p)
    case 'DELETE_POST':
      return posts.filter((p) => p.id !== a.postId)
    case 'VOTE_COMMENT':
      return posts.map((p) => p.id === a.postId
        ? { ...p, comments: mapComment(p.comments, a.commentId, (c) => applyVote(c, a.dir)) } : p)
    case 'REACT_COMMENT':
      return posts.map((p) => p.id === a.postId
        ? { ...p, comments: mapComment(p.comments, a.commentId, (c) => ({ ...c, reactions: toggleReaction(c.reactions, a.emoji) })) } : p)
    case 'ADD_COMMENT': {
      const node = { id: nid(), author: 'you', createdAt: Date.now(), body: a.body, votes: 1, myVote: 1, reactions: [], replies: [], chart: a.chart || null }
      return posts.map((p) => {
        if (p.id !== a.postId) return p
        return a.parentId
          ? { ...p, comments: addReply(p.comments, a.parentId, node) }
          : { ...p, comments: [...p.comments, node] }
      })
    }
    case 'ADD_POST': {
      const node = {
        id: nid(), author: 'you', category: a.category, flair: a.flair,
        title: a.title, body: a.body, tickers: a.tickers, createdAt: Date.now(),
        votes: 1, myVote: 1, saved: false, pinned: false, reactions: [], comments: [],
        chart: a.chart || null, images: a.images || [], files: a.files || [],
      }
      return [node, ...posts]
    }
    default:
      return posts
  }
}

const SORTS = { hot: hotScore, new: (p) => p.createdAt, top: (p) => p.votes, active: lastActivity }

export default function Floor2({ embedded = false }) {
  const [posts, dispatch] = useReducer(reducer, SEED_POSTS)
  const [view, setView] = useState('feed')     // 'feed' | 'detail'
  const [activeId, setActiveId] = useState(null)
  const [category, setCategory] = useState('all') // category key OR 'myposts' | 'bookmarks' | 'notifications'
  const [sort, setSort] = useState('hot')
  const [query, setQuery] = useState('')
  const [composerOpen, setComposerOpen] = useState(false)
  const [notifications, setNotifications] = useState(SEED_NOTIFICATIONS)
  const notifUnread = notifications.filter((n) => !n.seen).length

  // Mouse wheel should only ever SCROLL this page, never zoom it. A ctrl+wheel
  // (the gesture browsers turn into page zoom — and some mice/trackpads emit it
  // unintentionally) is intercepted here and converted into a normal scroll.
  const rootRef = useRef(null)
  useEffect(() => {
    const el = rootRef.current
    if (!el) return
    const onWheel = (e) => {
      const mid = el.querySelector('.main')
      if (!mid) return
      const delta = e.deltaMode === 1 ? e.deltaY * 16 : e.deltaY
      // is the pointer already over something scrollable (middle column, search
      // dropdown, an overflowing rail)? If so let the browser handle it natively.
      let node = e.target; let innerScrollable = null
      while (node && node !== el) {
        const s = getComputedStyle(node)
        if (/(auto|scroll)/.test(s.overflowY) && node.scrollHeight > node.clientHeight) { innerScrollable = node; break }
        node = node.parentElement
      }
      if (e.ctrlKey) { // never zoom the page
        e.preventDefault(); (innerScrollable || mid).scrollTop += delta; return
      }
      if (innerScrollable) return // native scroll
      // wheel over the header / side gutters / anywhere else → scroll the middle
      e.preventDefault(); mid.scrollTop += delta
    }
    el.addEventListener('wheel', onWheel, { passive: false })
    return () => el.removeEventListener('wheel', onWheel)
  }, [])

  const openPost = useCallback((id) => { setActiveId(id); setView('detail'); window.scrollTo(0, 0) }, [])
  const goFeed = useCallback(() => { setView('feed'); setActiveId(null) }, [])
  // Typing a search query always returns to the feed so results are visible.
  const handleQuery = useCallback((q) => {
    setQuery(q)
    if (q.trim()) { setView('feed'); setActiveId(null) }
  }, [])

  const searching = query.trim().length > 0
  const filtered = useMemo(() => {
    let list = posts
    if (searching) list = list.filter((p) => matchesQuery(p, query.trim()))
    else if (category === 'bookmarks') list = list.filter((p) => p.saved)
    else if (category === 'myposts') list = list.filter((p) => p.author === 'you')
    else if (category !== 'all' && category !== 'notifications') list = list.filter((p) => p.category === category)
    const key = SORTS[sort] || SORTS.hot
    return [...list].sort((x, y) => key(y) - key(x))
  }, [posts, category, sort, query, searching])

  // Opening the Notifications view clears the unread badge.
  useEffect(() => {
    if (category === 'notifications' && notifUnread > 0) {
      setNotifications((prev) => prev.map((n) => ({ ...n, seen: true })))
    }
  }, [category, notifUnread])

  const activePost = posts.find((p) => p.id === activeId)

  return (
    <div ref={rootRef} className={`floorx ${embedded ? 'embedded' : 'standalone'}`}>
      <Header
        embedded={embedded}
        query={query} setQuery={handleQuery}
        notifUnread={notifUnread}
        onNav={(k) => { setCategory(k); setQuery(''); goFeed() }}
        onBrand={() => { goFeed(); setCategory('all'); setQuery('') }}
        onNew={() => setComposerOpen(true)}
      />
      <div className="shell">
        <Sidebar
          posts={posts} view={category} notifUnread={notifUnread}
          onPick={(k) => { setCategory(k); setQuery(''); goFeed() }}
        />
        <main className="main">
          {view === 'detail' && activePost ? (
            <PostDetail post={activePost} dispatch={dispatch} onBack={goFeed} />
          ) : category === 'notifications' ? (
            <Notifications
              notifications={notifications}
              onOpen={openPost}
              onMarkAll={() => setNotifications((prev) => prev.map((n) => ({ ...n, seen: true })))}
            />
          ) : (
            <Feed
              posts={filtered} sort={sort} setSort={setSort}
              searching={searching} query={query} total={posts.length}
              onOpen={openPost} dispatch={dispatch}
              showSort={category !== 'bookmarks' && category !== 'myposts'}
            />
          )}
        </main>
        <RightRail posts={posts} onOpen={openPost} onPickTopic={handleQuery} />
      </div>
      <TickerHover rootRef={rootRef} />
      {composerOpen && (
        <Composer
          onClose={() => setComposerOpen(false)}
          onSubmit={(payload) => {
            dispatch({ type: 'ADD_POST', ...payload })
            setComposerOpen(false)
            setCategory('all'); setSort('new'); setQuery('')
            setView('feed'); window.scrollTo(0, 0)
          }}
        />
      )}
    </div>
  )
}

export { countComments }
