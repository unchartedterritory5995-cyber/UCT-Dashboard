import LiveActivity from './LiveActivity'
import NeedsAnswer from './NeedsAnswer'

export default function RightRail({ posts, onOpen }) {
  return (
    <aside className="rail">
      <LiveActivity posts={posts} onOpen={onOpen} />
      <NeedsAnswer posts={posts} onOpen={onOpen} />
    </aside>
  )
}
