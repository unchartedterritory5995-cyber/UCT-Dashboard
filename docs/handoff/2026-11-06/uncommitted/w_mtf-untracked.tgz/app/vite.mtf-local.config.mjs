// Scratch dev config (UNTRACKED, not committed): the app's config with /api -> :8001.
import base from './vite.config.js'
const cfg = typeof base === 'function' ? base({ command: 'serve', mode: 'development' }) : base
export default { ...cfg, server: { ...(cfg.server || {}), proxy: { '/api': 'http://127.0.0.1:8001' } } }
