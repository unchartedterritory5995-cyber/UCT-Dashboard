"""THE PRODUCTION STATE, REPRODUCED DETERMINISTICALLY — does a gapped intraday
cache heal, and can a live quote mutate an hours-old bucket?

⛔⛔ WHAT WAS MEASURED IN PRODUCTION ON 2026-09-22 (15:23-15:29 ET), and is
reproduced here exactly:

    server  /api/bars INOD tf=5   -> last 15:20, 95 Sep-22 bars, 69-526 ms
            since=<11:20>          -> 48 bars, 11:25 -> 15:20, 79 ms
    browser IndexedDB INOD_5       -> last 11:20, savedAt 15:18:48
            IndexedDB SOXL_5       -> last 09/21 19:55, ZERO Sep-22 bars

So the repair is available, cheap, and not happening. This harness seeds that
exact shape -- a durable cache whose tail is HOURS behind a current server --
and watches the REAL client decide what to do with it.

⭐ THE RUNTIME DISCRIMINATOR IS WHAT GOES ON THE WIRE. `classifyIntradayTail`
is a module-private function, so instead of asserting on it this records which
request the client actually makes:

    a `since=` request     -> the tail-repair branch ran ('fresh'/'behind')
    a full `bars=` request -> the gapped full-refetch branch ran
    NOTHING                -> the cache was treated as already durable + fresh

and then whether IndexedDB's CONTENT changed versus only its `savedAt`.

⚠️ WHAT IS REAL: idbGet/idbPut, the freshness classification, the warm/prefetch
decision, the SWR fetch, prepareForDisplay, every chart writer, and the
Lightweight Charts series that is measured. MODELLED: the SSE transport (a shim
over EventSource) and the market data (a fixture). Nothing in the product's
decision path is stubbed.

Usage:  python tools\\stale_gap_repro.py
"""
from __future__ import annotations

import json
import os
import socket
import sys
from datetime import timedelta

from playwright.sync_api import sync_playwright

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from intraday_tail_harness import (   # noqa: E402
    CLOCK_JS, FAKE_NOW, Fixture, SEED_JS, CACHE_LOGIC_VERSION, make_bars, route_handler,
)
from scan_handoff_harness import CLEAR_IDB, start_dev_server  # noqa: E402
from stimulus import require, verdict, summarize, render, StimulusError, INVALID, PASS, FAIL  # noqa: E402

SYM, TF = "INOD", "5"
# The production shape: cache tail 11:20, wall clock 15:18, server through 15:20.
CACHE_TAIL = FAKE_NOW.replace(hour=11, minute=22)     # make_bars stops at 11:20
NOW_LATE = FAKE_NOW.replace(hour=15, minute=18)
SERVER_NOW = FAKE_NOW.replace(hour=15, minute=22)     # server has 15:20
LIVE_PRICE = 73.08                                    # the price from the screenshot

# -- Instrumentation installed BEFORE the app boots --------------------------
# ⛔ AFTER-THE-FACT HOOKS CANNOT SEE A BOOTSTRAP. The whole question is which
# request the client makes on its FIRST load of a stale cache, so the fetch
# wrapper and the EventSource shim have to exist before any product module runs.
PROBE_JS = r"""
(() => {
  window.__probe = { fetches: [], ticks: 0 };
  const realFetch = window.fetch.bind(window);
  window.fetch = (input, init) => {
    const url = typeof input === 'string' ? input : (input && input.url) || '';
    if (url.indexOf('/api/bars') !== -1) {
      const rec = { url, at: Date.now(), t0: performance.now(),
                    since: /[?&]since=/.test(url), warm: /[?&]warm=1/.test(url),
                    status: null, ms: null, n: null };
      window.__probe.fetches.push(rec);
      return realFetch(input, init).then(r => {
        rec.status = r.status; rec.ms = Math.round(performance.now() - rec.t0);
        const c = r.clone();
        c.json().then(j => { rec.n = (j && j.bars && j.bars.length) || 0; }).catch(() => {});
        return r;
      });
    }
    return realFetch(input, init);
  };
  // SSE shim: the prices stream is what feeds realtimeCandle -> Writer C.
  const Real = window.EventSource;
  const feeds = [];
  function FakeES(url) {
    if (String(url).indexOf('/api/stream/') === -1) return new Real(url);
    const self = this;
    this.url = String(url); this.readyState = 0; this._l = {};
    this.onopen = null; this.onerror = null; this.onmessage = null;
    this.addEventListener = (t, fn) => { (this._l[t] = this._l[t] || []).push(fn); };
    this.removeEventListener = (t, fn) => {
      const a = this._l[t] || []; const i = a.indexOf(fn); if (i >= 0) a.splice(i, 1);
    };
    this.close = () => { self.readyState = 2; const i = feeds.indexOf(self); if (i >= 0) feeds.splice(i, 1); };
    this._fire = (type, data) => {
      const ev = { type, data: typeof data === 'string' ? data : JSON.stringify(data) };
      (self._l[type] || []).forEach(fn => { try { fn(ev) } catch (e) { void e } });
      if (type === 'message' && typeof self.onmessage === 'function') self.onmessage(ev);
    };
    feeds.push(this);
    setTimeout(() => { if (self.readyState !== 2) { self.readyState = 1;
      if (typeof self.onopen === 'function') self.onopen({ type: 'open' }); } }, 0);
  }
  window.EventSource = FakeES;
  window.__feed = {
    open: () => feeds.filter(f => f.readyState === 1).length,
    tick: (sym, price, vol, ts) => { let n = 0;
      for (const f of feeds) if (f.readyState === 1) { f._fire('tick', { sym, price, vol, ts }); n++; }
      window.__probe.ticks += n; return n; },
  };
})();
"""

READ_IDB = """
(async (key) => {
  const db = await new Promise((res, rej) => {
    const r = indexedDB.open('uct_bars_v1'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
  });
  const v = await new Promise((res, rej) => {
    const t = db.transaction('bars', 'readonly').objectStore('bars').get(key);
    t.onsuccess = () => res(t.result); t.onerror = () => rej(t.error);
  });
  db.close();
  if (!v || !v.bars || !v.bars.length) return null;
  const b = v.bars;
  return { n: b.length, firstT: b[0].t, lastT: b[b.length - 1].t,
           lastTField: v.lastT, savedAt: v.savedAt, v: v.v };
})
"""


def et(ts):
    from datetime import datetime, timezone
    return datetime.fromtimestamp(ts, timezone(timedelta(hours=-4))).strftime("%m/%d %H:%M")


def main():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]
    print(f"[gap] dev server on :{port}", flush=True)
    proc = start_dev_server(port)
    results = {}
    try:
        with sync_playwright() as pw:
            browser = pw.chromium.launch()
            ctx = browser.new_context(viewport={"width": 1400, "height": 860})
            ctx.add_init_script(CLOCK_JS % int(NOW_LATE.timestamp() * 1000))
            ctx.add_init_script(PROBE_JS)
            fixture = Fixture(); fixture.server_now = SERVER_NOW
            holder = {"f": fixture}
            # ⛔ THE EMPTY-BUT-AUTHORITATIVE ANSWER. The laundering branch is
            # `next = rows.length ? rows : have.bars`, so it needs a 200 whose
            # `bars` array is EMPTY -- not a 503 shed (which `_isAuthoritativeAnswer`
            # correctly refuses before any write). Only this shape can reach idbPut
            # with the unchanged stale array, so only this shape can test it.
            EMPTY = "--empty" in sys.argv
            def _route(route, request):
                if EMPTY and "/api/bars/" in request.url:
                    route.fulfill(status=200, content_type="application/json",
                                  body=json.dumps({"ticker": SYM, "tf": TF, "bars": []}))
                    return
                return route_handler(holder["f"])(route, request)
            ctx.route("**/api/**", _route)
            page = ctx.new_page()
            base = f"http://127.0.0.1:{port}"

            # -- Seed the EXACT production shape: a durable, hours-gapped cache --
            page.goto(f"{base}/scan-harness.html?blank=1", wait_until="domcontentloaded")
            page.evaluate(CLEAR_IDB)
            page.evaluate("() => { localStorage.setItem('uct.chartTiming','1');"
                          "        localStorage.setItem('uct.cameraAudit','1') }")
            page.evaluate(SEED_JS, [SYM, TF, make_bars(int(TF), CACHE_TAIL, 4), CACHE_LOGIC_VERSION])
            before = page.evaluate(READ_IDB, f"{SYM}_{TF}")
            print(f"  seeded cache: n={before['n']} last={et(before['lastT'])} "
                  f"savedAt={before['savedAt']}", flush=True)

            # -- Load the chart on that stale cache --
            page.goto(f"{base}/scan-harness.html?tf={TF}&syms={SYM}", wait_until="domcontentloaded")
            page.wait_for_timeout(9000)     # well past any first-paint + repair window

            probe = page.evaluate("() => window.__probe")
            after = page.evaluate(READ_IDB, f"{SYM}_{TF}")
            tail_pre = page.evaluate("() => window.__scan.tail(3)")
            timing = page.evaluate("() => (window.__uctChartTiming && window.__uctChartTiming.report()) || []")
            feeds = page.evaluate("() => window.__feed.open()")

            # -- The live quote that produced the screenshot --
            last_rendered = (tail_pre or [{}])[-1]
            tick_ts = int(NOW_LATE.timestamp())
            fired = page.evaluate("([s,p,v,t]) => window.__feed.tick(s,p,v,t)",
                                  [SYM, LIVE_PRICE, 1000, tick_ts])
            page.wait_for_timeout(2500)
            tail_post = page.evaluate("() => window.__scan.tail(3)")
            after2 = page.evaluate(READ_IDB, f"{SYM}_{TF}")

            browser.close()
    finally:
        try: proc.terminate()
        except Exception: pass                              # noqa: BLE001

    bars_reqs = probe.get("fetches", [])
    since_reqs = [f for f in bars_reqs if f.get("since")]
    full_reqs = [f for f in bars_reqs if not f.get("since")]
    content_changed = before["lastT"] != after["lastT"] or before["n"] != after["n"]
    saved_changed = before["savedAt"] != after["savedAt"]

    post_last = (tail_post or [{}])[-1]
    pre_last = (tail_pre or [{}])[-1]
    stale_mutation = bool(
        pre_last and post_last
        and pre_last.get("time") == post_last.get("time")            # SAME bucket
        and abs((post_last.get("close") or 0) - LIVE_PRICE) < 0.01   # moved to the live quote
        and abs((pre_last.get("close") or 0) - LIVE_PRICE) > 1.0     # and was far from it
    )

    results = {
        "productionShapeSeeded": {"lastT": et(before["lastT"]), "n": before["n"]},
        "idbBefore": {**before, "lastET": et(before["lastT"])},
        "idbAfterLoad": {**after, "lastET": et(after["lastT"])} if after else None,
        "idbAfterTick": {**after2, "lastET": et(after2["lastT"])} if after2 else None,
        "barsRequests": bars_reqs,
        "sinceRequests": len(since_reqs), "fullRequests": len(full_reqs),
        "idbContentChanged": content_changed, "idbSavedAtChanged": saved_changed,
        "ageLaundering": (saved_changed and not content_changed),
        "renderedBefore": tail_pre, "renderedAfter": tail_post,
        "renderedLastBeforeET": et(pre_last["time"] - 14400) if pre_last.get("time") else None,
        "renderedLastAfterET": et(post_last["time"] - 14400) if post_last.get("time") else None,
        "tickFired": fired, "feedsOpen": feeds,
        "staleBucketMutation": stale_mutation,
        "timingRows": timing[-3:] if timing else [],
    }

    print("\n-- RUNTIME EVIDENCE -----------------------------------------")
    print(f"  bars requests fired      : {len(bars_reqs)}  (since={len(since_reqs)} full={len(full_reqs)})")
    for f in bars_reqs[:6]:
        print(f"      {f['status']} {f['ms']}ms n={f['n']}  {f['url'][:88]}")
    print(f"  IDB content changed      : {content_changed}  "
          f"({et(before['lastT'])} -> {et(after['lastT']) if after else 'gone'})")
    print(f"  IDB savedAt changed      : {saved_changed}")
    print(f"  STALE-AGE LAUNDERING     : {results['ageLaundering']}")
    print(f"  rendered last before tick: {results['renderedLastBeforeET']} "
          f"O={pre_last.get('open')} H={pre_last.get('high')} L={pre_last.get('low')} C={pre_last.get('close')}")
    print(f"  live tick                : price={LIVE_PRICE} ts={et(tick_ts)} fired={fired} feeds={feeds}")
    print(f"  rendered last after tick : {results['renderedLastAfterET']} "
          f"O={post_last.get('open')} H={post_last.get('high')} L={post_last.get('low')} C={post_last.get('close')}")
    print(f"  STALE BUCKET MUTATION    : {stale_mutation}")

    # -- Verdict, fail-closed --
    try:
        require("a chart load occurred against the stale cache", bool(tail_pre), tail_pre)
        require("the live tick reached a subscriber", fired and fired > 0,
                {"fired": fired, "feeds": feeds})
    except StimulusError as exc:
        results["verdict"] = INVALID
        results["why"] = str(exc)
        print(f"\n  RESULT: INVALID -- {exc}")
    else:
        # The product is CORRECT only if it healed AND did not mutate a stale bucket.
        healed = content_changed
        results["verdict"] = verdict(True, healed and not stale_mutation)
        results["healed"] = healed
        print(f"\n  healed={healed}  staleMutation={stale_mutation}  => {results['verdict']}")

    dst = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stale_gap_repro_out%s.json" % ("_empty" if "--empty" in sys.argv else ""))
    with open(dst, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, default=str)
    print(f"[gap] wrote {dst}")
    if "--empty" in sys.argv:
        print("  (empty-response mode: every /api/bars answered 200 with bars=[])")
    return 0


if __name__ == "__main__":
    sys.exit(main())
