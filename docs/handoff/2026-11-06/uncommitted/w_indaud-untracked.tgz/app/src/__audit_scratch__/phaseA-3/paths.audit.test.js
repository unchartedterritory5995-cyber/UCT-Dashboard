// PA3 scratch probe — NOT COMMITTED. Drives every destructive indicator door's
// PURE writer on one fixture: three RSIs (two tuned, one hidden) + an MA over
// RSI#1 + a header info value on RSI#2, and records what each door leaves.
import { describe, it, expect } from 'vitest'
import * as registry from '../../components/chart/engine/nativeRegistry'
import { mergeChartSettings, CHART_DEFAULTS } from '../../components/chart/chartDefaults'
import { mergeSettingsOverride, instanceTombstone } from '../../components/chart/instanceShape'
import {
  addInstance, setIndicatorEnabled, setInstanceInput, setInstanceHidden, removeInstance,
  duplicateInstance, isIndicatorEnabled, findInstance, setInstanceCalculationTimeframe,
  setInstanceAppearance,
} from '../../components/chart/engine/instanceControls'
import { toggledRow, isRowOn } from '../../components/chart/IndicatorLibraryDialog'
import { applyRowPatch } from '../../components/chart/indicatorRegistry'
import { catalogRows } from '../../components/chart/indicatorCatalog'
import { ENGINE_OWNED } from '../../components/chart/engine/flipState'
import { instanceSource } from '../../components/chart/engine/sourceRef'
import { addInfoValue, infoValuesOf } from '../../components/chart/engine/infoValues'
import { chartTemplateSettings } from '../../components/chart/chartTemplateApply'
import { removeInstanceWithRecord, restoreRemoved } from '../../components/chart/builder/agentMutations'
import { normalizeInstances, migrateLegacyToInstances, legacyInstanceId } from '../../components/chart/engine/instances'

const log = (...a) => console.log('[PA3]', ...a)
const live = (cs, defId) => (cs.indicatorInstances || []).filter(i => i && !i.deleted && (!defId || i.defId === defId))
const byId = (cs, id) => (cs.indicatorInstances || []).find(i => i && i.instanceId === id)

function fixture() {
  let cs = mergeChartSettings(null)
  cs = addInstance(cs, 'rsi', registry)                       // inst:rsi:1
  cs = setInstanceInput(cs, 'inst:rsi:1', 'period', 7, registry)
  cs = setInstanceCalculationTimeframe(cs, 'inst:rsi:1', 'W', registry)
  cs = duplicateInstance(cs, 'inst:rsi:1', registry)          // inst:rsi:2 (copy of #1)
  cs = setInstanceInput(cs, 'inst:rsi:2', 'period', 21, registry)
  cs = addInstance(cs, 'rsi', registry)                       // inst:rsi:3
  cs = setInstanceInput(cs, 'inst:rsi:3', 'period', 50, registry)
  cs = setInstanceHidden(cs, 'inst:rsi:3', true, registry)
  cs = addInstance(cs, 'movingAverage', registry)             // MA over RSI#1
  const maId = live(cs, 'movingAverage').map(i => i.instanceId).find(id => id.startsWith('inst:'))
  const rsiPlot = registry.getDefinition('rsi').plots[0].key
  cs = setInstanceInput(cs, maId, 'source', instanceSource('inst:rsi:1', rsiPlot), registry)
  cs = addInfoValue(cs, { instanceId: 'inst:rsi:2', plotKey: rsiPlot, format: 'auto' },
    (id) => registry.getDefinition(id), () => true)
  return { cs, maId, rsiPlot }
}

describe('PA3 fixture sanity', () => {
  it('three RSIs (7/W, 21/W, 50 hidden), MA(RSI#1), info value on RSI#2', () => {
    const { cs, maId } = fixture()
    const r = live(cs, 'rsi')
    log('fixture rsi', JSON.stringify(r))
    log('fixture ma', JSON.stringify(byId(cs, maId)))
    log('fixture info', JSON.stringify(infoValuesOf(cs)))
    expect(r.map(i => i.inputs.period)).toEqual([7, 21, 50])
    expect(r.map(i => i.hidden)).toEqual([false, false, true])
    expect(r[0].calculationTimeframe).toBe('W')
    expect(byId(cs, maId).inputs.source).toBe(instanceSource('inst:rsi:1', registry.getDefinition('rsi').plots[0].key))
    expect(infoValuesOf(cs)).toHaveLength(1)
  })
})

describe('PA3 · the per-DEFINITION off door (Library row, right-click, Ctrl+I/O/B, Alt+U, phone switch + Remove from chart)', () => {
  it('setIndicatorEnabled(false) tombstones ALL THREE, severs the MA source and the info value; ON gives ONE default', () => {
    const { cs, maId } = fixture()
    const off = setIndicatorEnabled(cs, 'rsi', false, registry)
    const recs = ['inst:rsi:1', 'inst:rsi:2', 'inst:rsi:3', 'legacy:rsi'].map(id => byId(off, id))
    log('after OFF', JSON.stringify(recs))
    log('MA source after OFF', byId(off, maId).inputs.source)
    log('info after OFF', JSON.stringify(infoValuesOf(off)))
    expect(live(off, 'rsi')).toHaveLength(0)
    expect(recs.every(r => r && r.deleted === true && Object.keys(r).length === 2)).toBe(true)
    expect(byId(off, maId).inputs.source.startsWith('!')).toBe(true)
    expect(infoValuesOf(off)[0].severed).toBe(true)
    expect(off.indicators.rsi.enabled).toBe(false)
    const on = setIndicatorEnabled(off, 'rsi', true, registry)
    log('after ON', JSON.stringify(live(on, 'rsi')))
    expect(live(on, 'rsi')).toHaveLength(1)
    expect(live(on, 'rsi')[0].instanceId).toBe('legacy:rsi')
    expect(live(on, 'rsi')[0].inputs.period).toBeUndefined()           // 14, the default
    expect(byId(on, maId).inputs.source.startsWith('!')).toBe(true)    // NOT reconnected
    expect(infoValuesOf(on)[0].severed).toBe(true)
    // the round trip the member sees
    const back = mergeChartSettings(JSON.stringify(on))
    expect(live(back, 'rsi').map(i => i.inputs.period ?? 14)).toEqual([14])
  })

  it('the Library row / phone switch / phone "Remove from chart" (toggledRow) is the same writer', () => {
    const { cs } = fixture()
    const row = catalogRows(registry).find(r => r.id === 'rsi')
    expect(isRowOn(row, cs)).toBe(true)
    const next = toggledRow(row, cs, registry)
    expect(live(next, 'rsi')).toHaveLength(0)
  })

  it('a Settings / modal instance row patched {enabled:false} (applyRowPatch, indicatorRegistry.js:943) kills its SIBLINGS too', () => {
    const { cs } = fixture()
    const row = { engineOwned: true, defId: 'rsi', instanceId: 'inst:rsi:2' }
    const next = applyRowPatch(row, { enabled: false }, cs, registry)
    expect(live(next, 'rsi')).toHaveLength(0)
  })

  it('the right-click Indicators submenu offers "MA" (movingAverage) and OFF there tombstones EVERY moving average, default EMA/SMAs included', () => {
    const base = mergeChartSettings(null)
    const rows = catalogRows(registry).filter(r => r.id === 'movingAverage')
    const def = registry.getDefinition('movingAverage')
    const listed = rows.length === 1 && def?.meta?.quickMenu !== false
    const avgs = live(base, 'movingAverage')
    log('right-click lists movingAverage?', listed, 'addOnly', def?.meta?.addOnly, 'default live MAs', avgs.map(i => i.instanceId))
    // what StockChart.jsx:5805 does for a checked row: setIndicatorEnabled(cs, key, !on)
    const on = isIndicatorEnabled(base, 'movingAverage', ENGINE_OWNED)
    const next = setIndicatorEnabled(base, 'movingAverage', !on, registry)
    log('MA right-click on?', on, '-> live MAs after', live(next, 'movingAverage').length)
    expect(listed).toBe(true)
    if (avgs.length) {
      expect(on).toBe(true)
      expect(live(next, 'movingAverage')).toHaveLength(0)
    }
  })
})

describe('PA3 · per-INSTANCE doors (legend chip Delete, Inspector Remove, Settings ✕, Agent remove)', () => {
  it('removeInstance kills ONE (minimal tombstone), siblings keep inputs, mirror stays on', () => {
    const { cs, maId } = fixture()
    const next = removeInstance(cs, 'inst:rsi:1', registry)
    expect(byId(next, 'inst:rsi:1')).toEqual({ instanceId: 'inst:rsi:1', deleted: true })
    expect(live(next, 'rsi').map(i => i.inputs.period)).toEqual([21, 50])
    expect(byId(next, maId).inputs.source.startsWith('!')).toBe(true)   // dependent severed
    expect(next.indicators.rsi.enabled).toBe(true)
  })
  it('setInstanceHidden keeps EVERYTHING (inputs, dependents, info value, mirror)', () => {
    const { cs, maId } = fixture()
    const next = setInstanceHidden(cs, 'inst:rsi:1', true, registry)
    expect(byId(next, 'inst:rsi:1').inputs.period).toBe(7)
    expect(byId(next, maId).inputs.source.startsWith('@')).toBe(true)
    expect(infoValuesOf(next)[0].severed).not.toBe(true)
    const shown = setInstanceHidden(next, 'inst:rsi:1', false, registry)
    expect(JSON.stringify(shown.indicatorInstances)).toBe(JSON.stringify(cs.indicatorInstances))
  })
  it('the Agent remove has EXACT undo (restoreRemoved) — byte-identical after a reload round trip', () => {
    const { cs } = fixture()
    const norm = mergeChartSettings(JSON.stringify(cs))
    const r = removeInstanceWithRecord(norm, 'inst:rsi:1', registry)
    expect(r.ok).toBe(true)
    log('agent remove record paths', r.record.paths.length, JSON.stringify(r.record.paths.map(p => p.path)))
    const saved = mergeChartSettings(JSON.stringify(r.cs))
    const u = restoreRemoved(saved, r.record)
    expect(u.ok).toBe(true)
    // VALUE-exact…
    expect(u.cs.indicatorInstances).toEqual(norm.indicatorInstances)
    expect(u.cs.header).toEqual(norm.header)
    // …but NOT byte-exact: setAt rebuilds the revived record leaf by leaf, so its KEY ORDER differs
    const a = JSON.stringify(byId(u.cs, 'inst:rsi:1')), b = JSON.stringify(byId(norm, 'inst:rsi:1'))
    log('agent undo byte-identical?', a === b, '| before', b, '| after undo', a)
    expect(a === b).toBe(false)
  })
  it('…and the same record machinery undoes a DEFINITION-level off exactly, if a caller recorded it', () => {
    // feasibility for manual undo: changeRecord/revert are generic leaf diffs
    const { cs } = fixture()
    const norm = mergeChartSettings(JSON.stringify(cs))
    const off = mergeChartSettings(JSON.stringify(setIndicatorEnabled(norm, 'rsi', false, registry)))
    // build a record the way agentMutations.recordOf does (exported changeRecord)
    return import('../../components/chart/builder/agentMutations').then(({ changeRecord }) => {
      const rec = changeRecord(norm, off)
      // revert = apply `before` at each path — reuse restoreRemoved (it is revert + live-id check)
      const u = restoreRemoved(off, { ...rec, ids: ['inst:rsi:1', 'inst:rsi:2', 'inst:rsi:3'] })
      log('def-off record paths', rec.paths.length, 'undo ok', u.ok)
      expect(u.ok).toBe(true)
      expect(JSON.stringify(u.cs.indicatorInstances)).toBe(JSON.stringify(norm.indicatorInstances))
    })
  })
})

describe('PA3 · whole-blob doors', () => {
  it('Restore Defaults (ChartSettingsModal.jsx:469-473) writes indicatorInstances:[] — no tombstones, no record', () => {
    const { cs } = fixture()
    const reset = JSON.parse(JSON.stringify(CHART_DEFAULTS))
    expect(reset.indicatorInstances).toEqual([])
    const back = mergeChartSettings(JSON.stringify(reset))
    expect(live(back, 'rsi')).toHaveLength(0)
    // …and because nothing is tombstoned, a STALE union-by-id writer (a grid cell's override,
    // setPrefMerged) can put every RSI straight back — the reset is not even durable
    const revived = mergeSettingsOverride(back, { indicatorInstances: cs.indicatorInstances })
    log('reset then stale-union: live rsi', live(revived, 'rsi').length)
    expect(live(revived, 'rsi')).toHaveLength(3)
  })
  it('chart template apply (chartTemplateApply.js:36) REPLACES the instance list wholesale', () => {
    const { cs } = fixture()
    const tpl = { settings: { ...mergeChartSettings(null), indicatorInstances: [instanceTombstone('inst:rsi:1')] } }
    const next = chartTemplateSettings(tpl)
    expect(live(next, 'rsi')).toHaveLength(0)
    expect(next.indicatorInstances).toHaveLength(1)
    expect(cs.indicatorInstances.length).toBeGreaterThan(3)
  })
})

describe('PA3 · grid cell: a chord in a cell writes the WIDGET\'s instances as tombstones into GLOBAL', () => {
  it('global tombstone + widget live instance -> mergeSettingsOverride collapses to the tombstone (cell hides it forever)', () => {
    const { cs } = fixture()
    const globalBlob = mergeChartSettings(null)
    const cellCs = mergeSettingsOverride(globalBlob, cs)            // GridChartCell settingsOverride = first widget's blob
    const written = setIndicatorEnabled(cellCs, 'rsi', false, registry) // Ctrl+I in the active cell
    // handleUpdateChartSettings restores only keys carried through UNCHANGED; indicatorInstances changed,
    // so the tombstoned union is what reaches setPref('chart_settings')
    const newGlobal = mergeChartSettings(JSON.stringify(written))
    const cellAfter = mergeSettingsOverride(newGlobal, cs)          // widget still live on /charts
    log('widget live rsi', live(cs, 'rsi').length, '| cell after chord', live(cellAfter, 'rsi').length)
    expect(live(cs, 'rsi')).toHaveLength(3)
    expect(live(cellAfter, 'rsi')).toHaveLength(0)
  })
})

describe('PA3 · alerts: the orphan sweep counts a TOMBSTONE as a live instance', () => {
  // faithful JS port of api/services/indicator_alert_service.py:_walk_instance_ids (1433-1459)
  const walk = (node, out) => {
    if (node && typeof node === 'object' && !Array.isArray(node)) {
      if (typeof node.instanceId === 'string' && node.instanceId) out.add(node.instanceId)
      for (const v of Object.values(node)) walk(v, out)
    } else if (Array.isArray(node)) for (const v of node) walk(v, out)
  }
  it('an alert bound to inst:rsi:1 is NOT flagged missing after the instance is deleted', () => {
    const { cs } = fixture()
    const gone = removeInstance(cs, 'inst:rsi:1', registry)
    const ids = new Set(); walk(JSON.parse(JSON.stringify(gone)), ids)
    log('ids the sweep sees after delete include inst:rsi:1?', ids.has('inst:rsi:1'))
    expect(ids.has('inst:rsi:1')).toBe(true)   // => `missing` is false at :1526 — sweep is blind to deletes
  })
})

describe('PA3 · silent drops (engine/instances.js:765-817, StockChart.jsx:12054-12064)', () => {
  it('unknown defId and undeclared input are DROPPED at paint, KEPT in the blob, and a legacy projection can stand in', () => {
    const raw = {
      ...mergeChartSettings(null),
      indicators: { ...mergeChartSettings(null).indicators, rsi: { enabled: true, period: 9 } },
      indicatorInstances: [
        { instanceId: 'inst:u_0123456789ab:1', defId: 'u_0123456789ab', inputs: { len: 5 }, hidden: false },
        { instanceId: 'legacy:rsi', defId: 'rsi', inputs: { period: 7, removedKnob: 3 }, hidden: false },
      ],
    }
    const back = mergeChartSettings(JSON.stringify({ ...raw, settingsVersion: 2 }))
    expect(back.indicatorInstances).toHaveLength(raw.indicatorInstances.length + (back.indicatorInstances.length - raw.indicatorInstances.length))
    expect(back.indicatorInstances.some(i => i.instanceId === 'inst:u_0123456789ab:1')).toBe(true)  // kept in blob
    const n = normalizeInstances(back.indicatorInstances, registry)
    log('kept', n.kept.map(i => i.instanceId), 'dropped', n.dropped.map(d => d.inst.instanceId + ' :: ' + d.reason.slice(0, 70)))
    expect(n.dropped.map(d => d.inst.instanceId).sort()).toEqual(['inst:u_0123456789ab:1', 'legacy:rsi'].sort())
  })
  it('the v1→v2 fold (chartDefaults.js:832-838) DESTROYS a dropped instance in the merged output', () => {
    const v1 = { indicatorInstances: [{ instanceId: 'inst:u_0123456789ab:1', defId: 'u_0123456789ab', inputs: {}, hidden: false }] }
    const back = mergeChartSettings(JSON.stringify(v1))   // no settingsVersion => 1
    log('v1 fold output ids', back.indicatorInstances.map(i => i.instanceId))
    expect(back.indicatorInstances.some(i => i.instanceId === 'inst:u_0123456789ab:1')).toBe(false)
  })
})

describe('PA3 · version skew: what an OLD client makes of a hidden-but-kept instance', () => {
  it('all instances hidden still reads as ON at every checkbox (isIndicatorEnabled counts hidden)', () => {
    let { cs } = fixture()
    for (const i of live(cs, 'rsi')) cs = setInstanceHidden(cs, i.instanceId, true, registry)
    expect(isIndicatorEnabled(cs, 'rsi', ENGINE_OWNED)).toBe(true)
    // the old Library tick then means OFF -> old writer tombstones the hidden-but-kept set
    expect(live(setIndicatorEnabled(cs, 'rsi', false, registry), 'rsi')).toHaveLength(0)
    // the migrator does NOT project a second RSI beside hidden ones (hidden counts as taken)
    // the RAW migrator DOES project legacy:rsi beside three hidden ones (per-id 'taken' only)…
    const raw = migrateLegacyToInstances({ ...cs }, registry).filter(i => i.defId === 'rsi' && !i.deleted)
    expect(raw).toHaveLength(4)
    // …and StockChart.jsx:12054-12062's liveStoredDefIds filter (hidden COUNTS) is what suppresses it
    const storedIds = new Set(cs.indicatorInstances.map(i => i.instanceId))
    const liveDefs = new Set(normalizeInstances(cs.indicatorInstances, registry).kept.map(i => i.defId))
    const drawn = raw.filter(i => storedIds.has(i.instanceId) || !liveDefs.has(i.defId))
    expect(drawn).toHaveLength(3)
    expect(findInstance(cs, legacyInstanceId('rsi'))).toBeNull()
  })
})
