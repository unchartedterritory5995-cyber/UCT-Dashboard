// PHASE A-1 proposal code (audit scratch, never committed).
// Deterministic signatures over a PERSISTED canonical tree.

const isSeries = (n, name) => !!n && n.type === 'series' && n.name === name
const kids = (n) => (n && Array.isArray(n.args) ? n.args : [])

export function walk(node, visit, parent = null) {
  if (!node || typeof node !== 'object') return
  visit(node, parent)
  for (const a of kids(node)) walk(a, visit, node)
}

/** P0-1 signature: a `stoch` call whose first three args are EXACTLY the bare
 *  series close, high, low (the PCF_FUSED.STOC fill order). */
export function isSwappedStoch(tree) {
  let hit = false
  walk(tree, (n) => {
    if (hit || n.type !== 'call' || n.name !== 'stoch') return
    const [a, b, c] = kids(n)
    if (isSeries(a, 'close') && isSeries(b, 'high') && isSeries(c, 'low')) hit = true
  })
  return hit
}

/** Every stoch call's role signature, e.g. ['close,high,low'] — anything other
 *  than 'high,low,close' is suspicious whatever door wrote it. */
export function stochSignature(tree) {
  const out = []
  walk(tree, (n) => {
    if (n.type !== 'call' || n.name !== 'stoch') return
    out.push(kids(n).slice(0, 3).map((x) => (x && x.type === 'series' ? x.name : x && x.type)).join(','))
  })
  return out
}

/** The deterministic tree migration: reorder ONLY the swapped shape. */
export function rewriteSwappedStoch(node) {
  if (!node || typeof node !== 'object') return node
  const args = kids(node).map(rewriteSwappedStoch)
  if (node.type === 'call' && node.name === 'stoch') {
    const [a, b, c, ...rest] = args
    if (isSeries(a, 'close') && isSeries(b, 'high') && isSeries(c, 'low')) {
      return { ...node, args: [b, c, a, ...rest] }
    }
  }
  return Array.isArray(node.args) ? { ...node, args } : node
}

/** P0-2 signatures. A `tf` node (closed-period read) whose PARENT is
 *  (a) a windowed call (declared lookback reads the tf child), or (b) an
 *  `offset` node. `tf_live` is reported separately. */
export function mtfShapes(tree, table) {
  const found = []
  walk(tree, (n, parent) => {
    if ((n.type !== 'tf' && n.type !== 'tf_live') || !parent) return
    const leafField = kids(n).length === 1 && kids(n)[0].type === 'series'
    if (parent.type === 'offset') found.push({ shape: 'offset-of-tf', tf: n.value, node: n.type, leafField, bars: parent.value })
    else if (parent.type === 'call') {
      const spec = table && table.functions && table.functions[parent.name]
      const windowed = !!(spec && spec.lookback)
      found.push({ shape: windowed ? 'windowed-call-of-tf' : 'call-of-tf', fn: parent.name, tf: n.value, node: n.type, leafField })
    }
  })
  return found
}
