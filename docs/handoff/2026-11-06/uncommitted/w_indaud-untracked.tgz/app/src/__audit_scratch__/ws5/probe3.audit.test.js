import { it, vi } from 'vitest'
import { inspectSource } from '../../components/chart/builder/PineBox.jsx'
import { memberPaneDefinition } from '../../components/chart/builder/memberPane/memberPaneDefinition.js'
import { interpret } from '../../components/chart/engine/ast/interpret.js'
import { makeBars, refs } from './refs.js'
const L = String.fromCharCode(10)
const bars = makeBars(600, 7)
const S = (b) => ['//@version=5', 'indicator("p")', ...b].join(L) + L
const cases = {
  var_counter: ['var c = 0', 'c += 1', 'plot(c, "C")'],
  bs_confirmed: ['plot(barstate.isconfirmed ? close : na, "X")'],
  bs_isrealtime: ['plot(barstate.isrealtime ? 1 : 0, "X")'],
  bs_isfirst: ['plot(barstate.isfirst ? 1 : 0, "X")'],
  plotarrow: ['plotarrow(close - open, "X")'],
  linewidth: ['plot(close, "X", linewidth = 3)'],
  col_new: ['plot(close, "X", color = color.new(color.red, 50))'],
  cum: ['plot(ta.cum(volume), "X")'],
  pivot: ['plot(ta.pivothigh(high, 5, 5), "X")'],
  hist_series_offset: ['n = bar_index % 3', 'plot(close[n], "X")'],
}
it('probe3', () => {
  vi.stubEnv('VITE_PINE_OBJECTS_ONLY_PANE_ENABLED', '1')
  for (const [k, b] of Object.entries(cases)) {
    const src = S(b)
    const rep = inspectSource(src, 'auto')
    const pane = memberPaneDefinition({ source: src, id: 'u_member-pane-p3' })
    const o = pane.translation.outputs.find((x) => x && x.ast)
    const d = pane.definition
    let fin = null; let tail = null
    if (o) {
      for (const opts of [{ tf: 'D' }, { tf: 'D', newestBarIsForming: false, historyFromListing: true }]) {
        try { const v = Array.from(interpret(o.ast, bars, {}, undefined, undefined, opts)); fin = (fin ? fin + ' / ' : '') + v.filter(Number.isFinite).length; tail = v.slice(-3) } catch (e) { fin = String(e.message).slice(0, 80) }
      }
    }
    console.log('##', k, '| import', rep.outcome.verdict, (rep.refusal && rep.refusal.guard) || '', '| host formula', o && o.formula, '| finite', fin, JSON.stringify(tail))
    if (d) console.log('   plot', JSON.stringify(d.plots[0]).replace(/"ast":\{.*?\}\}?,/, '').slice(0, 400), '| inputs', JSON.stringify(d.inputs).slice(0, 300))
  }
})
