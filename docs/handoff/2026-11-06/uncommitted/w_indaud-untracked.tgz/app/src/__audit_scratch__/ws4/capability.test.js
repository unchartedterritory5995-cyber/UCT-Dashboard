// WS4 AUDIT SCRATCH — NOT FOR COMMIT. Drives formulas through the real authoring
// door (`evaluateFormula`) and the real client interpreter, then records results
// to JSON for the Python lane harness (capability_py.py).
import { describe, it, expect } from 'vitest'
import fs from 'node:fs'
import path from 'node:path'
import { evaluateFormula } from '../../components/chart/builder/FormulaField'
import { interpret } from '../../components/chart/engine/ast/interpret.js'
import { treeOutputType } from '../../components/chart/engine/outputType'
import { fromSource } from '../../components/chart/builder/criteria'

const OUT = path.join(process.cwd(), 'src', '__audit_scratch__', 'ws4')

// deterministic daily bars (LCG), 400 bars, date-keyed like /api/bars tf=D
function makeBars(n = 400) {
  let s = 12345
  const rnd = () => { s = (s * 1103515245 + 12345) % 2147483648; return s / 2147483648 }
  const out = []
  let c = 100
  const d0 = Date.UTC(2024, 0, 2)
  let day = 0
  while (out.length < n) {
    const dt = new Date(d0 + day * 86400000); day += 1
    if (dt.getUTCDay() === 0 || dt.getUTCDay() === 6) continue
    const o = c * (1 + (rnd() - 0.5) * 0.01)
    c = o * (1 + (rnd() - 0.48) * 0.03)
    const h = Math.max(o, c) * (1 + rnd() * 0.01)
    const l = Math.min(o, c) * (1 - rnd() * 0.01)
    out.push({ t: dt.toISOString().slice(0, 10), o: +o.toFixed(2), h: +h.toFixed(2), l: +l.toFixed(2), c: +c.toFixed(2), v: Math.round(1e6 * (0.5 + rnd())) })
  }
  return out
}
export const BARS = makeBars()

export const CASES = [
  // operands
  ['operand', 'close'], ['operand', 'open + high + low + volume'],
  ['operand', 'hl2'], ['operand', 'hlc3'], ['operand', 'ohlc4'], ['operand', '(high + low) / 2'],
  ['operand', 'dayofweek'], ['operand', 'barindex'], ['operand', 'vwap()'],
  // arithmetic / operators
  ['operator', 'close * 2 - open / 3'], ['operator', '-close'], ['operator', 'close % 2'],
  ['operator', 'mod(close, 2)'], ['operator', 'close ** 2'], ['operator', 'pow(close, 2)'],
  ['operator', 'abs(close - open)'], ['operator', 'max(close, open)'],
  // comparisons / boolean
  ['compare', 'close > open'], ['compare', 'close >= open'], ['compare', 'close == open'], ['compare', 'close != open'],
  ['boolean', 'close > open && volume > 1000000'], ['boolean', 'close > open || volume > 1000000'],
  ['boolean', '!(close > open)'], ['boolean', 'close > open and volume > 0'], ['boolean', 'not (close > open)'],
  ['boolean', 'true'], ['boolean', 'close > open == true'],
  // conditional
  ['ternary', 'close > open ? close : open'], ['ternary', 'close > open ? 1 : 0'],
  ['ternary', 'iff(close > open, 1, 0)'], ['ternary', 'close > open ? (volume > 1e6 ? 2 : 1) : 0'],
  // crossings
  ['cross', 'crossOver(ema(close, 9), ema(close, 20))'], ['cross', 'crossUnder(close, sma(close, 50))'],
  ['cross', 'crossover(close, sma(close, 50))'], ['cross', 'cross(close, sma(close, 50))'],
  ['cross', 'close > sma(close, 50) && close[1] <= sma(close, 50)[1]'],
  // history
  ['history', 'close[1]'], ['history', 'close - close[5]'], ['history', '(close > open)[1]'],
  ['history', 'sma(close, 20)[3]'], ['history', 'close[-1]'], ['history', 'close[1][1]'],
  ['history', 'barsAgo(close, barssince(close > open, 50), 50)'], ['history', 'close[barindex]'],
  // aggregations / windows
  ['aggregate', 'sum(volume, 20)'], ['aggregate', 'highest(high, 252)'], ['aggregate', 'lowest(low, 20)'],
  ['aggregate', 'cum(volume)'], ['aggregate', 'barssince(close > open, 50)'], ['aggregate', 'valuewhen(close > open, close, 50)'],
  ['aggregate', 'highestbars(high, 20)'], ['aggregate', 'change(close)'], ['aggregate', 'rising(close, 3)'], ['aggregate', 'falling(close, 3)'],
  ['aggregate', 'sum(close > open, 10) >= 7'],
  // moving averages
  ['ma', 'sma(close, 20)'], ['ma', 'ema(close, 20)'], ['ma', 'wma(close, 20)'], ['ma', 'rma(close, 20)'],
  ['ma', 'hma(close, 20)'], ['ma', 'vwma(close, 20)'], ['ma', 'dema(close, 20)'], ['ma', 'tema(close, 20)'],
  ['ma', 'alma(close, 9, 0.85, 6)'], ['ma', 'kama(close, 10)'], ['ma', 'zlema(close, 20)'], ['ma', 'smma(close, 20)'],
  ['ma', 'sma(close, 200)'], ['ma', 'ema(close, 200)'], ['ma', 'sma(close, 960)'], ['ma', 'sma(close, 1000)'],
  ['ma', 'sma(close, 252 * 4)'],
  // statistical
  ['stat', 'stdev(close, 20)'], ['stat', 'dev(close, 20)'], ['stat', 'median(close, 20)'],
  ['stat', 'percentrank(close, 100)'], ['stat', 'percentileLinearInterpolation(close, 100, 90)'],
  ['stat', 'correlation(close, volume, 20)'], ['stat', 'linreg(close, 20, 0)'], ['stat', 'variance(close, 20)'],
  ['stat', '(close - sma(close, 20)) / stdev(close, 20)'], ['stat', 'zscore(close, 20)'],
  // indicator functions
  ['indicator', 'rsi(close, 14)'], ['indicator', 'macd(close, 12, 26)'], ['indicator', 'ema(macd(close, 12, 26), 9)'],
  ['indicator', 'atr(high, low, close, 14)'], ['indicator', 'adx(high, low, close, 14)'], ['indicator', 'stoch(high, low, close, 14)'],
  ['indicator', 'cci(high, low, close, 20)'], ['indicator', 'mfi(high, low, close, volume, 14)'], ['indicator', 'bbw(close, 20, 2)'],
  ['indicator', 'sma(close, 20) + 2 * stdev(close, 20)'], ['indicator', 'kcUpper(close, 20, 2)'], ['indicator', 'obv'],
  ['indicator', 'obvN(20)'], ['indicator', 'supertrend(3, 10)'], ['indicator', 'roc(close, 10)'], ['indicator', 'mom(close, 10)'],
  ['indicator', 'accum(0, self + volume * sign(change(close)), 250)'],
  // MTF / cross-symbol
  ['mtf', "tf(close, 'W')"], ['mtf', "tf(sma(close, 10), 'W')"], ['mtf', "close > tf(sma(close, 10), 'W')"],
  ['mtf', "tf(close, 'M')"], ['mtf', "tf(close, '60')"], ['mtf', "ltf(close, '60')"],
  ['xsym', "sym('SPY', close)"], ['xsym', "close / sym('SPY', close)"], ['xsym', "sym('QQQ', close > sma(close, 50))"],
  ['xsym', "sym('AAPL', close)"],
  // nesting
  ['nested', 'ema(rsi(close, 14), 9)'], ['nested', 'sma(sma(sma(close, 10), 10), 10)'],
  ['nested', 'rsi(ema(close, 5), 14) > 50 && adx(high, low, close, 14) > 25'],
  // let / reuse
  ['let', 'let fast = ema(close, 9)\nlet slow = ema(close, 20)\nfast > slow'],
  ['let', 'let x = close\nlet x = open\nx'], ['let', 'let close2 = close * 2\nclose2 + y'],
  ['let', 'fast = ema(close, 9)\nfast'],
  // UDF
  ['udf', 'f(x) = x * 2\nf(close)'], ['udf', 'function f(x) { return x * 2 }'],
  // fundamentals / scalars
  ['fund', 'market_cap > 1e9'], ['fund', 'pe_ttm < 20 && close > sma(close, 50)'], ['fund', 'market_cap'],
  ['fund', 'rs_rank >= 80 && above_50sma'], ['fund', 'cpi'], ['fund', 'gdp_growth > 2'],
  // text / symbol info
  ['text', "text_startswith(syminfo('ticker'), 'A')"],
  // owner examples
  ['owner1', 'ema(close, 9) > ema(close, 20) && volume > sma(volume, 20)'],
  ['owner2', 'rsi(close, 14) > 70 && close > sma(close, 50) && rising(sma(close, 50), 1)'],
  ['owner2b', 'rsi(close, 14) > 70 && close > sma(close, 50) && sma(close, 50) > sma(close, 50)[1]'],
  // budget probe: node count
  ['budget', Array.from({ length: 20 }, (_, i) => `sma(close, ${i + 2})`).join(' + ')],
  ['budget', Array.from({ length: 40 }, (_, i) => `(close > sma(close, ${i + 2}))`).join(' + ')],
  ['budget', Array.from({ length: 40 }, (_, i) => `sma(close, ${i + 2})`).join(' + ')],
  // dialects
  ['pine', '//@version=5\nindicator("x")\nplot(ta.ema(close, 9) > ta.ema(close, 20) ? 1 : 0)'],
  ['thinkscript', 'plot x = ExpAverage(close, 9) > ExpAverage(close, 20);'],
  ['pcf', 'C > AVGC50 AND V > AVGV50'],
  // errors (message quality)
  ['error', 'sma(close)'], ['error', 'sma(close, 20'], ['error', 'smaa(close, 20)'], ['error', 'sma(close, length)'],
  ['error', 'close >'], ['error', 'rsi(close, 0)'], ['error', 'macd(close, 26, 12)'], ['error', 'close.foo'],
  ['error', 'emma(close, 9) > ema(close, 20)'], ['error', 'sma(close, 20.5)'], ['error', 'highest(high, -5)'],
]

function finiteCount(col) { let n = 0; for (const v of col) if (Number.isFinite(v)) n += 1; return n }

describe('WS4 capability harness', () => {
  it('runs every case through the door and the client interpreter', () => {
    const rows = []
    for (const [cat, src] of CASES) {
      const ev = evaluateFormula(src)
      const row = { cat, src, ok: ev.ok, guard: ev.guard, error: ev.error, dialect: ev.dialect,
        readback: ev.readback, repaint: ev.verdict && ev.verdict.mode, measured: ev.measured }
      if (ev.ast) {
        row.ast = ev.ast
        try { row.type = treeOutputType(ev.ast) } catch (e) { row.typeErr = String(e.message) }
      }
      if (ev.ok) {
        try {
          const col = [...interpret(ev.ast, BARS, {}, undefined, {}, { tf: 'D' })]
          row.jsFinite = finiteCount(col)
          row.jsLast = col.slice(-5).map((v) => (Number.isFinite(v) ? +v.toFixed(6) : null))
        } catch (e) { row.jsErr = `${e.guard || ''} ${e.message}` }
        try { const pk = fromSource(src); row.picker = pk && pk.ok !== undefined ? { ok: pk.ok, guard: pk.guard } : { ok: true } } catch (e) { row.picker = { ok: false, guard: e.guard || String(e.message) } }
      }
      rows.push(row)
    }
    fs.writeFileSync(path.join(OUT, 'js_results.json'), JSON.stringify({ bars: BARS, rows }, null, 1))
    expect(rows.length).toBe(CASES.length)
  })
})
