// PA3 scratch PROTOTYPE — NOT COMMITTED, NOT A PROPOSED IMPLEMENTATION FILE.
// Proves the proposed hide/show model + element-granular undo record are
// expressible on today's writers and today's blob, and runs the §7 property
// test against (a) the prototype and (b) the shipped definition toggle.
import { describe, it, expect } from 'vitest'
import * as registry from '../../components/chart/engine/nativeRegistry'
import { mergeChartSettings } from '../../components/chart/chartDefaults'
import {
  addInstance, setIndicatorEnabled, setInstanceInput, setInstanceHidden, removeInstance,
  duplicateInstance, findInstance, withInstances,
} from '../../components/chart/engine/instanceControls'
import { normalizeInstances } from '../../components/chart/engine/instances'
import { isInstanceTombstone } from '../../components/chart/instanceShape'

const log = (...a) => console.log('[PA3-proto]', ...a)
const isLive = (i) => !!i && typeof i === 'object' && !isInstanceTombstone(i)
const liveOf = (cs, defId) => (cs.indicatorInstances || []).filter(i => isLive(i) && (!defId || i.defId === defId))

// ─── the proposed definition-level door: HIDE, never tombstone ───────────────
const VIA = 'hiddenVia'
function defState(cs, defId) {
  const l = liveOf(cs, defId)
  if (!l.length) return 'absent'
  return l.some(i => i.hidden !== true) ? 'shown' : 'hidden'
}
function hideDefinition(cs, defId, reg) {
  const ids = new Set(liveOf(cs, defId).filter(i => i.hidden !== true).map(i => i.instanceId))
  if (!ids.size) return cs
  const next = cs.indicatorInstances.map(i => (isLive(i) && ids.has(i.instanceId) ? { ...i, hidden: true, [VIA]: 'definition' } : i))
  return withInstances(cs, next, reg)               // mirror untouched (existence, not ink)
}
function showDefinition(cs, defId, reg) {
  const l = liveOf(cs, defId)
  if (!l.length) return addInstance(cs, defId, reg)    // ABSENT -> add (unchanged meaning of "on")
  const viaDef = l.filter(i => i.hidden === true && i[VIA] === 'definition')
  const ids = new Set((viaDef.length ? viaDef : l.filter(i => i.hidden === true)).map(i => i.instanceId))
  if (!ids.size) return cs
  const next = cs.indicatorInstances.map(i => {
    if (!isLive(i) || !ids.has(i.instanceId)) return i
    const { [VIA]: _v, ...rest } = i
    return { ...rest, hidden: false }
  })
  return withInstances(cs, next, reg)
}
const toggleDefinition = (cs, defId, reg) =>
  (defState(cs, defId) === 'shown' ? hideDefinition(cs, defId, reg) : showDefinition(cs, defId, reg))
// per-instance eye clears the marker so a later definition-show does not override the member
function setHiddenOne(cs, id, hidden, reg) {
  const n = setInstanceHidden(cs, id, hidden, reg)
  if (n === cs) return cs
  return withInstances(n, n.indicatorInstances.map(i => {
    if (!isLive(i) || i.instanceId !== id || !(VIA in i)) return i
    const { [VIA]: _v, ...rest } = i
    return rest
  }), reg)
}

// ─── element-granular undo record (byte-exact by construction) ──────────────
const TOP_KEYS = ['indicators', 'header', 'volumeOverlayIndicators', 'paneOrder', 'paneSizes', 'preset']
const j = (v) => (v === undefined ? undefined : JSON.stringify(v))
function recordOf(prev, next) {
  const pm = new Map((prev.indicatorInstances || []).map(i => [i.instanceId, i]))
  const nm = new Map((next.indicatorInstances || []).map(i => [i.instanceId, i]))
  const elems = []
  for (const id of new Set([...pm.keys(), ...nm.keys()])) {
    if (j(pm.get(id)) !== j(nm.get(id))) elems.push({ id, before: j(pm.get(id)), after: j(nm.get(id)) })
  }
  const tops = TOP_KEYS.filter(k => j(prev[k]) !== j(next[k])).map(k => ({ k, before: j(prev[k]), after: j(next[k]) }))
  return { elems, tops,
    orderBefore: (prev.indicatorInstances || []).map(i => i.instanceId),
    orderAfter: (next.indicatorInstances || []).map(i => i.instanceId) }
}
function undoRecord(cs, rec) {
  const cur = new Map((cs.indicatorInstances || []).map(i => [i.instanceId, i]))
  for (const e of rec.elems) if (j(cur.get(e.id)) !== e.after) return { ok: false, why: `changed: ${e.id}` }
  for (const t of rec.tops) if (j(cs[t.k]) !== t.after) return { ok: false, why: `changed: ${t.k}` }
  if (j((cs.indicatorInstances || []).map(i => i.instanceId)) !== j(rec.orderAfter)) return { ok: false, why: 'order' }
  const restored = new Map(cur)
  for (const e of rec.elems) { if (e.before === undefined) restored.delete(e.id); else restored.set(e.id, JSON.parse(e.before)) }
  const list = rec.orderBefore.map(id => restored.get(id))
  const out = { ...cs, indicatorInstances: list }
  for (const t of rec.tops) { if (t.before === undefined) delete out[t.k]; else out[t.k] = JSON.parse(t.before) }
  return { ok: true, cs: out }
}

// ─── fixture ─────────────────────────────────────────────────────────────────
function fixture() {
  let cs = mergeChartSettings(null)
  cs = addInstance(cs, 'rsi', registry)
  cs = setInstanceInput(cs, 'inst:rsi:1', 'period', 7, registry)
  cs = duplicateInstance(cs, 'inst:rsi:1', registry)
  cs = setInstanceInput(cs, 'inst:rsi:2', 'period', 21, registry)
  cs = addInstance(cs, 'rsi', registry)
  cs = setInstanceInput(cs, 'inst:rsi:3', 'period', 50, registry)
  cs = setInstanceHidden(cs, 'inst:rsi:3', true, registry)
  cs = addInstance(cs, 'macd', registry)
  return mergeChartSettings(JSON.stringify(cs))
}

describe('PA3 prototype · hide/show model on the three-RSI fixture', () => {
  it('OFF hides the two visible RSIs, keeps the member-hidden one hidden, SHOW restores exactly', () => {
    const cs = fixture()
    const off = hideDefinition(cs, 'rsi', registry)
    expect(defState(off, 'rsi')).toBe('hidden')
    expect(liveOf(off, 'rsi').map(i => i.inputs.period)).toEqual([7, 21, 50])
    const on = showDefinition(off, 'rsi', registry)
    expect(liveOf(on, 'rsi').map(i => i.hidden)).toEqual([false, false, true])
    expect(JSON.stringify(on.indicatorInstances)).toBe(JSON.stringify(cs.indicatorInstances))
  })
  it('an OLD client keeps the marker: normalizeInstances accepts `hiddenVia`, and old writers spread it', () => {
    const off = hideDefinition(fixture(), 'rsi', registry)
    const n = normalizeInstances(off.indicatorInstances, registry)
    expect(n.dropped).toHaveLength(0)
    expect(n.kept.filter(i => i.hiddenVia === 'definition')).toHaveLength(2)
    // an old tab's per-instance eye (shipped setInstanceHidden) keeps hiddenVia on a now-VISIBLE instance
    const oldEye = setInstanceHidden(off, 'inst:rsi:1', false, registry)
    const r1 = findInstance(oldEye, 'inst:rsi:1')
    log('old-tab eye leaves', JSON.stringify({ hidden: r1.hidden, hiddenVia: r1.hiddenVia }))
    expect(r1.hidden).toBe(false)
    // …which is harmless: show only honours hiddenVia on a HIDDEN instance
    // and shipped duplicateInstance would COPY hiddenVia onto the copy (strips only id/display/hidden/group)
    const dup = duplicateInstance(off, 'inst:rsi:1', registry)
    const copy = liveOf(dup, 'rsi').find(i => !['inst:rsi:1', 'inst:rsi:2', 'inst:rsi:3'].includes(i.instanceId))
    log('shipped duplicate copies hiddenVia?', copy.hiddenVia)
    expect(copy.hidden).toBe(false)
  })
  it('undo of a definition hide is BYTE-exact; a stale undo (another write moved a recorded element) is REFUSED', () => {
    const cs = fixture()
    const off = hideDefinition(cs, 'rsi', registry)
    const rec = recordOf(cs, off)
    const u = undoRecord(off, rec)
    expect(u.ok).toBe(true)
    expect(JSON.stringify(u.cs)).toBe(JSON.stringify(cs))
    const moved = setInstanceInput(off, 'inst:rsi:2', 'period', 22, registry)
    expect(undoRecord(moved, rec).ok).toBe(false)
  })
})

// ─── §7 property test ────────────────────────────────────────────────────────
function prng(seed) { let s = seed >>> 0; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 2 ** 32) }
function runProperty(toggle, seeds = 200, steps = 25) {
  const failures = []
  for (let seed = 1; seed <= seeds; seed++) {
    const rnd = prng(seed)
    let cs = fixture()
    const model = new Map(liveOf(cs).map(i => [i.instanceId, JSON.stringify(i.inputs)]))   // id -> inputs that must survive
    const stack = []                               // {rec, before(JSON), modelBefore}
    const trace = []
    for (let step = 0; step < steps; step++) {
      const ids = liveOf(cs).map(i => i.instanceId)
      const pick = (a) => a[Math.floor(rnd() * a.length)]
      const op = pick(['toggle', 'toggle', 'hide', 'show', 'dup', 'remove', 'undo', 'undo'])
      const before = cs
      let next = cs
      if (op === 'toggle') next = toggle(cs, pick(['rsi', 'macd']), registry)
      else if (op === 'hide' && ids.length) next = setHiddenOne(cs, pick(ids), true, registry)
      else if (op === 'show' && ids.length) next = setHiddenOne(cs, pick(ids), false, registry)
      else if (op === 'dup' && ids.length) next = duplicateInstance(cs, pick(ids), registry)
      else if (op === 'remove' && ids.length) { const id = pick(ids); next = removeInstance(cs, id, registry); if (next !== cs) model.delete(id) }
      else if (op === 'undo' && stack.length) {
        const top = stack.pop()
        const u = undoRecord(cs, top.rec)
        if (!u.ok) { failures.push({ seed, step, why: 'undo refused on an untouched stack: ' + u.why, trace }); break }
        if (JSON.stringify(u.cs) !== top.before) { failures.push({ seed, step, why: 'undo not byte-identical', trace }); break }
        cs = u.cs; model.clear(); for (const [k, v] of top.modelBefore) model.set(k, v)
        trace.push('undo'); continue
      }
      trace.push(op)
      if (next !== cs) {
        next = mergeChartSettings(JSON.stringify(next))       // every write is a persisted round trip
        stack.push({ rec: recordOf(before, next), before: JSON.stringify(before), modelBefore: new Map(model) })
        for (const i of liveOf(next)) if (!model.has(i.instanceId) && !liveOf(before).some(b => b.instanceId === i.instanceId)) model.set(i.instanceId, JSON.stringify(i.inputs))
        cs = next
      }
      // INVARIANT: every instance the member did not explicitly remove is live with the same inputs
      for (const [id, inputs] of model) {
        const inst = findInstance(cs, id)
        if (!inst || JSON.stringify(inst.inputs) !== inputs) { failures.push({ seed, step, why: `lost ${id}`, trace: [...trace] }); step = steps; break }
      }
    }
  }
  return failures
}

describe('PA3 prototype · property: no inputs lost except by explicit remove; undo is byte-identical', () => {
  it('PROTOTYPE hide/show toggle: 0 failures over 200 seeded sequences', () => {
    const f = runProperty(toggleDefinition)
    log('prototype failures', f.length, f[0] ? JSON.stringify(f[0]) : '')
    expect(f).toHaveLength(0)
  })
  it('SHIPPED setIndicatorEnabled toggle: fails, with a minimal counterexample', () => {
    const shipped = (cs, defId, reg) => setIndicatorEnabled(cs, defId, !(liveOf(cs, defId).length > 0), reg)
    const f = runProperty(shipped)
    log('shipped failures', f.length, '/ 200; first', f[0] ? JSON.stringify({ seed: f[0].seed, why: f[0].why, trace: f[0].trace }) : '')
    expect(f.length).toBeGreaterThan(0)
  })
})
