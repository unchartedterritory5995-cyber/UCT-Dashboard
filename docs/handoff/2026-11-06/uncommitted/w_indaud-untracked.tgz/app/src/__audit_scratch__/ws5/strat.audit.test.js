import { it } from 'vitest'
import fs from 'node:fs'
import path from 'node:path'
import { memberPaneDefinition } from '../../components/chart/builder/memberPane/memberPaneDefinition.js'
const F = path.resolve(__dirname, '../../../../docs/indicators/audit-2026-10-13/migration-corpus/pine/14-strategy.pine')
it('strategy notes', () => {
  const p = memberPaneDefinition({ source: fs.readFileSync(F, 'utf8'), id: 'u_member-pane-st' })
  console.log('STRAT pane ok', p.ok, 'paneNotes', JSON.stringify(p.notes), 'hostNotes', JSON.stringify((p.translation.notes || []).map((n) => [n.code, String(n.message).slice(0, 140)])), 'disclosures', JSON.stringify(p.definition.meta.disclosures), 'declaration', p.translation.declaration)
})
