import { it } from 'vitest'
import fs from 'node:fs'
import path from 'node:path'
import { inspectSource } from '../../components/chart/builder/PineBox.jsx'
const REPO = path.resolve(__dirname, '../../../..')
it('codes', () => {
  const codes = {}
  const dir = path.join(REPO, 'tests/fixtures/vendor/harness')
  for (const f of fs.readdirSync(dir).filter((x) => x.endsWith('.json'))) {
    let cap; try { cap = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8')) } catch { continue }
    const src = cap && cap.source && cap.source.text
    if (typeof src !== 'string') continue
    const rep = inspectSource(src, 'auto')
    for (const n of rep.ignored || []) {
      const k = n.code || '(none)'
      codes[k] = codes[k] || { n: 0, ex: String(n.message).slice(0, 110) }
      codes[k].n++
    }
  }
  console.log(JSON.stringify(codes, null, 1))
})
