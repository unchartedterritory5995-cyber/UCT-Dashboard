// PA-2 scratch (NOT committed): every vendor capture through both Pine doors,
// recording the note codes each lane emits, which the verdict registry knows,
// which the pane surfaces, and which history-dependent constructs reach a saved
// document. Market values are never read or printed: only codes and counts.
import { it, vi } from 'vitest'
import fs from 'node:fs'
import path from 'node:path'
import { inspectSource } from '../../components/chart/builder/PineBox.jsx'
import { memberPaneDefinition } from '../../components/chart/builder/memberPane/memberPaneDefinition.js'
import { classifyNote } from '../../components/chart/engine/ast/importOutcome.js'
import { definitionWithholdsOffListing } from '../../components/chart/engine/listingDeepen.js'

const REPO = path.resolve(__dirname, '../../../..')
const RES = path.join(REPO, 'docs/indicators/audit-2026-10-13/migration-corpus/results')
const CAPS = path.join(REPO, 'tests/fixtures/vendor/harness')
const OUT = process.env.PA2_OUT
const REGISTERED = new Set(['pine:declaration', 'thinkscript:note-endash', 'thinkscript:note-seed',
  'thinkscript:note-warmup', 'pine:strategy-chart', 'pine:strategy-call'])
const HIST = new Set(['cum', 'isfirst', 'valuewhenOccurrence', 'barindex'])

function names(node, acc) {
  if (!node || typeof node !== 'object') return acc
  if (Array.isArray(node)) { node.forEach((n) => names(n, acc)); return acc }
  if ((node.type === 'call' || node.type === 'series') && typeof node.name === 'string') acc.add(node.name)
  for (const [k, v] of Object.entries(node)) if (k !== 'type' && k !== 'name') names(v, acc)
  return acc
}

it('surface census over the vendor harness', () => {
  vi.stubEnv('VITE_PINE_MEMBER_PANE_ENABLED', '1')
  vi.stubEnv('VITE_PINE_OBJECTS_ONLY_PANE_ENABLED', '1')
  vi.stubEnv('VITE_PINE_RUNTIME_PANE_ENABLED', '0')
  const verdicts = JSON.parse(fs.readFileSync(path.join(RES, 'ws5-vendor-harness-prodflags-verdicts.json'), 'utf8'))
  const rows = []
  for (const r of verdicts.results) {
    let cap
    try { cap = JSON.parse(fs.readFileSync(path.join(CAPS, path.basename(r.file)), 'utf8')) } catch { continue }
    const src = cap && cap.source && (cap.source.text || cap.source)
    if (typeof src !== 'string') continue
    let box; try { box = inspectSource(src, 'auto') } catch { box = null }
    let pane; try { pane = memberPaneDefinition({ source: src, id: 'u_member-pane-pa2s' }) } catch { pane = { ok: false } }
    const t = pane.translation || {}
    const boxCodes = ((box && box.ignored) || []).map((n) => n.code || '(none)')
    const hostCodes = (t.notes || []).map((n) => n.code || '(none)')
    const boxVendor = ((box && box.outputs) || []).flatMap((o) => (o.vendorNotes || []).map((v) => v.name))
    const treeNames = new Set()
    let switched = false
    if (pane.ok && pane.definition) {
      const d = pane.definition
      names(d.compute, treeNames); names(d.objects || null, treeNames); names(d.paints || null, treeNames)
      switched = definitionWithholdsOffListing(d)
    }
    const div = (r.plots || []).filter((p) => p.title !== 'objects' && p.verdict === 'DIVERGE')
    rows.push({
      file: path.basename(r.file),
      harness: r.verdict,
      divKinds: div.map((p) => (String(p.reason).match(/\((na|value|color)[: ]/) || [])[1] || 'other'),
      box: box && box.outcome ? box.outcome.verdict : 'THREW',
      boxReason: box && box.outcome && box.outcome.reason ? String(box.outcome.reason).slice(0, 70) : null,
      boxCodes,
      boxUnregistered: boxCodes.filter((c) => !REGISTERED.has(c)),
      boxUnregisteredNonInfo: ((box && box.ignored) || []).filter((n) => !REGISTERED.has(n.code) && classifyNote(n) === 'presentation').length,
      boxSemantic: box && box.outcome ? box.outcome.semantic.length : 0,
      boxVendor,
      pane: !!pane.ok,
      paneGuard: pane.ok ? null : (pane.guard || null),
      hostCodes,
      paneNotes: (pane.notes || []).length,
      reqTags: pane.requirementTags || [],
      repaint: pane.ok && pane.definition && pane.definition.meta ? pane.definition.meta.repaint || null : null,
      hist: [...treeNames].filter((n) => HIST.has(n)),
      switched,
    })
  }
  fs.writeFileSync(path.join(OUT, 'surface.json'), JSON.stringify(rows))
  console.log('PA2 rows', rows.length)
}, 600000)
