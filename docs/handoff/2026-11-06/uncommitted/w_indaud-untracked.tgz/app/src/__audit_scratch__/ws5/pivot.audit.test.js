import { it } from 'vitest'
import { memberPaneDefinition } from '../../components/chart/builder/memberPane/memberPaneDefinition.js'
import { interpret } from '../../components/chart/engine/ast/interpret.js'
import { makeBars } from './refs.js'
const L = String.fromCharCode(10)
const bars = makeBars(1500, 7)
it('pivot no lookahead', () => {
  const src = ['//@version=5', 'indicator("p", overlay = true)', 'plot(ta.pivothigh(high, 5, 5), "P", style = plot.style_circles)'].join(L)
  const pane = memberPaneDefinition({ source: src, id: 'u_member-pane-piv' })
  const o = pane.translation.outputs.find((x) => x && x.ast)
  const v = Array.from(interpret(o.ast, bars, {}, undefined, undefined, { tf: 'D' }))
  const ref = bars.map((b, i) => {
    if (i < 10) return NaN
    const c = i - 5; const h = bars[c].h
    for (let k = 1; k <= 5; k++) { if (!(h > bars[c - k].h) || !(h > bars[c + k].h)) return NaN }
    return h
  })
  let agree = 0; let dis = 0
  for (let i = 0; i < bars.length; i++) { const a = v[i]; const b = ref[i]; if ((Number.isFinite(a) === Number.isFinite(b)) && (!Number.isFinite(a) || a === b)) agree++; else dis++ }
  // truncation test: value at bar i must not change when future bars are removed
  let changed = 0
  for (const cut of [400, 777, 1200]) {
    const w = Array.from(interpret(o.ast, bars.slice(0, cut), {}, undefined, undefined, { tf: 'D' }))
    for (let i = 0; i < cut; i++) if (!(w[i] === v[i] || (Number.isNaN(w[i]) && Number.isNaN(v[i])))) changed++
  }
  console.log('PIVOT formula', o.formula, 'agree', agree, 'disagree', dis, 'valuesChangedByTruncation', changed, 'style', JSON.stringify(pane.definition.plots[0].style))
})
