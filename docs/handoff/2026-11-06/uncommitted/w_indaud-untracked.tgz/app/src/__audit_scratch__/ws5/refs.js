// WS5 audit scratch (NOT committed): synthetic bars + INDEPENDENT reference
// implementations of the corpus maths, written from Pine's documented semantics
// (bar-by-bar, na-aware), sharing no code with the engine.

export function makeBars(n, seed) {
  let s = seed >>> 0
  const rnd = () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296 }
  const out = []
  // weekdays only, 14:30 UTC, starting Mon 2019-01-07
  let t = Date.UTC(2019, 0, 7, 14, 30) / 1000
  let price = 100
  while (out.length < n) {
    const dow = new Date(t * 1000).getUTCDay()
    if (dow !== 0 && dow !== 6) {
      const drift = (rnd() - 0.48) * 0.03
      const o = price * (1 + (rnd() - 0.5) * 0.01)
      const c = Math.max(1, o * (1 + drift))
      const h = Math.max(o, c) * (1 + rnd() * 0.015)
      const l = Math.min(o, c) * (1 - rnd() * 0.015)
      const v = Math.round(1e6 * (0.5 + rnd() * (rnd() < 0.05 ? 6 : 1.5)))
      out.push({ t, o, h, l, c, v })
      price = c
    }
    t += 86400
  }
  return out
}

const NA = NaN
const isNa = (x) => !Number.isFinite(x)
const col = (bars, k) => bars.map((b) => b[k])

export function sma(src, n) {
  const out = new Array(src.length).fill(NA)
  for (let i = n - 1; i < src.length; i++) {
    let s = 0; let ok = true
    for (let j = i - n + 1; j <= i; j++) { if (isNa(src[j])) { ok = false; break } s += src[j] }
    if (ok) out[i] = s / n
  }
  return out
}
function recursive(src, n, alpha) {
  // Pine: na until n valid values, seeded with their SMA, then alpha-step
  const out = new Array(src.length).fill(NA)
  let prev = NA; let buf = []
  for (let i = 0; i < src.length; i++) {
    const x = src[i]
    if (isNa(prev)) {
      if (isNa(x)) { buf = []; continue }
      buf.push(x)
      if (buf.length === n) { prev = buf.reduce((a, b) => a + b, 0) / n; out[i] = prev }
    } else {
      if (isNa(x)) { out[i] = NA; continue }
      prev = alpha * x + (1 - alpha) * prev
      out[i] = prev
    }
  }
  return out
}
export const ema = (src, n) => recursive(src, n, 2 / (n + 1))
export const rma = (src, n) => recursive(src, n, 1 / n)
export function wma(src, n) {
  const out = new Array(src.length).fill(NA)
  const den = n * (n + 1) / 2
  for (let i = n - 1; i < src.length; i++) {
    let s = 0
    for (let j = 0; j < n; j++) s += src[i - j] * (n - j)
    out[i] = s / den
  }
  return out
}
export function stdev(src, n) {
  const m = sma(src, n)
  return src.map((_, i) => {
    if (isNa(m[i])) return NA
    let s = 0
    for (let j = i - n + 1; j <= i; j++) s += (src[j] - m[i]) ** 2
    return Math.sqrt(s / n)
  })
}
export function tr(bars) {
  return bars.map((b, i) => (i === 0 ? b.h - b.l
    : Math.max(b.h - b.l, Math.abs(b.h - bars[i - 1].c), Math.abs(b.l - bars[i - 1].c))))
}
export const atr = (bars, n) => rma(tr(bars), n)
export function rsi(src, n) {
  const up = src.map((x, i) => (i === 0 ? NA : Math.max(x - src[i - 1], 0)))
  const dn = src.map((x, i) => (i === 0 ? NA : Math.max(src[i - 1] - x, 0)))
  const ru = rma(up, n); const rd = rma(dn, n)
  return ru.map((u, i) => {
    const d = rd[i]
    if (isNa(u) || isNa(d)) return NA
    if (d === 0) return 100
    if (u === 0) return 0
    return 100 - 100 / (1 + u / d)
  })
}
export function linreg(src, n, off) {
  return src.map((_, i) => {
    if (i < n - 1) return NA
    let sx = 0; let sy = 0; let sxy = 0; let sxx = 0
    for (let k = 0; k < n; k++) { const x = k; const y = src[i - n + 1 + k]; sx += x; sy += y; sxy += x * y; sxx += x * x }
    const slope = (n * sxy - sx * sy) / (n * sxx - sx * sx)
    const icpt = sy / n - slope * sx / n
    return icpt + slope * (n - 1 - off)
  })
}

function isoWeekKey(t) {
  const d = new Date(t * 1000)
  const day = (d.getUTCDay() + 6) % 7
  const mon = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() - day)
  return mon
}

export const refs = {
  '01-ema-ribbon.pine': (b) => {
    const c = col(b, 'c')
    return { 'EMA Fast': ema(c, 8), 'EMA Mid': ema(c, 21), 'EMA Slow': ema(c, 55) }
  },
  '02-rsi-levels-fill.pine': (b) => ({ RSI: rsi(col(b, 'c'), 14) }),
  '03-macd-histogram.pine': (b) => {
    const c = col(b, 'c')
    const m = ema(c, 12).map((x, i) => x - ema(c, 26)[i])
    const sig = ema(m, 9)
    return { MACD: m, Signal: sig, Histogram: m.map((x, i) => x - sig[i]) }
  },
  '04-bollinger-fill.pine': (b) => {
    const c = col(b, 'c'); const m = sma(c, 20); const s = stdev(c, 20)
    return { Basis: m, Upper: m.map((x, i) => x + 2 * s[i]), Lower: m.map((x, i) => x - 2 * s[i]) }
  },
  '05-supertrend-var.pine': (b) => {
    const a = atr(b, 10)
    const out = []; let up = NA; let dn = NA; let dir = 1
    const ups = []; const dns = []
    for (let i = 0; i < b.length; i++) {
      const hl = (b[i].h + b[i].l) / 2
      const ub = hl - 3 * a[i]; const db = hl + 3 * a[i]
      const up1 = i ? ups[i - 1] : NA; const dn1 = i ? dns[i - 1] : NA
      const c1 = i ? b[i - 1].c : NA
      up = isNa(up1) ? ub : (c1 > up1 ? Math.max(ub, up1) : ub)
      dn = isNa(dn1) ? db : (c1 < dn1 ? Math.min(db, dn1) : db)
      // Pine comparisons with na are false
      if (dir === -1 && b[i].c > dn1) dir = 1
      else if (dir === 1 && b[i].c < up1) dir = -1
      ups.push(up); dns.push(dn)
      out.push(dir === 1 ? up : dn)
    }
    return { Supertrend: out }
  },
  '06-inside-day.pine': (b) => ({
    Inside: b.map((x, i) => (i === 0 ? 0 : (x.h < b[i - 1].h && x.l > b[i - 1].l ? 1 : 0))),
  }),
  '07-rs-vs-spy.pine': (b, spy) => {
    const rs = b.map((x, i) => x.c / spy[i].c * 100)
    return { 'RS Line': rs, 'RS MA': sma(rs, 50) }
  },
  '08-mtf-ema.pine': (b) => {
    // weekly bars from daily, EMA(10) of weekly closes; lookahead_on + [1] =
    // the previous COMPLETED week's EMA on every day of the current week
    const keys = []; const closes = []
    for (const x of b) {
      const k = isoWeekKey(x.t)
      if (!keys.length || keys[keys.length - 1] !== k) { keys.push(k); closes.push(x.c) } else closes[closes.length - 1] = x.c
    }
    const we = ema(closes, 10)
    const idx = new Map(keys.map((k, i) => [k, i]))
    return { 'HTF EMA': b.map((x) => { const i = idx.get(isoWeekKey(x.t)); return i > 0 ? we[i - 1] : NA }) }
  },
  '09-volume-spike-bg.pine': () => ({}),
  '10-atr-trailing-stop.pine': (b) => {
    const a = atr(b, 14); const out = []; let tr0 = NA
    for (let i = 0; i < b.length; i++) {
      const loss = 2.5 * a[i]; const c = b[i].c; const c1 = i ? b[i - 1].c : NA
      if (isNa(tr0)) tr0 = c - loss
      else if (c > tr0 && c1 > tr0) tr0 = Math.max(tr0, c - loss)
      else if (c < tr0 && c1 < tr0) tr0 = Math.min(tr0, c + loss)
      else if (c > tr0) tr0 = c - loss
      else tr0 = c + loss
      out.push(tr0)
    }
    return { Trail: out }
  },
  '11-pivots-labels-lines.pine': (b) => ({ 'SMA 20': sma(col(b, 'c'), 20) }),
  '12-input-heavy.pine': (b) => {
    const m = ema(col(b, 'c'), 30)
    return { MA: m, Upper: m.map((x) => x * 1.015), Lower: m.map((x) => x * 0.985) }
  },
  '13-table-dashboard.pine': () => ({}),
  '14-strategy.pine': (b) => ({ Fast: sma(col(b, 'c'), 10), Slow: sma(col(b, 'c'), 30) }),
  '15-v4-legacy.pine': (b) => {
    const c = col(b, 'c'); const mom = c.map((x, i) => (i >= 10 ? x - c[i - 10] : NA))
    return { Momentum: mom, Signal: sma(mom, 3) }
  },
  '16-missing-function.pine': (b) => {
    const c = col(b, 'c'); const a = linreg(c, 20, 0); const p = linreg(c, 20, 1)
    return { Slope: a.map((x, i) => x - p[i]) }
  },
}
