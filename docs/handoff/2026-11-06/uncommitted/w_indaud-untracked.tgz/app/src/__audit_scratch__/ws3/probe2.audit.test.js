import { it, expect } from 'vitest'
import * as registry from '../../components/chart/engine/nativeRegistry'
import { mergeChartSettings } from '../../components/chart/chartDefaults'
import { addInstance, setIndicatorEnabled, setInstanceInput, isIndicatorEnabled } from '../../components/chart/engine/instanceControls'
it('PROBE: an inst:-id instance loses its edited input across a definition-level toggle off/on', () => {
  let cs = addInstance(mergeChartSettings(null), 'rsi', registry)
  const id = cs.indicatorInstances.find(i => i.defId === 'rsi' && !i.deleted).instanceId
  cs = setInstanceInput(cs, id, 'period', 7, registry)
  cs = setIndicatorEnabled(cs, 'rsi', false, registry)
  cs = setIndicatorEnabled(cs, 'rsi', true, registry)
  const back = mergeChartSettings(JSON.stringify(cs)).indicatorInstances.filter(i => i.defId === 'rsi' && !i.deleted)
  console.log('[WS3] id', id, 'after toggle', JSON.stringify(back))
  expect(back.length).toBe(1)
  expect(back[0].inputs.period).not.toBe(7)
})
