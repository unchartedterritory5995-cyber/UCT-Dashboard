import { it } from 'vitest'
import { inspectSource } from '../../components/chart/builder/PineBox.jsx'
import { memberPaneDefinition } from '../../components/chart/builder/memberPane/memberPaneDefinition.js'
const L = String.fromCharCode(10)
it('modes', () => {
  for (const e of ['request.security(syminfo.tickerid, "W", close, lookahead = barmerge.lookahead_on)', 'request.security(syminfo.tickerid, "W", close)', 'request.security(syminfo.tickerid, "W", close[1], lookahead = barmerge.lookahead_on)']) {
    const src = ['//@version=5', 'indicator("m", overlay = true)', `x = ${e}`, 'plot(x, "X")'].join(L)
    const pane = memberPaneDefinition({ source: src, id: 'u_member-pane-mtf' })
    const rep = inspectSource(src, 'auto')
    console.log('EXPR', e)
    console.log('  rows', JSON.stringify(pane.definition.plots.map((p) => [p.label, p.mode, p.readback])))
    console.log('  defmode', JSON.stringify(pane.definition.compute && { mode: pane.definition.compute.mode, repaint: pane.definition.compute.repaint, meta: pane.definition.meta }))
    console.log('  notes', JSON.stringify(pane.notes))
    console.log('  semantic', JSON.stringify(rep.outcome.semantic))
    console.log('  downstream', JSON.stringify(rep.outputs[0].downstream && { ok: rep.outputs[0].downstream.ok, readback: rep.outputs[0].downstream.readback, verdict: rep.outputs[0].downstream.verdict }))
  }
})
