// WS4 AUDIT SCRATCH — NOT FOR COMMIT. Owner examples end-to-end through the
// definition builder, schema, type authority and the shared evaluability gate.
import { describe, it, expect } from 'vitest'
import fs from 'node:fs'
import path from 'node:path'
import { buildDefinition } from '../../components/chart/builder/BuilderSheet'
import { BUILDER_INPUTS } from '../../components/chart/builder/builderInputs'
import { evaluateFormula } from '../../components/chart/builder/FormulaField'
import { signalPaintsFor, presentationVerdict, intentReadback, INTENTS } from '../../components/chart/builder/authoringIntent'
import { validateDefinition } from '../../components/chart/engine/defSchema'
import { outputsOf } from '../../components/chart/engine/outputType'
import { evaluability, LANES } from '../../components/chart/engine/evaluability'
import { signalAlertGate, numericAlertGate } from '../../components/chart/engine/triggerPolicy'
import { infoValueOutputExists } from '../../components/chart/engine/infoValueResolve'

const OUT = path.join(process.cwd(), 'src', '__audit_scratch__', 'ws4')
const LOG = []
const log = (k, v) => LOG.push([k, v])

function rowFor(key, src, extra = {}) {
  const ev = evaluateFormula(src)
  if (!ev.ok) throw new Error(`${src}: ${ev.guard} ${ev.error}`)
  return { key, label: key, source: src, ast: ev.ast, mode: ev.verdict.mode, readback: ev.readback, style: 'line',
    color: '#26a69a', width: 1, ...extra }
}

function lanes(def, key) {
  const o = {}
  for (const lane of Object.values(LANES)) {
    const v = evaluability(def, key, lane, { tf: 'D' })
    o[lane] = v.status + (v.guard ? `:${v.guard}` : '')
  }
  return o
}

describe('WS4 owner examples + consumers', () => {
  it('owner example 1: candles green when 9EMA>20EMA and volume>20d avg', () => {
    const src = 'ema(close, 9) > ema(close, 20) && volume > sma(volume, 20)'
    const row = rowFor('signal', src, { hidden: true })
    const paints = signalPaintsFor('signal', { barcolor: '#00ff00' })
    const def = buildDefinition({ defId: 'u_aaaaaaaaaaaa', name: 'EMA trend w/ volume', source: src, ast: row.ast,
      mode: row.mode, readback: row.readback, plots: [row], paints, inputs: BUILDER_INPUTS })
    const v = validateDefinition(def)
    log('owner1.validate', v.ok ? 'ok' : v.errors)
    log('owner1.paints', def.paints)
    log('owner1.outputs', outputsOf(def))
    log('owner1.lanes', lanes(def, 'signal'))
    log('owner1.presentation', presentationVerdict(def, 'signal', { paints }, { tf: 'D' }))
    log('owner1.signalAlertGate', signalAlertGate(def, 'signal', { tf: 'D' }))
    log('owner1.intent', intentReadback(def, INTENTS.SIGNAL, { ctx: { tf: 'D' } }).status)
    expect(v.ok).toBe(true)
  })

  it('owner example 2: highlight RSI>70 and price above rising 50MA', () => {
    const src = 'rsi(close, 14) > 70 && close > sma(close, 50) && rising(sma(close, 50), 1)'
    const row = rowFor('hot', src, { hidden: true })
    const ma = rowFor('ma50', 'sma(close, 50)', { colorMode: 'column:hot', colorUp: '#ff9800', colorDown: '#2196f3' })
    const paints = signalPaintsFor('hot', { bgcolor: '#ff9800' })
    const def = buildDefinition({ defId: 'u_bbbbbbbbbbbb', name: 'Hot RSI over rising 50', source: src, ast: row.ast,
      mode: row.mode, readback: row.readback, plots: [row, ma], paints, placement: null, inputs: BUILDER_INPUTS })
    const v = validateDefinition(def)
    log('owner2.validate', v.ok ? 'ok' : v.errors)
    log('owner2.plots', def.plots)
    log('owner2.paints', def.paints)
    log('owner2.lanes.hot', lanes(def, 'hot'))
    log('owner2.lanes.ma50', lanes(def, 'ma50'))
    log('owner2.numericAlertGate.ma50', numericAlertGate(def, 'ma50', { tf: 'D' }))
    log('owner2.signalAlertGate.ma50', signalAlertGate(def, 'ma50', { tf: 'D' }))
    log('owner2.infoValue.exists', [infoValueOutputExists(def, 'hot'), infoValueOutputExists(def, 'ma50')])
    expect(v.ok).toBe(true)
  })

  it('a scalar (fundamental) condition: chart/alert vs scan', () => {
    const src = 'market_cap > 1e9 && close > sma(close, 50)'
    const row = rowFor('value', src)
    const def = buildDefinition({ defId: 'u_cccccccccccc', name: 'Big cap above 50', source: src, ast: row.ast,
      mode: row.mode, readback: row.readback, plots: [row], inputs: BUILDER_INPUTS })
    log('scalar.validate', validateDefinition(def).ok)
    log('scalar.lanes', lanes(def, 'value'))
  })

  it('cross-symbol + weekly condition lanes', () => {
    for (const [k, src] of [['xs', "close / sym('SPY', close) > sma(close / sym('SPY', close), 50)"],
      ['wk', "close > tf(sma(close, 10), 'W')"], ['ltf', "ltf(close, '60') > open"]]) {
      const ev = evaluateFormula(src)
      log(`${k}.eval`, ev.ok ? 'ok' : `${ev.guard}: ${ev.error}`)
      if (!ev.ok) continue
      const row = { key: 'value', label: k, source: src, ast: ev.ast, mode: ev.verdict.mode, readback: ev.readback, style: 'line', color: '#fff', width: 1 }
      const def = buildDefinition({ defId: 'u_dddddddddddd', name: k, source: src, ast: ev.ast, mode: ev.verdict.mode,
        readback: ev.readback, plots: [row], inputs: BUILDER_INPUTS })
      log(`${k}.lanes`, lanes(def, 'value'))
    }
  })

  it('inputs: window vs threshold', () => {
    const scope = { color: true, lineWidth: true, len: true, lvl: true }
    for (const src of ['sma(close, len)', 'rsi(close, 14) > lvl', 'close > sma(close, 20) * (1 + lvl / 100)']) {
      const ev = evaluateFormula(src, scope)
      log(`input:${src}`, ev.ok ? `ok ${ev.readback}` : `${ev.guard}: ${ev.error}`)
    }
  })

  it('let-bound reuse inflates node budget (sugar inlines)', () => {
    const lets = 'let a = ema(close, 9) - ema(close, 21)\nlet b = sma(a, 5)\nlet c = a - b\n'
    const body = Array.from({ length: 12 }, (_, i) => `(c > ${i})`).join(' + ')
    const ev = evaluateFormula(lets + body)
    log('let.budget', ev.ok ? `ok ${JSON.stringify(ev.measured)}` : `${ev.guard}: ${ev.error}`)
    const one = evaluateFormula(lets + 'c')
    log('let.single', one.ok ? JSON.stringify(one.measured) : one.error)
  })

  it('writes log', () => {
    fs.writeFileSync(path.join(OUT, 'consumers_log.json'), JSON.stringify(LOG, null, 1))
  })
})
