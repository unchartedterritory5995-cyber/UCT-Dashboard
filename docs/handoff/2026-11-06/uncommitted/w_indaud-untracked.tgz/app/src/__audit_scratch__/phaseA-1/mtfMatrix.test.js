// PHASE A-1 probe: thinkScript secondary aggregation composed with functions/offsets.
// Synthetic bars only. Real Import-tab entry point: PineBox.inspectSource(src, 'thinkscript').
import { it, expect } from 'vitest'
import fs from 'fs'
import { inspectSource } from '../../components/chart/builder/PineBox.jsx'
import { interpret } from '../../components/chart/engine/ast/interpret.js'
import { parseFormula } from '../../components/chart/engine/ast/parse.js'
import TABLE from '../../components/chart/engine/ast/closedTable.json'
import { B } from './bars.js'
import { mtfShapes } from './detect.js'

const N = B.length
const C = B.map((b) => b.c)
const TAIL = 120
const wkKey = (t) => { const d = new Date(t * 1000); const day = (d.getUTCDay() + 6) % 7; return Math.floor((t - day * 86400) / 86400 / 7) }
const moKey = (t) => { const d = new Date(t * 1000); return d.getUTCFullYear() * 12 + d.getUTCMonth() }

function imp(src) {
  const r = inspectSource(src, 'thinkscript')
  const o = (r.outputs || [])[r.selected >= 0 ? r.selected : 0] || {}
  const ast = o.ast || (o.downstream && o.downstream.ast) || null
  return { r, o, ast }
}
const run = (ast) => (ast ? [...interpret(ast, B, {}, undefined, {})] : null)
const eq = (a, b) => (Number.isFinite(a) && Number.isFinite(b) ? Math.abs(a - b) <= 1e-9 * Math.max(1, Math.abs(b)) : (!Number.isFinite(a) && !Number.isFinite(b)))
function agree(x, y) {
  if (!x || !y) return null
  let n = 0, both = 0, maxRel = 0
  for (let i = N - TAIL; i < N; i++) {
    if (eq(x[i], y[i])) n++
    if (Number.isFinite(x[i]) && Number.isFinite(y[i])) { both++; maxRel = Math.max(maxRel, Math.abs(x[i] - y[i]) / Math.max(1e-12, Math.abs(y[i]))) }
  }
  return { agree: `${n}/${TAIL}`, maxRelPct: +(maxRel * 100).toFixed(2) }
}
const strip = (s) => s.replace(/\(\s*period\s*=\s*AggregationPeriod\.(WEEK|MONTH)\s*\)/g, '')
const wrap = (ast, type, code) => (ast ? { type, value: code, args: [ast] } : null)

// independent references (no engine): weekly SMA10 closed / forming, previous-week close
function periodClose(key) {
  const k = B.map((b) => key(b.t)); const closes = []; const idx = []
  for (let i = 0; i < N; i++) { if (i === N - 1 || k[i + 1] !== k[i]) closes.push(C[i]); idx.push(closes.length - (i === N - 1 || k[i + 1] !== k[i] ? 1 : 0)) }
  return { k, closes, idx }
}
function indepSma(n, mode, key = wkKey) {
  const k = B.map((b) => key(b.t))
  return B.map((_, i) => {
    let done = 0; for (let j = 0; j < i; j++) if (k[j + 1] !== k[j]) done++
    const finals = []; for (let j = 0; j < N; j++) if (j === N - 1 || k[j + 1] !== k[j]) finals.push(C[j])
    const prior = finals.slice(0, done)
    const s = mode === 'forming' ? [...prior, C[i]] : prior
    if (s.length < n) return NaN
    return s.slice(-n).reduce((a, b) => a + b) / n
  })
}
function indepPrevWeekClose() {
  const k = B.map((b) => wkKey(b.t)); const finals = []; for (let j = 0; j < N; j++) if (j === N - 1 || k[j + 1] !== k[j]) finals.push(C[j])
  return B.map((_, i) => { let done = 0; for (let j = 0; j < i; j++) if (k[j + 1] !== k[j]) done++; return done >= 1 ? finals[done - 1] : NaN })
}

const W = 'AggregationPeriod.WEEK', M = 'AggregationPeriod.MONTH'
const CASES = [
  ['bare close(W)', `plot p = close(period = ${W});`, { code: 'W' }],
  ['bare high(M)', `plot p = high(period = ${M});`, { code: 'M' }],
  ['Average', `plot p = Average(close(period = ${W}), 10);`, { code: 'W' }],
  ['SimpleMovingAvg study', `plot p = SimpleMovingAvg(close(period = ${W}), 10);`, { code: 'W' }],
  ['ExpAverage', `plot p = ExpAverage(close(period = ${W}), 10);`, { code: 'W' }],
  ['WildersAverage', `plot p = WildersAverage(close(period = ${W}), 10);`, { code: 'W' }],
  ['Highest(high W)', `plot p = Highest(high(period = ${W}), 10);`, { code: 'W' }],
  ['Lowest(low W)', `plot p = Lowest(low(period = ${W}), 10);`, { code: 'W' }],
  ['Sum(volume W)', `plot p = Sum(volume(period = ${W}), 4);`, { code: 'W' }],
  ['StDev', `plot p = StDev(close(period = ${W}), 10);`, { code: 'W' }],
  ['RSI(price=W)', `plot p = RSI(price = close(period = ${W}), length = 14);`, { code: 'W' }],
  ['BollingerBands(price=W).UpperBand', `plot p = BollingerBands(price = close(period = ${W}), length = 20).UpperBand;`, { code: 'W' }],
  ['MovingAverage(SIMPLE)', `plot p = MovingAverage(AverageType.SIMPLE, close(period = ${W}), 10);`, { code: 'W' }],
  ['MovingAverage(EXPONENTIAL)', `plot p = MovingAverage(AverageType.EXPONENTIAL, close(period = ${W}), 10);`, { code: 'W' }],
  ['offset [1]', `plot p = close(period = ${W})[1];`, { code: 'W' }],
  ['offset [2] of M', `plot p = close(period = ${M})[2];`, { code: 'M' }],
  ['weekly change', `plot p = close(period = ${W}) - close(period = ${W})[1];`, { code: 'W' }],
  ['weekly arithmetic in fn', `plot p = Average(close(period = ${W}) - open(period = ${W}), 10);`, { code: 'W' }],
  ['Average(..)[1]', `plot p = Average(close(period = ${W}), 10)[1];`, { code: 'W' }],
  ['Highest(close W [1])', `plot p = Highest(close(period = ${W})[1], 10);`, { code: 'W' }],
  ['nested Average(Average)', `plot p = Average(Average(close(period = ${W}), 5), 2);`, { code: 'W' }],
  ['via def', `def w = close(period = ${W});\nplot p = Average(w, 10);`, { code: 'W' }],
  ['via input', `input agg = ${W};\nplot p = Average(close(period = agg), 10);`, { code: 'W', stripSrc: 'plot p = Average(close, 10);' }],
  ['MONTH ExpAverage', `plot p = ExpAverage(close(period = ${M}), 6);`, { code: 'M' }],
  ['volume W > Average(volume W)', `plot p = volume(period = ${W}) > Average(volume(period = ${W}), 10);`, { code: 'W' }],
  // mixed daily + weekly
  ['mix ratio daily/weekly', `plot p = close / close(period = ${W});`, { native: "close / tf(close, 'W')", nativeF: "close / tf_live(close, 'W')" }],
  ['daily crosses weekly avg', `plot p = close crosses above Average(close(period = ${W}), 10);`, { native: "crossOver(close, tf(sma(close, 10), 'W'))", nativeF: "crossOver(close, tf_live(sma(close, 10), 'W'))" }],
  ['weekly crosses weekly avg', `plot p = close(period = ${W}) crosses above Average(close(period = ${W}), 10);`, { code: 'W' }],
  ['mixed inside fn', `plot p = Average(close - close(period = ${W}), 10);`, { native: null }],
  ['daily > weekly avg', `plot p = close > Average(close(period = ${W}), 10);`, { native: "close > tf(sma(close, 10), 'W')", nativeF: "close > tf_live(sma(close, 10), 'W')" }],
]

it('MTF matrix', () => {
  const rows = []
  for (const [name, src, how] of CASES) {
    const { r, o, ast } = imp(src)
    let refC = null, refF = null, liftedFormula = null
    if (how.code) {
      const s = imp(how.stripSrc || strip(src))
      refC = wrap(s.ast, 'tf', how.code); refF = wrap(s.ast, 'tf_live', how.code)
      liftedFormula = s.o.formula ? `tf(${s.o.formula}, '${how.code}')` : null
    } else if (how.native) {
      refC = parseFormula(how.native).ast; refF = parseFormula(how.nativeF).ast; liftedFormula = how.native
    }
    const vi = run(ast)
    let vC = null, vF = null, errC = null
    try { vC = run(refC) } catch (e) { errC = String(e.message).slice(0, 120) }
    try { vF = run(refF) } catch (e) { errC = (errC || '') + ' F:' + String(e.message).slice(0, 120) }
    rows.push({
      name, ok: r.ok, formula: o.formula || null, outcome: r.outcome && r.outcome.verdict, reason: r.outcome && r.outcome.reason,
      semanticNotes: r.outcome && r.outcome.parts ? (r.outcome.parts.semantic || []).map((s) => s.name) : null,
      refusal: r.refusal ? `${r.refusal.guard}: ${String(r.refusal.message).slice(0, 140)}` : null,
      shapes: ast ? mtfShapes(ast, TABLE).map((s) => s.shape + (s.fn ? ':' + s.fn : '')) : [],
      liftedFormula, vsClosedLift: agree(vi, vC), vsFormingLift: agree(vi, vF), refErr: errC,
    })
  }
  // independent value checks of the PROPOSED trees
  const sma10C = run(parseFormula("tf(sma(close, 10), 'W')").ast)
  const sma10F = run(parseFormula("tf_live(sma(close, 10), 'W')").ast)
  const prevWk = indepPrevWeekClose()
  const checks = {
    'tf(sma(close,10),W) vs independent closed-week SMA10': agree(sma10C, indepSma(10, 'closed')),
    'tf_live(sma(close,10),W) vs independent forming-week SMA10': agree(sma10F, indepSma(10, 'forming')),
    'CURRENT import sma(tf(close,W),10) vs independent closed-week SMA10': agree(run(imp(`plot p = Average(close(period = ${W}), 10);`).ast), indepSma(10, 'closed')),
    'CURRENT import vs independent forming-week SMA10': agree(run(imp(`plot p = Average(close(period = ${W}), 10);`).ast), indepSma(10, 'forming')),
    'tf(close,W) vs independent previous-week close': agree(run(parseFormula("tf(close, 'W')").ast), prevWk),
    'tf_live(close[1],W) vs independent previous-week close': agree(run(parseFormula("tf_live(close[1], 'W')").ast), prevWk),
    'CURRENT import tf(close,W)[1] vs independent previous-week close': agree(run(imp(`plot p = close(period = ${W})[1];`).ast), prevWk),
    'tf(sma(close,10),W) == tf_live(sma(close,10)[1],W)': agree(sma10C, run(parseFormula("tf_live(sma(close, 10)[1], 'W')").ast)),
    'tf(sma,M6) vs independent closed-month SMA6': agree(run(parseFormula("tf(sma(close, 6), 'M')").ast), indepSma(6, 'closed', moKey)),
  }
  // does the linter badge tf_live as repainting? (alert/scan gate consequence)
  const { evaluateFormula } = { evaluateFormula: null }
  fs.writeFileSync('src/__audit_scratch__/phaseA-1/mtfMatrix.json', JSON.stringify({ rows, checks }, null, 1))
  expect(rows.length).toBe(CASES.length)
})
