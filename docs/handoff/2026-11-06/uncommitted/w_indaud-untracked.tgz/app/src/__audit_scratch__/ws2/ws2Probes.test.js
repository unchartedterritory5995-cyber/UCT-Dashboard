// WS2 audit scratch probes — NOT committed. Each probe pins a rendering claim
// against the real modules (no mocks of the module under test).
import { describe, it, expect } from 'vitest'
import { computePaneLayout, paneStretchPlan, paneHeightMismatch } from '../../components/chart/engine/paneLayout'
import { PRICE_PANE, VOLUME_PANE } from '../../components/chart/engine/paneOrder'
import { seriesOptionsForPlot, columnColorsForPlot, poolKey } from '../../components/chart/engine/pool'
import { markersFor } from '../../components/chart/engine/markerPrimitive'
import { validateDefinition } from '../../components/chart/engine/defSchema'
import { presentedPlot, availableStyles } from '../../components/chart/engine/presentation'
import { translatePine } from '../../components/chart/engine/ast/pine'

const inst = (defId, instanceId) => ({ defId, instanceId, inputs: {} })
const RSI = inst('rsi', 'inst:rsi:1')
const MACD = inst('macd', 'inst:macd:1')
const opts = (extra) => ({
  chartHeight: 600, hasVolumeBand: false, separatorPx: 1, firstPaneIndex: 2,
  abovePct: [78, 22], mainPaneIndex: 0, ...extra,
})

/** A fake chart whose pane heights are exactly what the PLAN assigned. */
const chartFrom = (plan) => ({ panes: () => plan.map((h) => ({ getHeight: () => h, getStretchFactor: () => h })) })

describe('P-A pane height verifier vs reordered / resized panes', () => {
  it('un-arranged: plan applied exactly -> no mismatch (control)', () => {
    const l = computePaneLayout([RSI, MACD], opts())
    const plan = paneStretchPlan(l, new Array(l.paneCountRequired || 4).fill(0))
    expect(paneHeightMismatch(chartFrom(plan), l)).toBe(null)
  })
  it('reordered: plan applied exactly -> verifier still reports a mismatch (positional check)', () => {
    const l = computePaneLayout([RSI, MACD], opts({ order: ['inst:rsi:1', PRICE_PANE, VOLUME_PANE, 'inst:macd:1'] }))
    const plan = paneStretchPlan(l, new Array(l.paneCountRequired || 4).fill(0))
    const msg = paneHeightMismatch(chartFrom(plan), l)
    // record what happens
    console.log('[WS2 P-A] reordered mismatch =', msg)
    expect(typeof msg === 'string' || msg === null).toBe(true)
  })
  it('resized (paneSizes share) -> verifier compares against un-resized stretch', () => {
    const l = computePaneLayout([RSI, MACD], opts({ paneSizes: { 'inst:rsi:1': 0.3 } }))
    const plan = paneStretchPlan(l, new Array(l.paneCountRequired || 4).fill(0))
    const msg = paneHeightMismatch(chartFrom(plan), l)
    console.log('[WS2 P-A] resized mismatch =', msg, 'plan=', JSON.stringify(plan))
    expect(typeof msg === 'string' || msg === null).toBe(true)
  })
})

describe('P-B per-bar colour on AREA plots', () => {
  const area = { key: 'a', style: 'area', color: '#336699', colorMode: 'column:c', colorUp: '#00ff00', colorDown: '#ff0000' }
  it('schema accepts colorMode column on an area plot', () => {
    const def = {
      schemaVersion: 1, id: 'probe-area', name: 'p', kind: 'indicator',
      compute: { kind: 'native', fn: 'x' },
      plots: [area, { key: 'c', style: 'line', hidden: true }],
      placement: { target: 'pane' },
    }
    const r = validateDefinition(def)
    console.log('[WS2 P-B] validate area+colorMode:', r.ok, (r.errors || []).slice(0, 3))
  })
  it('the renderer resolves per-point colours for it, but area series options take lineColor/topColor only', () => {
    expect(poolKey(area)).toBe('area')
    expect(columnColorsForPlot(area)).toMatchObject({ key: 'c', up: '#00ff00', down: '#ff0000' })
    const o = seriesOptionsForPlot(area, {})
    expect(o.lineColor).toBe('#336699')
    // binder.toPoints writes {time, value, color} — LWC AreaData has no `color` field (typings.d.ts AreaData: lineColor/topColor/bottomColor)
  })
  it('a member may re-style a sign-coloured histogram to Area', () => {
    const hist = { key: 'h', style: 'histogram', colorMode: 'sign', colorUp: '#0f0', colorDown: '#f00' }
    expect(availableStyles(hist, { target: 'pane' })).toContain('area')
    const p = presentedPlot(hist, { instanceId: 'x', presentation: { plotStyle: 'area' } }, {})
    expect(p.style).toBe('area')
    expect(p.colorMode).toBe('sign') // sign mode survives onto an area series whose points cannot carry `color`
  })
})

describe('P-C markers ignore palette / gradient / packed colours', () => {
  it('palette marker draws the flat plot colour', () => {
    const plot = { key: 'm', style: 'markers', color: '#aaaaaa', marker: { shape: 'circle' }, colorMode: 'column:k', colorPalette: ['#ff0000', '#00ff00', '#0000ff'] }
    const cc = columnColorsForPlot(plot)
    expect(cc.palette).toHaveLength(3)
    const out = markersFor({ column: [1, 1, 1], times: [1, 2, 3], marker: plot.marker, color: '#aaaaaa',
      condColumn: [0, 1, 2], colorUp: cc.up, colorDown: cc.down })
    expect(out.map((m) => m.color)).toEqual(['#aaaaaa', '#aaaaaa', '#aaaaaa'])
  })
})

describe('P-D Pine style_linebr carries no break', () => {
  it('translated plot is a plain line with no sparse flag', () => {
    const src = '//@version=5\nindicator("t", overlay=true)\nplot(close > open ? close : na, style=plot.style_linebr)\n'
    const t = translatePine(src)
    const plots = (t && (t.plots || (t.presentation && t.presentation.plots) || (t.definition && t.definition.plots))) || null
    console.log('[WS2 P-D] ok=', t && t.ok, 'keys=', t && Object.keys(t).slice(0, 25).join(','))
    const pres = t && t.presentation
    console.log('[WS2 P-D] presentation=', JSON.stringify(pres && (pres.outputs || pres.plots || pres)).slice(0, 600))
    expect(t).toBeTruthy()
  })
})
