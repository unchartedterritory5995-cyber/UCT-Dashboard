# PA4 scratch — NOT COMMITTED. Limitation ledger for the 41 status-2 built-ins.
# cat: CALC CONV VIS CFG REACH TF ACCESS APPROX OTHER-PARITY OTHER-HIST OTHER-LIVE OTHER-DOMAIN
# sev: 1 wrong value, 2 misleading, 3 missing capability, 4 cosmetic
L = []
def a(item, cat, sev, text): L.append((item, cat, sev, text))
a('vwap','PARITY',1,'alert lane anchors at ET midnight over ETH bars; RTH-only chart anchors 09:30 (D-3)')
a('vwap','TF',3,'hidden on 2/3/10/45/65/120/195/240m although offered; pill says "Intraday only" (D-4)')
a('vwap','CALC',1,'one NaN volume blanks the rest of the session (D-8; data-conditional)')
a('stoch','PARITY',2,'new chart instances are slow 14/3/3; alert lane computes fast 14/3 only; disclosed (D-5)')
a('stoch','CONV',4,'%K = 50 on a flat range (Pine: na); documented')
a('stoch','DOMAIN',4,'computeFor kPeriod 0 throws (programmatic writers only; D-10)')
a('avwap','CALC',1,'week/month/quarter/year anchors start at first LOADED bar: partial-period VWAP (D-2)')
a('avwap','CALC',2,'swing anchors = running extreme since first loaded bar; moves with loaded history (D-2)')
a('avwap','TF',3,'only 1/5/15/30/60m (D-4)')
a('avwap','REACH',3,'no alert or screener address; formula avwap() covers the session window only')
a('atrBands','REACH',3,'Python twin exists but no SERIES_FUNCS address')
a('atrBands','CONV',4,'Wilder ATR seed (as atr); documented')
a('movingAverage','REACH',3,'alertable only as close-SMA/EMA via price_vs_ma (period seeded 50, not the instance); 7 MA types and non-close sources not alertable')
a('movingAverage','PARITY',2,'NaN-hole policy: native restarts, formula ema holds / sma skips (D-7; gappy sources only)')
a('movingAverage','LIVE',4,'only SMA/EMA stepped per tick; other 7 types wait for next recompute')
a('dollarVolume','REACH',3,'no alert/formula primitive (chart-only)')
a('rsLine','ACCESS',3,'premium tier')
a('rsLine','CFG',3,'benchmark fixed to SPY/QQQ/IWM')
a('rsLine','REACH',3,'no alert/screener/formula address; no other-timeframe calc')
a('rsLine','CALC',4,'6-dp delivery rounding stair-steps very small ratios (D-12; edge)')
a('volumeProfile','APPROX',2,'whole bar volume to its hlc3 bin; no intra-bar distribution; binning has no unit test (D-11)')
a('volumeProfile','VIS',3,'no up/down split, no value area (VAH/VAL), visible range only; no session/fixed/anchored modes')
a('volumeProfile','REACH',3,'canvas carve-out: no plots grammar, no alerts/formula/legend')
T1 = ['superTrend','aroon','vortex','choppiness','stochRsi','ppo','roc','momentum','tsi','cmo','trix','awesome','ultimate','balanceOfPower','bullBearPower','keltner','envelope','bbPercentB','bbWidth','atrPercent','adrPercent','historicalVolatility','squeeze','relativeVolume','accumDist','chaikinMoneyFlow','chaikinOscillator','forceIndex','pvt','upDownVolume','percentFromMa','fiftyTwoWeek','standardDeviation']
FORMULA = {'aroon','roc','momentum','balanceOfPower','standardDeviation','bbWidth'}
for t in T1:
    a(t,'REACH',3,'chart-only: no alert/screener address' + ('' if t in FORMULA else '; no formula primitive'))
a('superTrend','CONV',4,'Wilder ATR seed vs Pine ta.atr seed (converges); documented')
a('aroon','CONV',4,'tie -> most recent extreme (TA-Lib); documented')
a('stochRsi','CONV',4,'flat RSI range -> 50; documented')
a('roc','CONV',4,'default 12 (TC2000/StockCharts) vs TradingView 9; documented')
a('trix','CONV',2,'x100 %-change of triple EMA (TA-Lib) vs TradingView log x10000: different scale; documented in decision doc only')
a('balanceOfPower','CONV',4,'default SMA-14 smoothing vs TradingView raw; documented')
a('keltner','PARITY',2,'formula kcUpper/kcLower = EMA(TR,n) (Pine ta.kc); chart Keltner = Wilder ATR(10): same name, different bands')
a('keltner','CFG',4,'basis fixed to EMA')
a('keltner','CONV',4,'Wilder ATR seed; documented')
a('bbPercentB','CFG',4,'source fixed to close; SMA basis only')
a('bbWidth','CFG',4,'source fixed to close; SMA basis only')
a('atrPercent','CONV',4,'Wilder ATR seed; documented')
a('adrPercent','CONV',4,'on intraday = per-bar range, not daily range; documented')
a('historicalVolatility','CONV',2,'sample sigma x sqrt(252) vs TradingView population x sqrt(365): TV reads ~17% higher at period 20; documented')
a('historicalVolatility','TF',3,'D/W/M only: hidden on intraday and 2D/3D/5D/2W/3M/6M/12M')
a('squeeze','CONV',4,'generic BB-inside-KC (SMA +/- 1.5 Wilder ATR20), not a vendor TTM clone; documented')
a('relativeVolume','CONV',2,'mean of previous n BARS, not time-of-day: intraday RVOL near the open/pre-market is not comparable to TC2000-style RVOL; documented')
a('accumDist','HIST',4,'cumulative level depends on loaded history (as OBV)')
a('chaikinOscillator','CONV',4,'SMA-seeded EMAs vs TA-Lib first-value seed (converges); documented')
a('pvt','HIST',4,'cumulative level depends on loaded history (as OBV)')
a('fiftyTwoWeek','TF',3,'D/W/M only; needs 364 calendar days loaded')
a('fiftyTwoWeek','CFG',4,'no lookback input; fixed 52 weeks')
import collections, json
items = sorted(set(i for i,*_ in L)); assert len(items)==41, len(items)
byCat = collections.Counter(c for _,c,_,_ in L)
byCatItems = {c: len(set(i for i,cc,_,_ in L if cc==c)) for c in byCat}
bySev = collections.Counter(s for *_,s,_ in [(x[0],x[1],x[2],x[3]) for x in L] for s in [s])
worst = {i: min(s for ii,_,s,_ in L if ii==i) for i in items}
only_reach = [i for i in items if all(c=='REACH' for ii,c,_,_ in L if ii==i)]
print(json.dumps({'limitations':len(L),'byCat':byCat,'byCatItems':byCatItems,'bySev':collections.Counter(s for _,_,s,_ in L),
 'itemsByWorstSev':collections.Counter(worst.values()),'onlyReach':only_reach,'nOnlyReach':len(only_reach),
 'worst1':[i for i in items if worst[i]==1],'worst2':[i for i in items if worst[i]==2]}, indent=1))
