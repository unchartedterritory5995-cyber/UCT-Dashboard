// WS5 audit scratch (NOT committed): per-construct probe through the real doors.
// Stages: PARSE (no lexer/statement refusal) · TRANSLATE (host-lane outputs) ·
// EXECUTE (interpret / runtime run yields finite values) · RENDER (what the
// definition carries) · SAVE (validateUserDefinitions on a JSON round trip).
import { describe, it, vi, afterAll } from 'vitest'
import fs from 'node:fs'
import path from 'node:path'
import { inspectSource } from '../../components/chart/builder/PineBox.jsx'
import { memberPaneDefinition } from '../../components/chart/builder/memberPane/memberPaneDefinition.js'
import { interpret } from '../../components/chart/engine/ast/interpret.js'
import { validateUserDefinitions } from '../../components/chart/engine/nativeRegistry.js'
import { runtimeColumnsFor } from '../../components/chart/engine/runtime/runtimeColumns.js'
import { makeBars } from './refs.js'

const OUT = process.env.WS5_OUT || path.resolve(__dirname, 'out')
const L = String.fromCharCode(10)
const bars = makeBars(600, 7)
const spy = makeBars(600, 99)

// [id, group, body lines (or full script when it starts with //@version)]
const P = [
  ['v3', 'version', ['//@version=3', 'study("p")', 'plot(sma(close, 10))']],
  ['v4', 'version', ['//@version=4', 'study("p")', 'plot(sma(close, 10), title="S")']],
  ['v5', 'version', ['plot(ta.sma(close, 10), "S")']],
  ['v6', 'version', ['//@version=6', 'indicator("p")', 'plot(ta.sma(close, 10), "S")']],
  ['noversion', 'version', ['study("p")', 'plot(sma(close, 10))']],
  ['ind_overlay', 'indicator', ['//@version=5', 'indicator("p", overlay = true)', 'plot(ta.sma(close, 10), "S")']],
  ['ind_precision', 'indicator', ['//@version=5', 'indicator("p", precision = 4)', 'plot(ta.sma(close, 10), "S")']],
  ['ind_mbb', 'indicator', ['//@version=5', 'indicator("p", max_bars_back = 500)', 'plot(ta.sma(close, 10), "S")']],
  ['ind_format', 'indicator', ['//@version=5', 'indicator("p", format = format.percent)', 'plot(ta.roc(close, 10), "S")']],
  ['ind_timeframe', 'indicator', ['//@version=5', 'indicator("p", timeframe = "W")', 'plot(ta.sma(close, 10), "S")']],
  ['in_int', 'input', ['n = input.int(14, "N", minval = 1)', 'plot(ta.rsi(close, n), "R")']],
  ['in_float_mult', 'input', ['m = input.float(2.0, "M")', 'plot(ta.sma(close, 20) + m * ta.stdev(close, 20), "U")']],
  ['in_bool', 'input', ['b = input.bool(true, "Show")', 'plot(b ? ta.sma(close, 20) : na, "S")']],
  ['in_source_hl2', 'input', ['s = input.source(hl2, "Src")', 'plot(ta.sma(s, 20), "S")']],
  ['in_string_opts', 'input', ['t = input.string("SMA", "Type", options = ["SMA", "EMA"])', 'plot(t == "SMA" ? ta.sma(close, 20) : ta.ema(close, 20), "S")']],
  ['in_color', 'input', ['c = input.color(color.red, "Col")', 'plot(ta.sma(close, 20), "S", color = c)']],
  ['in_timeframe', 'input', ['tf = input.timeframe("W", "TF")', 'plot(request.security(syminfo.tickerid, tf, close), "S")']],
  ['in_symbol', 'input', ['s = input.symbol("AMEX:SPY", "Sym")', 'plot(request.security(s, timeframe.period, close), "S")']],
  ['in_session', 'input', ['ss = input.session("0930-1000", "Sess")', 'plot(na(time(timeframe.period, ss)) ? 0 : 1, "S")']],
  ['in_enum_v6', 'input', ['//@version=6', 'indicator("p")', 'enum MA', '    sma = "SMA"', '    ema = "EMA"', 'm = input.enum(MA.sma, "MA")', 'plot(m == MA.sma ? ta.sma(close, 20) : ta.ema(close, 20), "S")']],
  ['var_counter', 'state', ['var c = 0', 'c += 1', 'plot(c, "C")']],
  ['var_reseed', 'state', ['var float hi = na', 'hi := na(hi) or high > hi ? high : hi * 0.99 + high * 0.01', 'plot(hi, "H")']],
  ['varip', 'state', ['varip int n = 0', 'n += 1', 'plot(n, "N")']],
  ['if_block', 'control', ['x = 0.0', 'if close > open', '    x := 1', 'else', '    x := -1', 'plot(x, "X")']],
  ['if_expr', 'control', ['x = if close > open', '    1', 'else', '    -1', 'plot(x, "X")']],
  ['switch', 'control', ['m = 2', 'x = switch m', '    1 => ta.sma(close, 10)', '    2 => ta.ema(close, 10)', '    => close', 'plot(x, "X")']],
  ['ternary', 'control', ['plot(close > open ? high : low, "X")']],
  ['for_sum', 'control', ['s = 0.0', 'for i = 0 to 9', '    s += close[i]', 'plot(s / 10, "X")']],
  ['for_in_array', 'control', ['a = array.from(open, high, low, close)', 's = 0.0', 'for v in a', '    s += v', 'plot(s / 4, "X")']],
  ['while', 'control', ['i = 0', 's = 0.0', 'while i < 5', '    s += close[i]', '    i += 1', 'plot(s / 5, "X")']],
  ['fn_inline', 'functions', ['f(x, n) => ta.sma(x, n) * 2', 'plot(f(close, 10), "X")']],
  ['fn_block', 'functions', ['f(x, n) =>', '    a = ta.sma(x, n)', '    b = ta.ema(x, n)', '    (a + b) / 2', 'plot(f(close, 10), "X")']],
  ['fn_tuple', 'functions', ['f() => [ta.sma(close, 10), ta.ema(close, 10)]', '[a, b] = f()', 'plot(a - b, "X")']],
  ['method', 'functions', ['method twice(float x) => x * 2', 'plot(close.twice(), "X")']],
  ['array_basic', 'collections', ['var a = array.new_float()', 'array.push(a, close)', 'if array.size(a) > 10', '    array.shift(a)', 'plot(array.avg(a), "X")']],
  ['map', 'collections', ['var m = map.new<string, float>()', 'map.put(m, "c", close)', 'plot(map.get(m, "c"), "X")']],
  ['matrix', 'collections', ['m = matrix.new<float>(2, 2, close)', 'plot(matrix.sum(m), "X")']],
  ['udt', 'types', ['type P', '    float v', 'p = P.new(close)', 'plot(p.v, "X")']],
  ['import_lib', 'libraries', ['import TradingView/ta/7 as tvta', 'plot(tvta.ama(close, 10), "X")']],
  ['na_fns', 'na', ['plot(nz(close[1], close) + (na(close[2]) ? 0 : 1), "X")']],
  ['fixnan', 'na', ['x = close > open ? close : na', 'plot(fixnan(x), "X")']],
  ['hist_literal', 'history', ['plot(close - close[5], "X")']],
  ['hist_var', 'history', ['x = ta.sma(close, 5)', 'plot(x - x[2], "X")']],
  ['hist_dynamic', 'history', ['n = input.int(5, "N")', 'plot(close - close[n], "X")']],
  ['hist_series_offset', 'history', ['n = bar_index % 3', 'plot(close[n], "X")']],
  ['math_mix', 'math', ['plot(math.abs(close - open) + math.max(high, low) - math.min(open, close) + math.round(close) + math.pow(2, 2) + math.sqrt(close) + math.log(close) + math.sign(close - open), "X")']],
  ['math_avg_sum', 'math', ['plot(math.avg(open, close) + math.sum(close, 5), "X")']],
  ['math_round_mintick', 'math', ['plot(math.round_to_mintick(close), "X")']],
  ['math_random', 'math', ['plot(math.random(), "X")']],
  ['str_in_plot', 'str', ['s = str.tostring(close)', 'plot(str.length(s), "X")']],
  ['sec_sym_spy', 'request', ['plot(request.security("AMEX:SPY", timeframe.period, close), "X")']],
  ['sec_w_off', 'request', ['plot(request.security(syminfo.tickerid, "W", close), "X")']],
  ['sec_w_on', 'request', ['plot(request.security(syminfo.tickerid, "W", close, lookahead = barmerge.lookahead_on), "X")']],
  ['sec_w_gaps', 'request', ['plot(request.security(syminfo.tickerid, "W", close, gaps = barmerge.gaps_on), "X")']],
  ['sec_lower', 'request', ['plot(request.security(syminfo.tickerid, "60", close), "X")']],
  ['sec_lower_tf', 'request', ['a = request.security_lower_tf(syminfo.tickerid, "60", close)', 'plot(array.size(a), "X")']],
  ['sec_tuple', 'request', ['[h, l] = request.security(syminfo.tickerid, "W", [high, low])', 'plot(h - l, "X")']],
  ['req_financial', 'request', ['plot(request.financial(syminfo.tickerid, "TOTAL_REVENUE", "FQ"), "X")']],
  ['req_earnings', 'request', ['plot(request.earnings(syminfo.tickerid, earnings.actual), "X")']],
  ['req_dividends', 'request', ['plot(request.dividends(syminfo.tickerid), "X")']],
  ['req_economic', 'request', ['plot(request.economic("US", "GDP"), "X")']],
  ['tf_vars', 'timeframe', ['plot(timeframe.isintraday ? 1 : timeframe.isdaily ? 2 : 3, "X")']],
  ['tf_multiplier', 'timeframe', ['plot(timeframe.multiplier, "X")']],
  ['tf_in_seconds', 'timeframe', ['plot(timeframe.in_seconds(), "X")']],
  ['time_dow', 'time', ['plot(dayofweek == dayofweek.monday ? 1 : 0, "X")']],
  ['time_hour', 'time', ['plot(hour, "X")']],
  ['time_session', 'time', ['plot(na(time(timeframe.period, "0930-1000")) ? 0 : 1, "X")']],
  ['time_timestamp', 'time', ['plot(time > timestamp(2020, 1, 1) ? 1 : 0, "X")']],
  ['bs_confirmed', 'barstate', ['plot(barstate.isconfirmed ? close : na, "X")']],
  ['bs_islast', 'barstate', ['plot(barstate.islast ? close : na, "X")']],
  ['bs_isfirst', 'barstate', ['plot(barstate.isfirst ? 1 : 0, "X")']],
  ['bs_isnew', 'barstate', ['plot(barstate.isnew ? 1 : 0, "X")']],
  ['bs_isrealtime', 'barstate', ['plot(barstate.isrealtime ? 1 : 0, "X")']],
  ['plot_color_series', 'plot', ['plot(close, "X", color = close > open ? color.green : color.red)']],
  ['plot_linewidth', 'plot', ['plot(close, "X", linewidth = 3)']],
  ['plot_hist', 'plot', ['plot(close - open, "X", style = plot.style_histogram)']],
  ['plot_columns', 'plot', ['plot(close - open, "X", style = plot.style_columns)']],
  ['plot_circles', 'plot', ['plot(close, "X", style = plot.style_circles)']],
  ['plot_step', 'plot', ['plot(close, "X", style = plot.style_stepline)']],
  ['plot_area', 'plot', ['plot(close, "X", style = plot.style_area)']],
  ['plot_cross', 'plot', ['plot(close, "X", style = plot.style_cross)']],
  ['plot_trackprice', 'plot', ['plot(close, "X", trackprice = true)']],
  ['plot_offset_pos', 'plot', ['plot(ta.sma(close, 10), "X", offset = 5)']],
  ['plot_offset_neg', 'plot', ['plot(ta.sma(close, 10), "X", offset = -3)']],
  ['plot_display_none', 'plot', ['plot(close, "X", display = display.none)', 'plot(open, "Y")']],
  ['plot_display_dw', 'plot', ['plot(close, "X", display = display.data_window)']],
  ['plot_show_last', 'plot', ['plot(close, "X", show_last = 20)']],
  ['plot_transp_v4', 'plot', ['//@version=4', 'study("p")', 'plot(close, "X", color=color.red, transp=50)']],
  ['plotshape', 'shapes', ['plotshape(ta.crossover(close, ta.sma(close, 10)), "X", shape.triangleup, location.belowbar, color.green)']],
  ['plotchar', 'shapes', ['plotchar(close > open, "X", "▲", location.abovebar, color.green)']],
  ['plotarrow', 'shapes', ['plotarrow(close - open, "X")']],
  ['plotcandle', 'shapes', ['plotcandle(open, high, low, close, "X", color = close > open ? color.green : color.red)']],
  ['plotbar', 'shapes', ['plotbar(open, high, low, close, "X")']],
  ['hline_plain', 'levels', ['plot(ta.rsi(close, 14), "R")', 'hline(70, "OB")']],
  ['hline_named_fill', 'levels', ['plot(ta.rsi(close, 14), "R")', 'a = hline(70)', 'b = hline(30)', 'fill(a, b, color.new(color.blue, 90))']],
  ['fill_plots', 'levels', ['p1 = plot(high, "H")', 'p2 = plot(low, "L")', 'fill(p1, p2, color.new(color.blue, 80))']],
  ['fill_gradient', 'levels', ['p1 = plot(high, "H")', 'p2 = plot(low, "L")', 'fill(p1, p2, high, low, color.green, color.red)']],
  ['bgcolor', 'paints', ['//@version=5', 'indicator("p", overlay = true)', 'bgcolor(close > open ? color.new(color.green, 80) : na)']],
  ['barcolor', 'paints', ['//@version=5', 'indicator("p", overlay = true)', 'barcolor(close > open ? color.green : color.red)']],
  ['obj_line', 'objects', ['//@version=5', 'indicator("p", overlay = true)', 'if barstate.islast', '    line.new(bar_index - 10, low, bar_index, high, color = color.red)']],
  ['obj_label_text', 'objects', ['//@version=5', 'indicator("p", overlay = true)', 'if barstate.islast', '    label.new(bar_index, high, "Hi " + str.tostring(high, "#.##"))']],
  ['obj_box', 'objects', ['//@version=5', 'indicator("p", overlay = true)', 'var box b = na', 'if barstate.islast', '    b := box.new(bar_index - 5, high, bar_index, low)']],
  ['obj_table', 'objects', ['//@version=5', 'indicator("p", overlay = true)', 'var t = table.new(position.top_right, 1, 1)', 'if barstate.islast', '    table.cell(t, 0, 0, str.tostring(close, "#.##"))']],
  ['obj_polyline', 'objects', ['//@version=5', 'indicator("p", overlay = true)', 'if barstate.islast', '    pts = array.new<chart.point>()', '    for i = 0 to 4', '        pts.push(chart.point.from_index(bar_index - i, close[i]))', '    polyline.new(pts)']],
  ['obj_linefill', 'objects', ['//@version=5', 'indicator("p", overlay = true)', 'if barstate.islast', '    l1 = line.new(bar_index - 5, high, bar_index, high)', '    l2 = line.new(bar_index - 5, low, bar_index, low)', '    linefill.new(l1, l2, color.new(color.blue, 80))']],
  ['obj_pool_delete', 'objects', ['//@version=5', 'indicator("p", overlay = true)', 'var line ln = na', 'line.delete(ln)', 'ln := line.new(bar_index - 1, close[1], bar_index, close)']],
  ['col_new', 'color', ['plot(close, "X", color = color.new(color.red, 50))']],
  ['col_rgb', 'color', ['plot(close, "X", color = color.rgb(10, 200, 30))']],
  ['col_gradient', 'color', ['r = ta.rsi(close, 14)', 'plot(r, "X", color = color.from_gradient(r, 30, 70, color.red, color.green))']],
  ['col_components', 'color', ['c = color.red', 'plot(color.r(c), "X")']],
  ['alertcondition', 'alerts', ['x = ta.crossover(close, ta.sma(close, 10))', 'plot(close, "C")', 'alertcondition(x, "Cross", "crossed")']],
  ['alert_fn', 'alerts', ['plot(close, "C")', 'if ta.crossover(close, ta.sma(close, 10))', '    alert("crossed", alert.freq_once_per_bar_close)']],
  ['strategy_decl', 'strategy', ['//@version=5', 'strategy("p", overlay = true)', 'if ta.crossover(close, ta.sma(close, 10))', '    strategy.entry("L", strategy.long)', 'plot(ta.sma(close, 10), "S")']],
  ['strategy_value_in_ind', 'strategy', ['plot(strategy.position_size, "X")']],
  ['runtime_error', 'errors', ['n = input.int(10, "N")', 'if n < 1', '    runtime.error("bad")', 'plot(ta.sma(close, n), "X")']],
  ['syminfo_mintick', 'syminfo', ['plot(close + syminfo.mintick, "X")']],
  ['syminfo_type', 'syminfo', ['plot(syminfo.type == "stock" ? 1 : 0, "X")']],
]

// ta.* coverage, one call each (all in a plot)
const TA = [
  'ta.sma(close, 10)', 'ta.ema(close, 10)', 'ta.wma(close, 10)', 'ta.rma(close, 10)', 'ta.hma(close, 10)',
  'ta.vwma(close, 10)', 'ta.alma(close, 9, 0.85, 6)', 'ta.swma(close)', 'ta.linreg(close, 10, 0)', 'ta.stdev(close, 10)',
  'ta.variance(close, 10)', 'ta.dev(close, 10)', 'ta.rsi(close, 14)', 'ta.cci(hlc3, 20)', 'ta.cci(close, 20)', 'ta.mfi(hlc3, 14)',
  'ta.cmo(close, 9)', 'ta.mom(close, 10)', 'ta.roc(close, 10)', 'ta.stoch(close, high, low, 14)', 'ta.tsi(close, 13, 25)',
  'ta.wpr(14)', 'ta.atr(14)', 'ta.tr', 'ta.tr(true)', 'ta.bbw(close, 20, 2)', 'ta.kcw(close, 20, 2)', 'ta.highest(high, 10)',
  'ta.lowest(low, 10)', 'ta.highestbars(high, 10)', 'ta.lowestbars(low, 10)', 'ta.pivothigh(high, 5, 5)', 'ta.pivotlow(low, 5, 5)',
  'ta.crossover(close, open) ? 1 : 0', 'ta.crossunder(close, open) ? 1 : 0', 'ta.cross(close, open) ? 1 : 0', 'ta.change(close)',
  'ta.rising(close, 3) ? 1 : 0', 'ta.falling(close, 3) ? 1 : 0', 'ta.barssince(close > open)', 'ta.valuewhen(close > open, close, 0)',
  'ta.cum(volume)', 'ta.vwap', 'ta.vwap(hlc3)', 'ta.obv', 'ta.accdist', 'ta.correlation(close, open, 20)', 'ta.percentrank(close, 20)',
  'ta.percentile_linear_interpolation(close, 20, 50)', 'ta.percentile_nearest_rank(close, 20, 50)', 'ta.median(close, 20)',
  'ta.mode(close, 20)', 'ta.range(close, 20)', 'ta.sar(0.02, 0.02, 0.2)', 'ta.iii', 'ta.nvi', 'ta.pvi', 'ta.pvt', 'ta.wad', 'ta.wvad',
  'ta.cog(close, 10)', 'ta.max(close)', 'ta.min(close)',
]
const TA_TUPLE = [
  ['ta.macd', '[a, b, c] = ta.macd(close, 12, 26, 9)', 'a'], ['ta.bb', '[a, b, c] = ta.bb(close, 20, 2)', 'b'],
  ['ta.kc', '[a, b, c] = ta.kc(close, 20, 2)', 'b'], ['ta.dmi', '[a, b, c] = ta.dmi(14, 14)', 'c'],
  ['ta.supertrend', '[a, b] = ta.supertrend(3, 10)', 'a'],
]
for (const e of TA) P.push([`ta:${e}`, 'ta', [`plot(${e}, "X")`]])
for (const [n, l, v] of TA_TUPLE) P.push([`ta:${n}`, 'ta', [l, `plot(${v}, "X")`]])

const scriptOf = (lines) => (lines[0].startsWith('//@version') || lines[0].startsWith('study(')
  ? lines.join(L) : ['//@version=5', 'indicator("p")', ...lines].join(L)) + L

const rows = []
afterAll(() => {
  fs.mkdirSync(OUT, { recursive: true })
  fs.writeFileSync(path.join(OUT, 'constructs.json'), JSON.stringify(rows, null, 1))
  vi.unstubAllEnvs()
})

function finiteOf(def, plotKey, inputs) {
  const p = (def.plots || []).find((x) => x.key === plotKey)
  return p
}

describe('constructs', () => {
  for (const [id, group, lines] of P) {
    it(id, () => {
      const src = scriptOf(lines)
      const row = { id, group }
      vi.stubEnv('VITE_PINE_OBJECTS_ONLY_PANE_ENABLED', '1')
      vi.stubEnv('VITE_PINE_RUNTIME_PANE_ENABLED', '0')
      let rep
      try { rep = inspectSource(src, 'auto') } catch (e) { rep = { outcome: { verdict: 'THREW' }, refusal: { guard: 'threw', message: String(e) } } }
      const parseGuards = new Set(['pine:character', 'pine:statement', 'pine:empty', 'import:internal-error'])
      const allNotes = [...(rep.ignored || [])]
      row.parse = !(rep.refusal && parseGuards.has(rep.refusal.guard)) && !allNotes.some((n) => n.code === 'pine:character')
      row.importVerdict = rep.outcome && rep.outcome.verdict
      row.importReason = rep.outcome && rep.outcome.reason ? String(rep.outcome.reason).slice(0, 160) : null
      row.importNotes = allNotes.filter((n) => n.code !== 'pine:declaration').map((n) => `${n.code}: ${String(n.message).slice(0, 120)}`).slice(0, 4)
      row.importOutputs = (rep.outputs || []).map((o) => (o.formula ? `${o.kind}:${String(o.formula).slice(0, 80)}` : `${o.kind}:REF ${o.refusal && o.refusal.guard}`))
      let pane
      try { pane = memberPaneDefinition({ source: src, id: 'u_member-pane-ws5p' }) } catch (e) { pane = { ok: false, reason: `threw ${e}` } }
      row.host = pane.ok ? 'ok' : `REF ${pane.guard || ''} ${String(pane.reason || '').slice(0, 140)}`
      if (pane.ok) {
        const d = pane.definition
        const vis = (d.plots || []).filter((p) => !p.hidden)
        row.render = {
          plots: vis.map((p) => `${p.style}${p.colorMode ? '/dyncol' : ''}${p.fill ? '/fill' : ''}${p.marker ? `/marker:${p.marker.shape || ''}` : ''}${p.displace ? `/displace${p.displace}` : ''}`),
          levels: d.levels ? d.levels.length : 0, paints: d.paints ? d.paints.map((p) => p.kind) : [],
          objects: d.objects ? (d.objects.ops || []).length : 0, placement: d.placement && d.placement.target,
          inputs: (d.inputs || []).map((i) => i.key).filter((k) => !/Color$|Width$|^color$|^lineWidth$/.test(k)),
          params: d.compute && d.compute.paramManifest ? Object.values(d.compute.paramManifest).map((p) => p.sourceName) : [],
          notes: (pane.notes || []).map((n) => String(n.note).slice(0, 100)),
          kind: d.compute && d.compute.kind,
        }
        // execute: evaluate host outputs
        const t = pane.translation
        const inputs = Object.fromEntries((d.inputs || []).map((i) => [i.key, i.default]))
        const ex = []
        for (const o of (t.outputs || []).filter((x) => x && x.ast && !x.hidden && x.kind !== 'alertcondition')) {
          try {
            const v = Array.from(interpret(o.ast, bars, inputs, undefined, undefined, { symbols: { SPY: spy, 'AMEX:SPY': spy }, tf: 'D' }))
            ex.push(v.filter(Number.isFinite).length)
          } catch (e) { ex.push(`ERR ${String(e.message).slice(0, 60)}`) }
        }
        row.execute = ex
        try {
          const { defs, errors } = validateUserDefinitions([JSON.parse(JSON.stringify(d))])
          row.save = defs.length === 1 && !errors.length ? 'ok' : `REF ${errors.join(' ').slice(0, 120)}`
        } catch (e) { row.save = `threw ${String(e).slice(0, 80)}` }
      }
      // dark runtime lane
      vi.stubEnv('VITE_PINE_RUNTIME_PANE_ENABLED', '1')
      if (!pane.ok) {
        let rt
        try { rt = memberPaneDefinition({ source: src, id: 'u_member-pane-ws5r' }) } catch (e) { rt = { ok: false, reason: `threw ${e}` } }
        if (rt.ok && rt.definition.compute && rt.definition.compute.kind === 'runtime') {
          try {
            const cols = runtimeColumnsFor(rt.definition, bars, undefined, { tf: 'D', newestBarIsForming: false })
            row.runtime = `ok: ${Object.entries(cols).filter(([k]) => !k.startsWith('__')).map(([k, v]) => `${k}=${Array.from(v).filter(Number.isFinite).length}`).join(',')}`
          } catch (e) { row.runtime = `builds, run refused: ${String((e && e.message) || e).slice(0, 120)}` }
        } else if (rt.ok) row.runtime = 'host-ok'
        else row.runtime = `declined ${(rt.runtimeDeclined && rt.runtimeDeclined.code) || rt.guard || ''}: ${String((rt.runtimeDeclined && rt.runtimeDeclined.why) || '').slice(0, 120)}`
      }
      rows.push(row)
    })
  }
})
