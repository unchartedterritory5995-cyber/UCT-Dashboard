"""PA5 scratch pytest plugin (audit only, never committed). Re-runs stale-fixture rails
with `definition.version = 1` injected when a fixture omits it, to see whether the
rail's OWN claim still holds once the 10-08 version gate (4b9796e968) is satisfied."""
import pytest


@pytest.fixture(autouse=True)
def _pa5_inject_version(monkeypatch):
    from api.services import user_definitions as svc
    real = svc.save

    def save(user_id, def_id, definition, *a, **k):
        if isinstance(definition, dict) and "version" not in definition:
            definition = {**definition, "version": 1}
        return real(user_id, def_id, definition, *a, **k)
    monkeypatch.setattr(svc, "save", save)
    yield
