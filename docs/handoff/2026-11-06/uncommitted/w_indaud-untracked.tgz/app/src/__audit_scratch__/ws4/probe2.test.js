// WS4 AUDIT SCRATCH — NOT FOR COMMIT.
import { it } from 'vitest'
import fs from 'node:fs'
import { translatePine } from '../../components/chart/engine/ast/pine.js'
import { evaluateFormula } from '../../components/chart/builder/FormulaField'
const H = '//@version=5\nindicator("probe", overlay=true)\n'
it('probe2', () => {
  const out = {}
  for (const s of ['crossOver(close - vwap(), 0)', '(close > vwap()) && !((close > vwap())[1])', 'close > vwap()',
    'crossOver(close, avwap(1700000000))', 'change(vwap())', 'close > open ? 1 : na(close)', 'nz(close[1], close)']) {
    const ev = evaluateFormula(s); out[s] = ev.ok ? 'ok' : `${ev.guard}: ${String(ev.error).slice(0, 120)}`
  }
  const pine = {
    barcolorPlot: H + 'c = ta.ema(close, 9) > ta.ema(close, 20) and volume > ta.sma(volume, 20)\nbarcolor(c ? color.green : na)\nplot(close, display=display.none)',
    bgPlot: H + 'ma = ta.sma(close, 50)\nhot = ta.rsi(close, 14) > 70 and close > ma and ma > ma[1]\nbgcolor(hot ? color.new(color.orange, 80) : na)\nplot(ma)',
    vwapCross: H + 'plot(ta.crossover(close, ta.vwap) ? 1 : 0)',
  }
  for (const [k, s] of Object.entries(pine)) {
    const t = translatePine(s)
    out[`pine:${k}`] = { ok: t.ok, outputs: (t.outputs || []).map((o) => o.formula), presentationKeys: t.presentation ? Object.keys(t.presentation) : null,
      paints: t.presentation && t.presentation.paints ? JSON.stringify(t.presentation.paints).slice(0, 300) : null,
      refusals: JSON.stringify(t.refusals || []).slice(0, 250) }
  }
  fs.writeFileSync('src/__audit_scratch__/ws4/probe2.json', JSON.stringify(out, null, 1))
})
