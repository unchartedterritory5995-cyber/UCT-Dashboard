"""PA5 scratch (audit only, never committed). Is the PRODUCT save path depth-sensitive?

A deep canonical tree through the real store (`user_definitions.save`) and the router's
own wrapper (`_save_or_400`), on a temp DB. Nothing in production is touched.
"""
from __future__ import annotations

import pytest
from fastapi import HTTPException

from api.services import user_definitions as svc
from api.services import compute_graph as cg


@pytest.fixture
def store(tmp_path, monkeypatch):
    monkeypatch.setattr(svc, "_DB_PATH", str(tmp_path / "user_definitions.db"))
    svc._init_db()
    return tmp_path


def deep(n):
    t = {"type": "series", "name": "close"}
    for _ in range(n):
        t = {"type": "op", "name": "+", "args": [{"type": "num", "value": 1}, t]}
    return t


def doc(tree, i):
    return {"id": svc.new_def_id(), "version": 1, "plots": [{"key": "value", "style": "line"}],
            "compute": {"kind": "ast", "ast": tree, "fn": "sha256:x"}}


@pytest.mark.parametrize("depth", [100, 200, 300, 1000])
def test_v1_deep_tree_through_save(store, depth):
    d = doc(deep(depth), depth)
    try:
        svc.save("pa5-user", d["id"], d)
        outcome = "stored"
    except svc.SaveRefused as e:
        outcome = f"SaveRefused({e.as_dict().get('guard')})"
    except ValueError as e:
        outcome = f"ValueError({str(e)[:70]})"
    except RecursionError:
        outcome = "RecursionError (uncaught -> HTTP 500)"
    print(f"PA5_DEEP v1 depth={depth}: {outcome}")


@pytest.mark.parametrize("length", [100, 600, 2000])
def test_graph_chain_through_save(store, length):
    nodes = [{"type": "series", "name": "close"}]
    for _ in range(length):
        nodes.append({"type": "op", "name": "+", "args": [len(nodes) - 1, len(nodes) - 1]})
    # a CHAIN, not a doubling: each node uses the previous one once (+ a literal)
    nodes = [{"type": "series", "name": "close"}, {"type": "num", "value": 1}]
    for _ in range(length):
        nodes.append({"type": "op", "name": "+", "args": [1, len(nodes) - 1]})
    graph = {"graphVersion": cg.GRAPH_VERSION, "nodes": nodes,
             "outputRoots": {"value": len(nodes) - 1, "up": 0}, "parameters": {}}
    d = {"id": svc.new_def_id(), "version": 1, "plots": [{"key": "up", "style": "line"}, {"key": "value", "style": "line"}],
         "compute": {"kind": "ast", "graph": graph, "scanPlot": "value", "treesHash": "sha256:x", "fn": "sha256:x"}}
    try:
        svc.save("pa5-user", d["id"], d)
        outcome = "stored"
    except svc.SaveRefused as e:
        outcome = f"SaveRefused({e.as_dict().get('guard')})"
    except ValueError as e:
        outcome = f"ValueError({str(e)[:70]})"
    except RecursionError:
        outcome = "RecursionError (uncaught -> HTTP 500)"
    print(f"PA5_DEEP graph chain length={length}: {outcome}")


def test_router_wrapper_does_not_catch_recursion(store):
    from api.routers import user_definitions as r
    d = doc(deep(400), 999)
    try:
        r._save_or_400("pa5-user", d["id"], d, None)
        outcome = "returned"
    except HTTPException as e:
        outcome = f"HTTPException {e.status_code}"
    except RecursionError:
        outcome = "RecursionError escapes _save_or_400 (FastAPI answers 500)"
    except Exception as e:  # noqa: BLE001
        outcome = f"{type(e).__name__}: {str(e)[:80]}"
    print(f"PA5_DEEP router: {outcome}")
