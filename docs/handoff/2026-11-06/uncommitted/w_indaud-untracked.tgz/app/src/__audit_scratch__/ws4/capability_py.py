"""WS4 AUDIT SCRATCH — NOT FOR COMMIT. Python-lane half of the capability matrix."""
import json, math, os, sys
ROOT = r"C:/w/indaud"
sys.path.insert(0, ROOT)
from api.services import ast_interpret, scan_definition, ast_budget, alert_user_series  # noqa

HERE = os.path.dirname(os.path.abspath(__file__))
d = json.load(open(os.path.join(HERE, "js_results.json"), encoding="utf-8"))
bars = d["bars"]
out = []
for r in d["rows"]:
    if not r.get("ok"):
        continue
    row = {"cat": r["cat"], "src": r["src"]}
    ast = r["ast"]
    try:
        col = ast_interpret.interpret(ast, bars, {}, None, {}, {"tf": "D"})
        fin = [v for v in col if isinstance(v, (int, float)) and not math.isnan(v)]
        row["pyFinite"] = len(fin)
        last = [None if (v is None or (isinstance(v, float) and math.isnan(v))) else round(v, 6) for v in col[-5:]]
        row["pyLast"] = last
        jl = r.get("jsLast") or []
        agree = len(jl) == len(last) and all(
            (a is None and b is None) or (a is not None and b is not None and abs(a - b) <= 1e-6 * max(1, abs(a)))
            for a, b in zip(jl, last))
        row["laneAgree"] = agree and r.get("jsFinite") == len(fin)
    except Exception as e:  # noqa
        row["pyErr"] = f"{type(e).__name__}: {getattr(e, 'guard', '')} {str(e)[:200]}"
    try:
        row["isBool"] = scan_definition.is_boolean_tree(ast)
    except Exception as e:
        row["isBoolErr"] = str(e)[:120]
    try:
        scan_definition.assert_scannable({"compute": {"kind": "ast", "ast": ast}})
        row["scan"] = "ADMIT"
    except scan_definition.ScanRefused as e:
        row["scan"] = f"REFUSE[{e.gate}] {str(e)[:220]}"
    except Exception as e:
        row["scan"] = f"ERR {type(e).__name__} {str(e)[:160]}"
    try:
        defn = {"plots": [{"key": "value"}], "compute": {"kind": "ast", "ast": ast}}
        adm, withheld = alert_user_series.plot_admissions("u_aaaaaaaaaaaa", defn)
        row["alert"] = "ADMIT" if adm else ("WITHHELD " + "; ".join(f"[{v.gate}] {str(v)[:160]}" for v in withheld.values()))
    except alert_user_series.AdmissionRefused as e:
        row["alert"] = f"REFUSE[{e.gate}] {str(e)[:160]}"
    except Exception as e:
        row["alert"] = f"ERR {type(e).__name__} {str(e)[:160]}"
    out.append(row)
json.dump(out, open(os.path.join(HERE, "py_results.json"), "w"), indent=1)
for row in out:
    print(" | ".join(str(x) for x in [row["cat"], row["src"].replace("\n", " / ")[:60], row.get("pyFinite", row.get("pyErr")),
                                      "agree" if row.get("laneAgree") else "DIFF", row.get("isBool"), row["scan"][:120], row["alert"][:120]]))
