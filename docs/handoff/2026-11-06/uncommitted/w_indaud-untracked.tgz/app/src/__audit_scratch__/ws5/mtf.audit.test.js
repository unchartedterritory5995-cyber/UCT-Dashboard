import { it } from 'vitest'
import { inspectSource } from '../../components/chart/builder/PineBox.jsx'
import { memberPaneDefinition } from '../../components/chart/builder/memberPane/memberPaneDefinition.js'
import { interpret } from '../../components/chart/engine/ast/interpret.js'
import { makeBars } from './refs.js'
const bars = makeBars(400, 7)
const wk = (t) => { const d = new Date(t * 1000); const day = (d.getUTCDay() + 6) % 7; return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() - day) }
// weekly closes
const keys = []; const wc = []; const lastIdx = []
bars.forEach((b, i) => { const k = wk(b.t); if (!keys.length || keys[keys.length - 1] !== k) { keys.push(k); wc.push(b.c); lastIdx.push(i) } else { wc[wc.length - 1] = b.c; lastIdx[lastIdx.length - 1] = i } })
const widx = bars.map((b) => keys.indexOf(wk(b.t)))
const models = {
  thisWeekFinal: bars.map((b, i) => wc[widx[i]]), // lookahead_on future leak
  prevWeek: bars.map((b, i) => (widx[i] > 0 ? wc[widx[i] - 1] : NaN)),
  tvOffHistorical: bars.map((b, i) => (lastIdx[widx[i]] === i ? wc[widx[i]] : (widx[i] > 0 ? wc[widx[i] - 1] : NaN))),
  developing: bars.map((b, i) => b.c),
}
const L = String.fromCharCode(10)
const variants = {
  off_default: 'request.security(syminfo.tickerid, "W", close)',
  off_explicit: 'request.security(syminfo.tickerid, "W", close, lookahead = barmerge.lookahead_off)',
  on_no_offset: 'request.security(syminfo.tickerid, "W", close, lookahead = barmerge.lookahead_on)',
  on_offset1: 'request.security(syminfo.tickerid, "W", close[1], lookahead = barmerge.lookahead_on)',
  off_offset1: 'request.security(syminfo.tickerid, "W", close[1])',
  gaps_on: 'request.security(syminfo.tickerid, "W", close, barmerge.gaps_on)',
  lower_tf: 'request.security(syminfo.tickerid, "60", close)',
  monthly: 'request.security(syminfo.tickerid, "M", close)',
  sym_bare_qqq: 'request.security("QQQ", timeframe.period, close)',
  sym_computed: 'request.security(input.symbol("SPY"), "W", close)',
  security_lower_tf: 'request.security_lower_tf(syminfo.tickerid, "60", close)',
  v4_security_on: null,
}
it('mtf variants', () => {
  for (const [name, expr] of Object.entries(variants)) {
    const src = expr === null
      ? ['//@version=4', 'study("m", overlay=true)', 'x = security(syminfo.tickerid, "W", close, lookahead=barmerge.lookahead_on)', 'plot(x, "X")'].join(L)
      : ['//@version=5', 'indicator("m", overlay = true)', `x = ${expr}`, 'plot(x, "X")'].join(L)
    const rep = inspectSource(src, 'auto')
    const pane = memberPaneDefinition({ source: src, id: 'u_member-pane-mtf' })
    const o = (pane.translation && pane.translation.outputs || [])[0]
    let match = null
    if (o && o.ast) {
      try {
        const v = Array.from(interpret(o.ast, bars, {}, undefined, undefined, { tf: 'D' }))
        match = {}
        for (const [m, ref] of Object.entries(models)) {
          let ok = 0; let tot = 0
          for (let i = 30; i < bars.length - 1; i++) { if (!Number.isFinite(ref[i])) continue; tot++; if (Number.isFinite(v[i]) && Math.abs(v[i] - ref[i]) < 1e-9) ok++ }
          match[m] = `${ok}/${tot}`
        }
        match.finite = v.filter(Number.isFinite).length
      } catch (e) { match = String(e.message).slice(0, 100) }
    }
    console.log(name, '| import:', rep.outcome.verdict, (rep.outcome.reason || '').slice(0, 90), '| formula:', o && o.formula, '| pane:', pane.ok, (pane.reason || '').slice(0, 140), '| notes:', (pane.notes || []).map((n) => n.note.slice(0, 80)).join(' / '), '|', JSON.stringify(match))
  }
})
