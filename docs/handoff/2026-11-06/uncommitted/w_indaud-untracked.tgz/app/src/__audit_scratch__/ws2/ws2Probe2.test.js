import { it } from 'vitest'
import { validateDefinition } from '../../components/chart/engine/defSchema'
import { translatePine } from '../../components/chart/engine/ast/pine'
import * as reg from '../../components/chart/engine/nativeRegistry'
it('probe', () => {
  const rsi = reg.getDefinition ? reg.getDefinition('rsi') : null
  const base = rsi ? JSON.parse(JSON.stringify(rsi)) : null
  if (base) {
    const k = base.plots.find((p) => p.style !== 'hlines').key
    base.id = 'probe-area'
    base.plots = base.plots.map((p) => p.key === k ? { ...p, style: 'area', colorMode: 'column:' + k, colorUp: '#00ff00', colorDown: '#ff0000' } : p)
    const r = validateDefinition(base)
    console.log('[WS2 P-B2] rsi->area+colorMode ok=', r.ok, JSON.stringify((r.errors || []).slice(0, 3)))
  }
  const src = '//@version=5\nindicator("t", overlay=true)\nplot(close > open ? close : na, style=plot.style_linebr)\n'
  const t = translatePine(src)
  console.log('[WS2 P-D2] outputs=', JSON.stringify(t.outputs).slice(0, 700))
  console.log('[WS2 P-D2] notes=', JSON.stringify((t.notes||[]).map(n=>n.code||n.message)).slice(0, 500))
})
