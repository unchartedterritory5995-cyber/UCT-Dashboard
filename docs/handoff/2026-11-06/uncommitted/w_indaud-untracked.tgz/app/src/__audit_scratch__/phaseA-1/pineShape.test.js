import { it } from 'vitest'
import fs from 'fs'
import { inspectSource } from '../../components/chart/builder/PineBox.jsx'
import { evaluateFormula } from '../../components/chart/builder/FormulaField.jsx'
import { BUILDER_INPUT_SCOPE } from '../../components/chart/builder/builderInputs.js'
it('pine shapes + verdicts', () => {
  const out = {}
  const P = (body) => `//@version=5\nindicator("x")\nplot(${body})`
  for (const [k, s] of Object.entries({
    smaOfSecurity: P('ta.sma(request.security(syminfo.tickerid, "W", close), 10)'),
    securityOfSma: P('request.security(syminfo.tickerid, "W", ta.sma(close, 10))'),
    securityOffset: P('request.security(syminfo.tickerid, "W", close[1])'),
    securityThenOffset: P('request.security(syminfo.tickerid, "W", close)[1]'),
    securityLookaheadOn: P('request.security(syminfo.tickerid, "W", close, lookahead = barmerge.lookahead_on)'),
  })) {
    const r = inspectSource(s, 'auto'); const o = r.outputs[r.selected >= 0 ? r.selected : 0] || {}
    out[k] = { ok: r.ok, formula: o.formula, verdict: r.outcome && r.outcome.verdict, reason: r.outcome && r.outcome.reason, semantic: (r.outcome && r.outcome.parts && r.outcome.parts.semantic || []).map((x) => x.name), refusal: r.refusal && r.refusal.guard }
  }
  for (const f of ["tf(sma(close, 10), 'W')", "tf_live(sma(close, 10), 'W')", "tf(sma(close, 10)[1], 'W')", "sma(tf(close, 'W'), 10)"]) {
    const ev = evaluateFormula(f, BUILDER_INPUT_SCOPE)
    out[f] = { ok: ev.ok, mode: ev.verdict && ev.verdict.mode, readback: ev.readback }
  }
  fs.writeFileSync('src/__audit_scratch__/phaseA-1/pineShape.json', JSON.stringify(out, null, 1))
})
