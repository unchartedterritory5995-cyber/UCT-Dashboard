import { it } from 'vitest'
import fs from 'fs'
import { readFormulaSource } from '../../components/chart/engine/ast/pcf.js'
import { isSwappedStoch } from './detect.js'
it('case + mixed', () => {
  const out = {}
  for (const s of ['stoc14.3 < 20', 'Stoc14.3<20', 'STOC14.3.2 > 50 OR WRSI14 < 30', 'XUP(STOC14.3, 20)', 'COUNTTRUE(STOC14.3 < 20, 5) >= 3', 'stoch(close, high, low, 14) < 20']) {
    const r = readFormulaSource(s, 'auto'); out[s] = { dialect: r.dialect, ok: r.result.ok, swapped: r.result.ok ? isSwappedStoch(r.result.ast) : null, err: r.result.ok ? null : r.result.error }
  }
  fs.writeFileSync('src/__audit_scratch__/phaseA-1/stocCase.json', JSON.stringify(out, null, 1))
})
