"""PHASE A-1 probe (audit scratch, never committed). Synthetic bars only.

1. The server lane evaluates the STORED tree; it has no PCF reader.
2. Python detection predicate + deterministic rewrite; hashes must equal the JS ones.
"""
import json
import math
import random
import sys

sys.path.insert(0, "C:/w/indaud")
from api.services import ast_interpret, user_definitions  # noqa: E402


def bars(n=420, seed=7):
    r = random.Random(seed)
    out, p, t = [], 50.0, 1704153600
    while len(out) < n:
        o = p * (1 + (r.random() - 0.5) * 0.02)
        c = o * (1 + (r.random() - 0.5) * 0.04)
        h = max(o, c) * (1 + r.random() * 0.015)
        l = min(o, c) * (1 - r.random() * 0.015)
        out.append({"t": t, "o": o, "h": h, "l": l, "c": c, "v": 1e6})
        p = c
        t += 86400
    return out


def is_series(n, name):
    return isinstance(n, dict) and n.get("type") == "series" and n.get("name") == name


def walk(n):
    if isinstance(n, dict):
        yield n
        for a in n.get("args") or []:
            yield from walk(a)


def is_swapped_stoch(tree):
    """P0-1 predicate: any `stoch` call whose first three args are close, high, low."""
    for n in walk(tree):
        if n.get("type") == "call" and n.get("name") == "stoch":
            a = (n.get("args") or [])[:3]
            if len(a) == 3 and is_series(a[0], "close") and is_series(a[1], "high") and is_series(a[2], "low"):
                return True
    return False


def rewrite(n):
    if not isinstance(n, dict):
        return n
    args = [rewrite(a) for a in (n.get("args") or [])]
    if n.get("type") == "call" and n.get("name") == "stoch" and len(args) >= 3 \
            and is_series(args[0], "close") and is_series(args[1], "high") and is_series(args[2], "low"):
        args = [args[1], args[2], args[0], *args[3:]]
    out = dict(n)
    if "args" in n:
        out["args"] = args
    return out


def S(name):
    return {"type": "series", "name": name}


def N(v):
    return {"type": "num", "value": v}


old = {"type": "op", "name": "<", "args": [
    {"type": "call", "name": "sma", "args": [
        {"type": "call", "name": "stoch", "args": [S("close"), S("high"), S("low"), N(14)]}, N(3)]}, N(20)]}
B = bars()
col_old = ast_interpret.interpret(old, B)
col_new = ast_interpret.interpret(rewrite(old), B)
k_old = ast_interpret.interpret(old["args"][0], B)
k_new = ast_interpret.interpret(rewrite(old)["args"][0], B)
fin = lambda xs: [x for x in xs if x is not None and not (isinstance(x, float) and math.isnan(x))]  # noqa: E731
print(json.dumps({
    "old_hash": user_definitions.ast_hash(old),
    "rewritten_hash": user_definitions.ast_hash(rewrite(old)),
    "js_old_hash_expected": "sha256:22a71bc4c7632e0cf10894882879d7dd9c851cbeeab6fd23dcf658a08c3b90d3",
    "js_fixed_hash_expected": "sha256:8df8501616c63eecd501e816b07edfa70781b5733ca226b54b0f2881e85bd563",
    "detect_old": is_swapped_stoch(old), "detect_new": is_swapped_stoch(rewrite(old)),
    "server_old_k_range": [round(min(fin(k_old)), 1), round(max(fin(k_old)), 1)],
    "server_new_k_range": [round(min(fin(k_new)), 1), round(max(fin(k_new)), 1)],
    "server_condition_disagree_bars": sum(1 for a, b in zip(col_old, col_new) if a != b),
    "bars": len(B),
}, indent=1))
