import { it } from 'vitest'
import fs from 'fs'
import { inspectSource } from '../../components/chart/builder/PineBox.jsx'
import { evaluateFormula } from '../../components/chart/builder/FormulaField.jsx'
import { BUILDER_INPUT_SCOPE } from '../../components/chart/builder/builderInputs.js'
import { interpret } from '../../components/chart/engine/ast/interpret.js'
import { B } from './numeric.test.js'

it('stoch', () => {
  const N = B.length
  const C = B.map((b) => b.c), H = B.map((b) => b.h), L = B.map((b) => b.l)
  const lines = []
  const ev = (src) => { const e = evaluateFormula(src, BUILDER_INPUT_SCOPE); return { e, v: e.ok ? [...interpret(e.ast, B, {}, undefined, {})] : null } }
  const ref = []
  for (let i = 0; i < N; i++) {
    if (i < 13) { ref.push(NaN); continue }
    const hh = Math.max(...H.slice(i - 13, i + 1)), ll = Math.min(...L.slice(i - 13, i + 1))
    ref.push(100 * (C[i] - ll) / (hh - ll))
  }
  lines.push('ref raw %K tail ' + ref.slice(-4).map((x) => x.toFixed(3)))
  for (const s of ['stoch(close, high, low, 14)', 'STOC14.1 + 0', 'STOC14 + 0', 'STOC14.3 + 0']) {
    const { e, v } = ev(s)
    lines.push(`${s}: ok=${e.ok} dialect=${e.dialect} ast=${JSON.stringify(e.ast).slice(0, 200)} readback=${String(e.readback).slice(0, 120)} tail=${v ? v.slice(-4).map((x) => x.toFixed(3)) : e.error}`)
  }
  // permutations against the engine value
  const { v } = ev('stoch(close, high, low, 14)')
  const perms = {
    '(c-ll)/(hh-ll)': (i, hh, ll) => 100 * (C[i] - ll) / (hh - ll),
    'hh/ll over close': (i) => { const w = C.slice(i - 13, i + 1); return 100 * (C[i] - Math.min(...w)) / (Math.max(...w) - Math.min(...w)) },
    'src=high? (h-llLow)/(hhClose-llLow)': (i) => { const hh = Math.max(...C.slice(i - 13, i + 1)); const ll = Math.min(...L.slice(i - 13, i + 1)); return 100 * (H[i] - ll) / (hh - ll) },
  }
  for (const [n, f] of Object.entries(perms)) {
    let agree = 0, cnt = 0
    for (let i = 30; i < N; i++) { const hh = Math.max(...H.slice(i - 13, i + 1)), ll = Math.min(...L.slice(i - 13, i + 1)); const r = f(i, hh, ll); cnt++; if (Math.abs(r - v[i]) < 1e-6) agree++ }
    lines.push(`perm ${n}: agree ${agree}/${cnt}`)
  }
  // brute: find source/high/low assignment that matches
  const fields = { close: C, high: H, low: L }
  for (const a of Object.keys(fields)) for (const b of Object.keys(fields)) for (const c of Object.keys(fields)) {
    let agree = 0, cnt = 0
    for (let i = 30; i < N; i++) {
      const hh = Math.max(...fields[b].slice(i - 13, i + 1)), ll = Math.min(...fields[c].slice(i - 13, i + 1))
      const r = 100 * (fields[a][i] - ll) / (hh - ll); cnt++; if (Math.abs(r - v[i]) < 1e-6) agree++
    }
    if (agree > 0) lines.push(`MATCH src=${a} hh over ${b} ll over ${c}: ${agree}/${cnt}`)
  }
  // Pine door
  const p = inspectSource('//@version=5\nindicator("s")\nplot(ta.stoch(close, high, low, 14))', 'auto')
  lines.push('pine stoch formula ' + (p.outputs[0] && p.outputs[0].formula))
  if (p.outputs[0] && p.outputs[0].ast) lines.push('pine tail ' + [...interpret(p.outputs[0].ast, B, {}, undefined, {})].slice(-4).map((x) => x.toFixed(3)))
  lines.push('min engine stoch over all bars ' + Math.min(...v.filter(Number.isFinite)).toFixed(3) + ' max ' + Math.max(...v.filter(Number.isFinite)).toFixed(3))
  fs.writeFileSync('src/__audit_scratch__/ws6/stoch.txt', lines.join('\n'))
})
