// PHASE A-1 probe: SIMULATE the corrected PCF reader (STOC fills high, low, close)
// by post-processing readFormulaSource, then reload a doc saved under the OLD reader.
import { it, expect, vi } from 'vitest'
import fs from 'fs'

vi.mock('../../components/chart/engine/ast/pcf.js', async (importOriginal) => {
  const real = await importOriginal()
  const { rewriteSwappedStoch } = await import('./detect.js')
  return {
    ...real,
    readFormulaSource: (source, dialect, inputs) => {
      const r = real.readFormulaSource(source, dialect, inputs)
      if (r.dialect === 'pcf' && r.result && r.result.ok) return { ...r, result: { ...r.result, ast: rewriteSwappedStoch(r.result.ast) } }
      return r
    },
  }
})

import { readFormulaSource } from '../../components/chart/engine/ast/pcf.js'
import { parseFormula, astHash } from '../../components/chart/engine/ast/parse.js'
import { validateUserDefinitions, installUserDefinitions, clearUserDefinitions, AST_LANE_TIER } from '../../components/chart/engine/nativeRegistry.js'
import { SCHEMA_VERSION } from '../../components/chart/engine/defSchema.js'
import { normalizeInstances } from '../../components/chart/engine/instances.js'
import { userRefusalRows } from '../../components/chart/indicatorCatalog.js'
import { rewriteSwappedStoch } from './detect.js'

const docFor = (source, ast, id = 'myFormula') => ({
  schemaVersion: SCHEMA_VERSION, id, version: 1,
  compute: { kind: 'ast', fn: astHash(ast), rev: 1, ast, source },
  meta: { name: 'My STOC scan', shortName: 'P', category: 'Custom', tier: AST_LANE_TIER, repaint: 'non-repainting', freshness: 'live' },
  placement: { target: 'pane', pane: { height: 0.15 } },
  inputs: [{ key: 'color', type: 'color', label: 'Colour', default: 'token:info' }],
  plots: [{ key: 'out', label: 'P', style: 'line', color: '$color', width: 1, role: 'primary' }],
})

it('a doc saved under the OLD reader, loaded under the FIXED reader', () => {
  const out = []
  const src = 'STOC14.3 < 20'
  // the tree the OLD reader stored: close, high, low
  const oldTree = { type: 'op', name: '<', args: [{ type: 'call', name: 'sma', args: [{ type: 'call', name: 'stoch', args: [{ type: 'series', name: 'close' }, { type: 'series', name: 'high' }, { type: 'series', name: 'low' }, { type: 'num', value: 14 }] }, { type: 'num', value: 3 }] }, { type: 'num', value: 20 }] }
  const fixedNow = readFormulaSource(src, 'auto').result.ast
  out.push({ fixedReaderEmits: JSON.stringify(fixedNow).slice(0, 220), equalsCorrectSpelling: astHash(fixedNow) === astHash(parseFormula('sma(stoch(high, low, close, 14), 3) < 20').ast) })
  let oldOk = true
  try { astHash(oldTree) } catch (e) { oldOk = String(e.message) }
  out.push({ oldTreeCanonical: oldOk })
  const oldDoc = docFor(src, oldTree)
  const v = validateUserDefinitions([oldDoc])
  out.push({ oldDocInstalls: v.defs.length, errors: v.errors })
  clearUserDefinitions()
  const ins = installUserDefinitions([oldDoc])
  const n = normalizeInstances([{ instanceId: 'i1', defId: 'myFormula' }])
  out.push({ installed: ins.installed.length, kept: n.kept.length, dropped: n.dropped.map((d) => d.reason) })
  out.push({ settingsRow: userRefusalRows([oldDoc], ins.errors).map((r) => ({ name: r.name, refused: r.refused, n: r.messages.length })) })
  // the migrated doc (deterministic tree rewrite, SAME PCF text) installs under the fixed reader
  const mig = docFor(src, rewriteSwappedStoch(oldTree))
  out.push({ migratedDocInstalls: validateUserDefinitions([mig]).defs.length })
  clearUserDefinitions()
  fs.writeFileSync('src/__audit_scratch__/phaseA-1/stocFixedReader.json', JSON.stringify(out, null, 1))
  expect(true).toBe(true)
})
