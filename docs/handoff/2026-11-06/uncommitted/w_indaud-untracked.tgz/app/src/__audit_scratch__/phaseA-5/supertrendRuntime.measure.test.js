// PA5 scratch (audit only, never committed): one representative stateful script
// (a hand-written Supertrend with `var` state + if/else) through the runtime
// lane's own compute (`computeRuntimeColumns`), on 5,000 synthetic bars.
// Measured on a SHARED, loaded CPU: report ratios, not absolute budgets.
import { describe, it, expect, beforeEach } from 'vitest'
import {
  computeRuntimeColumns, resetRuntimeSessions, runtimeIncrementalOf, runtimeSessionStats,
} from '../../components/chart/engine/runtime/runtimeColumns.js'
import { runtimeWarmupOf } from '../../components/chart/engine/runtime/runtimeObjects.js'

const SUPERTREND = `//@version=5
indicator("PA5 Supertrend", overlay = true)
atrLen = input.int(10, "ATR length")
mult = input.float(3.0, "Multiplier")
atr = ta.atr(atrLen)
src = hl2
var float up = na
var float dn = na
var int dir = 1
basicUp = src - mult * atr
basicDn = src + mult * atr
prevUp = nz(up, basicUp)
prevDn = nz(dn, basicDn)
up := close[1] > prevUp ? math.max(basicUp, prevUp) : basicUp
dn := close[1] < prevDn ? math.min(basicDn, prevDn) : basicDn
dir := dir == -1 and close > prevDn ? 1 : dir == 1 and close < prevUp ? -1 : dir
plot(dir == 1 ? up : na, "Up")
plot(dir == -1 ? dn : na, "Down")
`
const BASELINE = `//@version=5
indicator("PA5 SMA baseline", overlay = true)
plot(ta.sma(close, 20), "SMA")
plot(ta.sma(close, 50), "SMA50")
`

let seed = 11
const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647 }
function makeBars(n) {
  seed = 11
  const out = []
  let p = 100
  for (let i = 0; i < n; i += 1) {
    const c = Math.max(1, p + (rnd() - 0.5) * 2)
    out.push({ t: 1500000000 + i * 86400, o: p, h: Math.max(p, c) + rnd(), l: Math.min(p, c) - rnd(), c, v: 1e5 + Math.round(rnd() * 5e4) })
    p = c
  }
  return out
}
const doc = (source, { listing = false } = {}) => ({
  id: listing ? 'pa5-l' : 'pa5', ...(listing ? { meta: { runtimeHistory: 'listing' } } : {}),
  compute: { kind: 'runtime', fn: 'runtime:pa5', outputs: { up: 0, dn: 1 }, source },
})
const now = () => performance.now()
const median = (xs) => { const s = [...xs].sort((a, b) => a - b); return s[Math.floor(s.length / 2)] }

function timeIt(fn, reps = 5) {
  const ts = []
  let out
  for (let r = 0; r < reps; r += 1) { const t0 = now(); out = fn(); ts.push(now() - t0) }
  return { ms: median(ts), out }
}

describe('PA5 runtime Supertrend, 5,000 synthetic bars (shared CPU: ratios only)', () => {
  beforeEach(() => resetRuntimeSessions())
  it('cold vs resume-after-1-bar-append vs tick', () => {
    const N = 5000
    const all = makeBars(N + 2)
    const rows = all.slice(0, N)
    const ctx = { tf: 'D', newestBarIsForming: true, historyFromListing: true }
    const d = doc(SUPERTREND)

    // warm the JIT once (not measured)
    computeRuntimeColumns(d, rows, ctx, { incremental: false })

    const cold = timeIt(() => computeRuntimeColumns(d, rows, ctx, { incremental: false }))
    const base = timeIt(() => computeRuntimeColumns(doc(BASELINE), rows, ctx, { incremental: false }))
    expect(cold.out.up.length).toBe(N)
    const finiteUp = Array.from(cold.out.up).filter(Number.isFinite).length
    const finiteDn = Array.from(cold.out.dn).filter(Number.isFinite).length

    // resume: a session-backed run on N bars, then one bar appended (old forming bar confirmed)
    const appendTimes = []
    const tickTimes = []
    let resumedAppends = 0
    let resumedTicks = 0
    for (let r = 0; r < 5; r += 1) {
      resetRuntimeSessions()
      computeRuntimeColumns(d, rows, ctx) // leaves a session
      const appended = all.slice(0, N + 1)
      let t0 = now()
      const a = computeRuntimeColumns(d, appended, ctx)
      appendTimes.push(now() - t0)
      if ((runtimeIncrementalOf(a) || {}).resumedFrom != null) resumedAppends += 1
      // a tick: the forming bar's close moves
      const ticked = appended.map((b, i) => (i === N ? { ...b, c: b.c + 0.01 } : b))
      t0 = now()
      const t = computeRuntimeColumns(d, ticked, ctx)
      tickTimes.push(now() - t0)
      if ((runtimeIncrementalOf(t) || {}).resumedFrom != null) resumedTicks += 1
      // equality with a full run on the appended bars
      const full = computeRuntimeColumns(d, ticked, ctx, { incremental: false })
      for (const k of ['up', 'dn']) for (let i = 0; i < full[k].length; i += 1) {
        if (!Object.is(full[k][i], t[k][i])) expect.fail(`${k}[${i}]`)
      }
    }
    const stats = runtimeSessionStats()

    // warm-up curtain path: same script, history NOT from listing -> two runs (A and B)
    const dl = doc(SUPERTREND, { listing: true })
    const ctxOff = { ...ctx, historyFromListing: false }
    computeRuntimeColumns(dl, rows, ctxOff, { incremental: false })
    const curtain = timeIt(() => computeRuntimeColumns(dl, rows, ctxOff, { incremental: false }))
    const warm = runtimeWarmupOf(curtain.out)

    const append = median(appendTimes)
    const tick = median(tickTimes)
    const report = {
      bars: N,
      cold_ms_median: +cold.ms.toFixed(2),
      baseline_sma_cold_ms: +base.ms.toFixed(2),
      append_ms_median: +append.toFixed(2),
      tick_ms_median: +tick.toFixed(2),
      cold_over_append: +(cold.ms / append).toFixed(1),
      cold_over_tick: +(cold.ms / tick).toFixed(1),
      supertrend_over_sma_baseline: +(cold.ms / base.ms).toFixed(2),
      curtain_two_run_ms: +curtain.ms.toFixed(2),
      curtain_over_cold: +(curtain.ms / cold.ms).toFixed(2),
      curtain_withheld_bars: warm ? warm.withheldBars : null,
      resumed_appends: `${resumedAppends}/5`,
      resumed_ticks: `${resumedTicks}/5`,
      finite_up: finiteUp,
      finite_dn: finiteDn,
      us_per_bar_cold: +((cold.ms * 1000) / N).toFixed(2),
      sessions_after: stats,
    }
    // eslint-disable-next-line no-console
    console.log('PA5_RESULT ' + JSON.stringify(report))
    expect(finiteUp + finiteDn).toBeGreaterThan(N * 0.9)
  }, 120000)
})

describe('PA5 scaling + fixed cost (shared CPU: ratios only)', () => {
  it('50 / 5,000 / 32,000 bars, cold and resume', () => {
    const out = {}
    for (const N of [50, 5000, 32000]) {
      const all = makeBars(N + 1)
      const rows = all.slice(0, N)
      const ctx = { tf: 'D', newestBarIsForming: true, historyFromListing: true }
      const d = doc(SUPERTREND)
      computeRuntimeColumns(d, rows, ctx, { incremental: false })
      const cold = timeIt(() => computeRuntimeColumns(d, rows, ctx, { incremental: false }), 5)
      const app = []
      for (let r = 0; r < 5; r += 1) {
        resetRuntimeSessions()
        computeRuntimeColumns(d, rows, ctx)
        const t0 = now(); computeRuntimeColumns(d, all, ctx); app.push(now() - t0)
      }
      out[N] = { cold_ms: +cold.ms.toFixed(2), append_ms: +median(app).toFixed(2), sess: runtimeSessionStats().approxBytes }
    }
    // eslint-disable-next-line no-console
    console.log('PA5_SCALE ' + JSON.stringify(out))
    expect(out[5000].cold_ms).toBeGreaterThan(0)
  }, 120000)
})
