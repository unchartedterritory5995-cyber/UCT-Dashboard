import { it, vi } from 'vitest'
import fs from 'node:fs'
import path from 'node:path'
import { memberPaneDefinition } from '../../components/chart/builder/memberPane/memberPaneDefinition.js'
import { interpret } from '../../components/chart/engine/ast/interpret.js'
import { objectReaderFor } from '../../components/chart/engine/objectColumns.js'
import { evaluateObjects } from '../../components/chart/engine/objectRuntime.js'
import { makeBars, sma } from './refs.js'
const CORPUS = path.resolve(__dirname, '../../../../docs/indicators/audit-2026-10-13/migration-corpus/pine')
const bars = makeBars(1500, 7)
it('paints + objects', () => {
  vi.stubEnv('VITE_PINE_OBJECTS_ONLY_PANE_ENABLED', '1')
  const rd = (f) => fs.readFileSync(path.join(CORPUS, f), 'utf8')
  // volume spike paint condition
  {
    const p = memberPaneDefinition({ source: rd('09-volume-spike-bg.pine'), id: 'u_member-pane-pa' })
    const d = p.definition
    const key = d.paints[0].colorMode.slice(7)
    const row = d.plots.find((x) => x.key === key)
    const t = p.translation
    const inputs = Object.fromEntries((d.inputs || []).map((i) => [i.key, i.default]))
    const tree = (d.compute.trees && d.compute.trees[key]) || (key === 'value' ? d.compute.ast : null)
    const v = Array.from(interpret(tree || row.ast, bars, inputs, undefined, undefined, { tf: 'D' }))
    const av = sma(bars.map((b) => b.v), 20)
    let ok = 0; let bad = 0
    for (let i = 300; i < bars.length; i++) { const want = bars[i].v > av[i] * 2 ? 0 : 1; if (v[i] === want) ok++; else bad++ }
    console.log('PAINT volume-spike key', key, 'palette', JSON.stringify(d.paints[0].colorPalette), 'opacity', d.paints[0].opacity, 'sample', JSON.stringify(v.slice(300, 310)), 'agree(palette idx 0=spike)', ok, 'disagree', bad, 'treesKeys', Object.keys(d.compute.trees || {}))
  }
  // pivots objects with a symbol whose tick is witnessed
  {
    const p = memberPaneDefinition({ source: rd('11-pivots-labels-lines.pine'), id: 'u_member-pane-pb' })
    const d = p.definition
    for (const symbol of [undefined, { ticker: 'AAPL', exchange: 'NASDAQ' }]) {
      const reader = objectReaderFor(d, bars, { tf: 'D', newestBarIsForming: false, historyFromListing: true, symbol })
      const out = evaluateObjects(reader.program, { barCount: bars.length, readNode: reader.readNode, readTime: (i) => bars[i].t, readUnknown: reader.readUnknown })
      const live = [...out.live]
      const labels = live.filter((o) => o.family === 'label')
      const lines = live.filter((o) => o.family === 'line')
      // reference pivots
      let nph = 0; let npl = 0
      for (let i = 10; i < bars.length; i++) {
        const c = i - 5; let ph = true; let pl = true
        for (let k = 1; k <= 5; k++) { if (!(bars[c].h > bars[c - k].h && bars[c].h > bars[c + k].h)) ph = false; if (!(bars[c].l < bars[c - k].l && bars[c].l < bars[c + k].l)) pl = false }
        if (ph) nph++; if (pl) npl++
      }
      console.log('OBJ pivots symbol', JSON.stringify(symbol), 'labels', labels.length, 'lines', lines.length, 'created', out.stats.created, 'refPivots ph', nph, 'pl', npl, 'textsWithheld', out.stats.textsWithheld || 0, 'lastLabel', JSON.stringify(labels[labels.length - 1] && labels[labels.length - 1].props), 'status', out.status, out.reason || '')
    }
  }
})
