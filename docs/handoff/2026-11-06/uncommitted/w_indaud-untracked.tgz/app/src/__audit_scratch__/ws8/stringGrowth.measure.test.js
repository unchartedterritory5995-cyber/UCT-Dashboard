// WS8 scratch — NOT committed. Does the runtime VM bound string growth?
import { it, expect } from 'vitest'
import { computeRuntimeColumns } from '../../components/chart/engine/runtime/runtimeColumns'
it('doubling string per bar', () => {
  const head = '//@version=6\nindicator("t", overlay = true)\n'
  const src = 'var string s = "x"\ns := s + s\nplot(str.length(s))\n'
  const rows = Array.from({ length: 200 }, (_, i) => ({ t: 1136160000 + i * 86400, o: 1, h: 2, l: 0.5, c: 1.5, v: 10 }))
  const t0 = performance.now()
  let res = null
  try {
    computeRuntimeColumns({ id: 'sg', compute: { fn: 'sg', source: head + src, outputs: { v: 0 } } }, rows, { tf: 'D' }, { budgetMs: 1000, incremental: false })
    res = 'completed'
  } catch (e) { res = `${e && e.name} ${e && e.guard} :: ${String(e && e.message).slice(0, 200)}` }
  console.log(JSON.stringify({ bench: 'string-growth', ms: +(performance.now() - t0).toFixed(1), res }))
  expect(res).not.toBeNull()
})
