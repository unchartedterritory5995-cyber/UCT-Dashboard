// WS4 AUDIT SCRATCH — NOT FOR COMMIT.
import { it } from 'vitest'
import fs from 'node:fs'
import { evaluateFormula } from '../../components/chart/builder/FormulaField'
import { interpret } from '../../components/chart/engine/ast/interpret.js'
const BARS = JSON.parse(fs.readFileSync('src/pages/parityBars/intraday5m.json', 'utf8')).bars
it('probe3', () => {
  const out = {}
  for (const s of ["tf(close, 'D')", "tf(close, '60')", "tf(close, 'W')", 'vwap()', 'close > vwap()', "close > tf(high, 'D')[1]"]) {
    const ev = evaluateFormula(s)
    if (!ev.ok) { out[s] = `${ev.guard}: ${String(ev.error).slice(0, 200)}`; continue }
    try { const c = [...interpret(ev.ast, BARS, {}, undefined, {}, { tf: '5' })]; out[s] = `finite=${c.filter(Number.isFinite).length}/${c.length}` } catch (e) { out[s] = `interp ${e.guard}: ${String(e.message).slice(0, 200)}` }
  }
  fs.writeFileSync('src/__audit_scratch__/ws4/probe3.json', JSON.stringify(out, null, 1))
})
