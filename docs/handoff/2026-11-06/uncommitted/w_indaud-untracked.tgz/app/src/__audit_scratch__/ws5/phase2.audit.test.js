// WS5 audit scratch (NOT committed): numeric + object + paint checks with the
// document's own input defaults, plus a run with the DARK runtime lane on.
import { describe, it, vi, afterAll } from 'vitest'
import fs from 'node:fs'
import path from 'node:path'
import { memberPaneDefinition } from '../../components/chart/builder/memberPane/memberPaneDefinition.js'
import { interpret } from '../../components/chart/engine/ast/interpret.js'
import { objectReaderFor } from '../../components/chart/engine/objectColumns.js'
import { evaluateObjects } from '../../components/chart/engine/objectRuntime.js'
import { runtimeColumnsFor } from '../../components/chart/engine/runtime/runtimeColumns.js'
import { makeBars, refs, rsi, atr, sma } from './refs.js'

const CORPUS = path.resolve(__dirname, '../../../../docs/indicators/audit-2026-10-13/migration-corpus/pine')
const OUT = process.env.WS5_OUT || path.resolve(__dirname, 'out')
const files = fs.readdirSync(CORPUS).filter((f) => f.endsWith('.pine')).sort()
const bars = makeBars(1500, 7)
const spy = makeBars(1500, 99)

function cmp(ours, ref, from = 300) {
  let worst = 0; let compared = 0; let naMismatch = 0; let firstNa = null
  for (let i = from; i < ref.length; i++) {
    const a = ours[i]; const b = ref[i]
    const fa = Number.isFinite(a); const fb = Number.isFinite(b)
    if (fa !== fb) { naMismatch++; if (firstNa === null) firstNa = { i, ours: a, ref: b }; continue }
    if (!fa) continue
    compared++
    const d = Math.abs(a - b) / Math.max(1e-12, Math.abs(b))
    if (d > worst) worst = d
  }
  return { worstRel: worst, compared, naMismatch, firstNa }
}

const results = {}
afterAll(() => {
  fs.mkdirSync(OUT, { recursive: true })
  fs.writeFileSync(path.join(OUT, 'phase2.json'), JSON.stringify(results, null, 1))
  vi.unstubAllEnvs()
})

describe('host lane (production flags) — values with the document inputs', () => {
  for (const f of files) {
    it(f, () => {
      vi.stubEnv('VITE_PINE_OBJECTS_ONLY_PANE_ENABLED', '1')
      vi.stubEnv('VITE_PINE_RUNTIME_PANE_ENABLED', '0')
      const src = fs.readFileSync(path.join(CORPUS, f), 'utf8')
      const pane = memberPaneDefinition({ source: src, id: 'u_member-pane-ws5b' })
      const rec = { ok: pane.ok, reason: pane.reason && pane.reason.slice(0, 160) }
      if (pane.ok) {
        const d = pane.definition
        const inputs = Object.fromEntries((d.inputs || []).map((i) => [i.key, i.default]))
        const ref = refs[f] ? refs[f](bars, spy) : {}
        rec.plots = {}
        for (const p of d.plots || []) {
          let vals
          try { vals = Array.from(interpret(p.ast, bars, inputs, undefined, undefined, { symbols: { SPY: spy } })) } catch (e) { vals = String(e.message).slice(0, 120) }
          const r = { label: p.label, hidden: !!p.hidden, style: p.style, color: p.color, colorMode: p.colorMode }
          if (Array.isArray(vals)) {
            r.finite = vals.filter(Number.isFinite).length
            if (ref[p.label]) r.vsRef = cmp(vals, ref[p.label])
            if (p.hidden && p.label === '' ) r.sampleTail = vals.slice(-5)
          } else r.error = vals
          rec.plots[p.key] = r
        }
        if (d.objects) {
          try {
            const reader = objectReaderFor(d, bars, { tf: 'D', newestBarIsForming: false, historyFromListing: true })
            const out = evaluateObjects(reader.program, { barCount: bars.length, readNode: reader.readNode, readTime: (i) => bars[i].t, readUnknown: reader.readUnknown })
            const live = [...out.live]
            rec.objects = { live: live.length, families: {}, sample: live.slice(-3), stats: out.stats, cells: out.cells ? out.cells : undefined, keys: Object.keys(out) }
            for (const o of live) rec.objects.families[o.family || o.kind || o.type] = (rec.objects.families[o.family || o.kind || o.type] || 0) + 1
            rec.objects.all = live
            if (out.tables) rec.objects.tables = out.tables
          } catch (e) { rec.objects = { error: String(e && e.stack).slice(0, 400) } }
        }
      }
      results[`host:${f}`] = rec
    })
  }
})

describe('DARK runtime lane switched on (what exists in code, not what members get)', () => {
  for (const f of ['05-supertrend-var.pine', '10-atr-trailing-stop.pine', '16-missing-function.pine', '14-strategy.pine', '07-rs-vs-spy.pine']) {
    it(f, () => {
      vi.stubEnv('VITE_PINE_OBJECTS_ONLY_PANE_ENABLED', '1')
      vi.stubEnv('VITE_PINE_RUNTIME_PANE_ENABLED', '1')
      const src = fs.readFileSync(path.join(CORPUS, f), 'utf8')
      const pane = memberPaneDefinition({ source: src, id: 'u_member-pane-ws5c' })
      const rec = { ok: pane.ok, reason: pane.reason, guard: pane.guard, runtimeDeclined: pane.runtimeDeclined, notes: pane.notes }
      if (pane.ok) {
        const d = pane.definition
        rec.computeKind = d.compute && d.compute.kind
        rec.plots = (d.plots || []).map((p) => ({ key: p.key, label: p.label, hidden: p.hidden, color: p.color, colorMode: p.colorMode }))
        try {
          const cols = runtimeColumnsFor(d, bars, undefined, { tf: 'D', newestBarIsForming: false })
          const ref = refs[f] ? refs[f](bars, spy) : {}
          rec.cols = {}
          for (const p of d.plots || []) {
            const v = cols[p.key]
            if (!v) { rec.cols[p.key] = 'missing'; continue }
            rec.cols[p.key] = { label: p.label, finite: Array.from(v).filter(Number.isFinite).length, vsRef: ref[p.label] ? cmp(Array.from(v), ref[p.label]) : null }
          }
        } catch (e) { rec.colsError = String((e && e.message) || e).slice(0, 300) }
      }
      results[`runtime:${f}`] = rec
    })
  }
})

describe('table dashboard reference values (last bar)', () => {
  it('reference', () => {
    const c = bars.map((b) => b.c)
    const n = bars.length - 1
    results.tableRef = { rsi: rsi(c, 14)[n], atr: atr(bars, 14)[n], chg: (c[n] - c[n - 1]) / c[n - 1] * 100 }
    results.smaCheck = sma(c, 20)[n]
  })
})
