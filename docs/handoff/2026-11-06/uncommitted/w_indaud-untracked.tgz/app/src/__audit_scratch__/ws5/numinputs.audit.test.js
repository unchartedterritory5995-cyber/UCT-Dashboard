import { it, vi } from 'vitest'
import fs from 'node:fs'
import path from 'node:path'
import { memberPaneDefinition } from '../../components/chart/builder/memberPane/memberPaneDefinition.js'
import { interpret } from '../../components/chart/engine/ast/interpret.js'
import { makeBars, refs } from './refs.js'
const CORPUS = path.resolve(__dirname, '../../../../docs/indicators/audit-2026-10-13/migration-corpus/pine')
const bars = makeBars(1500, 7); const spy = makeBars(1500, 99)
it('numerics with document inputs', () => {
  vi.stubEnv('VITE_PINE_OBJECTS_ONLY_PANE_ENABLED', '1')
  for (const f of fs.readdirSync(CORPUS).filter((x) => x.endsWith('.pine'))) {
    const pane = memberPaneDefinition({ source: fs.readFileSync(path.join(CORPUS, f), 'utf8'), id: 'u_member-pane-ni' })
    if (!pane.ok) continue
    const inputs = Object.fromEntries((pane.definition.inputs || []).map((i) => [i.key, i.default]))
    const ref = refs[f] ? refs[f](bars, spy) : {}
    const out = []
    for (const o of pane.translation.outputs.filter((x) => x && x.ast && x.kind !== 'alertcondition')) {
      const v = Array.from(interpret(o.ast, bars, inputs, undefined, undefined, { tf: 'D', symbols: { SPY: spy } }))
      const r = ref[o.title]
      if (!r) { out.push(`${o.title}:noref(finite ${v.filter(Number.isFinite).length})`); continue }
      let worst = 0; let n = 0; let nm = 0
      for (let i = 300; i < r.length; i++) { const fa = Number.isFinite(v[i]); const fb = Number.isFinite(r[i]); if (fa !== fb) { nm++; continue } if (!fa) continue; n++; worst = Math.max(worst, Math.abs(v[i] - r[i]) / Math.max(1e-12, Math.abs(r[i]))) }
      out.push(`${o.title}:cmp=${n},naMismatch=${nm},maxRel=${worst.toExponential(1)}`)
    }
    console.log('NUM', f, out.join(' | '))
  }
})
