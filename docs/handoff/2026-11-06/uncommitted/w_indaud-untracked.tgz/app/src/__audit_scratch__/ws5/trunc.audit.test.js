import { it, vi } from 'vitest'
import fs from 'node:fs'
import path from 'node:path'
import { memberPaneDefinition } from '../../components/chart/builder/memberPane/memberPaneDefinition.js'
import { interpret } from '../../components/chart/engine/ast/interpret.js'
import { makeBars } from './refs.js'
const CORPUS = path.resolve(__dirname, '../../../../docs/indicators/audit-2026-10-13/migration-corpus/pine')
const bars = makeBars(900, 7); const spy = makeBars(900, 99)
it('truncation (no-lookahead) check', () => {
  vi.stubEnv('VITE_PINE_OBJECTS_ONLY_PANE_ENABLED', '1')
  const L = String.fromCharCode(10)
  const extra = { 'mtf-on-no-offset': ['//@version=5', 'indicator("m", overlay = true)', 'plot(request.security(syminfo.tickerid, "W", close, lookahead = barmerge.lookahead_on), "X")'].join(L) }
  const srcs = Object.fromEntries(fs.readdirSync(CORPUS).filter((f) => f.endsWith('.pine')).map((f) => [f, fs.readFileSync(path.join(CORPUS, f), 'utf8')]))
  for (const [name, src] of Object.entries({ ...srcs, ...extra })) {
    const pane = memberPaneDefinition({ source: src, id: 'u_member-pane-tr' })
    if (!pane.ok) continue
    const inputs = Object.fromEntries((pane.definition.inputs || []).map((i) => [i.key, i.default]))
    const res = []
    for (const o of pane.translation.outputs.filter((x) => x && x.ast)) {
      const ev = (b, s) => Array.from(interpret(o.ast, b, inputs, undefined, undefined, { tf: 'D', symbols: { SPY: s } }))
      let full
      try { full = ev(bars, spy) } catch (e) { res.push(`${o.title}:ERR`); continue }
      let changed = 0
      for (const cut of [333, 611, 850]) {
        const w = ev(bars.slice(0, cut), spy.slice(0, cut))
        for (let i = 0; i < cut - 1; i++) if (!(w[i] === full[i] || (Number.isNaN(w[i]) && Number.isNaN(full[i])))) changed++
      }
      res.push(`${o.title || o.kind}:${changed}`)
    }
    console.log('TRUNC', name, res.join(' '))
  }
})
