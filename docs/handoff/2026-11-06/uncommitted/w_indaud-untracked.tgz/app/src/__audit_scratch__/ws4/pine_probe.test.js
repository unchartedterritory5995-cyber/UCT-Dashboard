// WS4 AUDIT SCRATCH — NOT FOR COMMIT. What the Pine / thinkScript doors admit
// that the native formula box cannot, plus a few native lint/error probes.
import { describe, it } from 'vitest'
import fs from 'node:fs'
import path from 'node:path'
import { translatePine } from '../../components/chart/engine/ast/pine.js'
import { translateThinkScript } from '../../components/chart/engine/ast/thinkscript.js'
import { evaluateFormula } from '../../components/chart/builder/FormulaField'

const OUT = path.join(process.cwd(), 'src', '__audit_scratch__', 'ws4')
const H = '//@version=5\nindicator("probe", overlay=true)\n'
const PINE = {
  udf: H + 'f(x, n) => ta.ema(x, n) - ta.sma(x, n)\nplot(f(close, 20))',
  multiplot: H + 'plot(ta.ema(close, 9))\nplot(ta.ema(close, 20))',
  inputLen: H + 'len = input.int(20, "Length")\nplot(ta.sma(close, len))',
  barcolor: H + 'c = ta.ema(close, 9) > ta.ema(close, 20) and volume > ta.sma(volume, 20)\nbarcolor(c ? color.green : na)',
  bgcolor: H + 'ma = ta.sma(close, 50)\nhot = ta.rsi(close, 14) > 70 and close > ma and ma > ma[1]\nbgcolor(hot ? color.new(color.orange, 80) : na)',
  security: H + 'w = request.security(syminfo.tickerid, "W", ta.sma(close, 10))\nplot(w)',
  loop: H + 's = 0.0\nfor i = 0 to 9\n    s += close[i]\nplot(s / 10)',
  varState: H + 'var float hi = na\nhi := na(hi) or high > hi ? high : hi\nplot(hi)',
  dema: H + 'e = ta.ema(close, 20)\nplot(2 * e - ta.ema(e, 20))',
  alma: H + 'plot(ta.alma(close, 9, 0.85, 6))',
  supertrend: H + '[st, dir] = ta.supertrend(3, 10)\nplot(st)',
  array: H + 'a = array.new_float(0)\narray.push(a, close)\nplot(array.get(a, 0))',
  alertcond: H + 'alertcondition(ta.crossover(close, ta.sma(close, 50)), "x", "y")\nplot(close)',
}
const TOS = {
  basic: 'plot x = ExpAverage(close, 9) - ExpAverage(close, 20);',
  assign: 'def fast = ExpAverage(close, 9);\ndef slow = ExpAverage(close, 20);\nplot cross = fast > slow;',
}
const NATIVE = ['pivothigh(high, 5, 5)', 'pivothigh(high, 5, 5) > 0', 'close > open and volume > 0', 'C > O',
  'close > open AND volume > 0', 'ltf(close, \'60\') > open', 'sma(close, 20) > sma(close, 50) &&',
  'close > highest(high, 20)[1]', 'crossOver(close, vwap())']

function summarise(t) {
  if (!t) return null
  const o = { ok: t.ok, guard: t.guard, error: t.error && String(t.error).slice(0, 300) }
  if (t.ok) {
    o.outputs = (t.outputs || []).map((x) => ({ key: x.key, formula: x.formula && String(x.formula).slice(0, 140) }))
    o.paints = t.paints ? t.paints.length : 0
    o.keys = Object.keys(t).slice(0, 30)
  }
  if (t.refusals) o.refusals = JSON.stringify(t.refusals).slice(0, 300)
  if (t.compute) o.computeKind = t.compute.kind
  return o
}

describe('WS4 door probe', () => {
  it('runs', () => {
    const res = {}
    for (const [k, s] of Object.entries(PINE)) {
      try { res[`pine:${k}`] = summarise(translatePine(s)) } catch (e) { res[`pine:${k}`] = `THROW ${e.message}` }
    }
    for (const [k, s] of Object.entries(TOS)) {
      try { res[`tos:${k}`] = summarise(translateThinkScript(s)) } catch (e) { res[`tos:${k}`] = `THROW ${e.message}` }
    }
    for (const s of NATIVE) {
      const ev = evaluateFormula(s)
      res[`native:${s}`] = { ok: ev.ok, dialect: ev.dialect, guard: ev.guard, error: ev.error && ev.error.slice(0, 220), repaint: ev.verdict && ev.verdict.mode, verdictReasons: ev.verdict && ev.verdict.reasons, forward: ev.verdict && ev.verdict.forward }
    }
    fs.writeFileSync(path.join(OUT, 'door_probe.json'), JSON.stringify(res, null, 1))
  })
})
