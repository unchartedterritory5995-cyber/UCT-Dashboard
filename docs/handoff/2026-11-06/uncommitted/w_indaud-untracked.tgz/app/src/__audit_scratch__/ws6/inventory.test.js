import { it } from 'vitest'
import * as TS from '../../components/chart/engine/ast/thinkscript.js'
import * as P from '../../components/chart/engine/ast/pcf.js'
import fs from 'fs'
it('dump', () => {
  const out = {
    shapes: Object.keys(TS.TS_CALL_SHAPES),
    uncited: Object.fromEntries(Object.entries(TS.TS_UNCITED).map(([k,v])=>[k, typeof v==='string'?v.slice(0,160):JSON.stringify(v).slice(0,160)])),
    docBlocked: Object.keys(TS.TS_DOC_BLOCKED),
    pcfVocab: P.PCF_VOCABULARY, pcfFused: Object.keys(P.PCF_FUSED), pcfCalls: Object.keys(P.PCF_CALLS),
    pcfDifferent: Object.keys(P.PCF_DIFFERENT_FORMULA),
    coverage: P.pcfCoverage(),
  }
  fs.writeFileSync('src/__audit_scratch__/ws6/inventory.json', JSON.stringify(out, null, 1))
})
