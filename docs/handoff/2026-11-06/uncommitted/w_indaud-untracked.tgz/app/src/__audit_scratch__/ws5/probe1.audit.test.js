import { it } from 'vitest'
import fs from 'node:fs'
import path from 'node:path'
import { inspectSource } from '../../components/chart/builder/PineBox.jsx'
import { memberPaneDefinition } from '../../components/chart/builder/memberPane/memberPaneDefinition.js'
const REPO = path.resolve(__dirname, '../../../..')
it('probe', () => {
  for (const f of ['mcclellan-indicators-spy-1d-2026-10-03.json', 'atr-trailing-stop-by-ceyhun-spy-1d-2026-10-02.json', 'trendlines-spy-1d-2026-10-03.json', 'twin-range-filter-rddt-1d-2026-10-02.json']) {
    const cap = JSON.parse(fs.readFileSync(path.join(REPO, 'tests/fixtures/vendor/harness', f), 'utf8'))
    const src = cap.source.text
    const rep = inspectSource(src, 'auto')
    const o = rep.outcome
    console.log('##', f, o.verdict, '|', o.reason)
    for (const k of ['missing', 'semantic', 'presentation']) for (const n of o[k]) console.log('   [' + k + ']', n.name, ':', String(n.note || n.message).slice(0, 220))
    const pane = memberPaneDefinition({ source: src, id: 'u_member-pane-p1' })
    console.log('   pane', pane.ok, (pane.notes || []).map((n) => n.name + ': ' + String(n.note).slice(0, 160)).join(' || '))
    console.log('   otherSymbols', JSON.stringify(pane.translation && pane.translation.otherSymbols), 'lowerTf', JSON.stringify(pane.translation && pane.translation.lowerTf))
  }
})
