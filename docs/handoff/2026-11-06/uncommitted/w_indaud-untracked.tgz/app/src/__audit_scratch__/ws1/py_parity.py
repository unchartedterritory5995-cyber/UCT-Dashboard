import json, math, sys
sys.path.insert(0, 'C:/w/indaud')
from api.services import indicator_compute as ic
D = json.load(open('C:/w/indaud/app/src/__audit_scratch__/ws1/bars_daily.json'))
I = json.load(open('C:/w/indaud/app/src/__audit_scratch__/ws1/bars_intraday.json'))
J = json.load(open('C:/w/indaud/app/src/__audit_scratch__/ws1/js_cols.json'))
def cmp(name, py, js):
    mx = 0.0; both = 0; onlyp = 0; onlyj = 0
    for a, b in zip(py, js):
        fa = a is not None and not (isinstance(a, float) and math.isnan(a)); fb = b is not None
        if fa and fb: both += 1; mx = max(mx, abs(a - b))
        elif fa: onlyp += 1
        elif fb: onlyj += 1
    print(f"{name:16s} compared={both:4d} onlyPy={onlyp} onlyJs={onlyj} maxAbs={mx:.3e} lenPy={len(py)} lenJs={len(js)}")
cl = [b['c'] for b in D]
cmp('rsi', ic.compute_rsi_raw(cl, 14), J['rsi'])
cmp('atr', ic.compute_atr_raw(D, 14), J['atr'])
u, m, l = ic.compute_bb_raw(cl, 20, 2.0); cmp('bb_upper', u, J['bb_upper'])
mc, sg, h = ic.compute_macd_raw(cl, 12, 26, 9); cmp('macd', mc, J['macd']); cmp('signal', sg, J['signal'])
k, d = ic.compute_stoch_raw(D, 14, 3); cmp('stoch_k', k, J['stoch_k']); cmp('stoch_d', d, J['stoch_d'])
cmp('obv', ic.compute_obv_raw(D), J['obv'])
cmp('vwap', ic.compute_vwap_raw(I), J['vwap'])
cmp('cci', ic.compute_cci_raw(D, 20), J['cci'])
cmp('mfi', ic.compute_mfi_raw(D, 14), J['mfi'])
cmp('williams_r', ic.compute_williams_r_raw(D, 14), J['williams_r'])
cmp('adx', ic.compute_adx_raw(D, 14)[0], J['adx'])
r = ic.compute_case('sar', D, {}); cmp('sar', r['sar'], J['sar'])
r = ic.compute_case('ichimoku', D, {}); cmp('spanA', r['spanA'], J['spanA']); cmp('chikou', r['chikou'], J['chikou'])
r = ic.compute_case('donchian', D, {}); cmp('donchian_upper', r['upper'], J['donchian_upper'])
r = ic.compute_case('atr_bands', D, {}); cmp('atrBands_upper', r['upper'], J['atrBands_upper'])
cmp('avwap_week', ic.compute_avwap_raw(I, 'week'), J['avwap_week'])
# delivery-wrapper rounding vs raw
print('rsi delivery max rounding delta', max(abs(a-b) for a,b in zip(ic.compute_rsi(cl,14), ic.compute_rsi_raw(cl,14)) if a is not None))
