import { it, expect } from 'vitest'
import { presentedPlot, availableStyles, PLOT_STYLE_CHOICES } from '../../components/chart/engine/presentation'
import { seriesOptionsForPlot } from '../../components/chart/engine/pool'
it('Last value horizontal is offered and renders exactly as Line', () => {
  const plot = { key: 'v', style: 'line', color: '#123456', legend: { decimals: 2 } }
  expect(availableStyles(plot, { target: 'pane' })).toContain('lastValueHorizontal')
  expect(PLOT_STYLE_CHOICES.map((c) => c.value)).toContain('lastValueHorizontal')
  const lvh = presentedPlot(plot, { instanceId: 'i', presentation: { plotStyle: 'lastValueHorizontal' } }, {})
  const line = presentedPlot(plot, { instanceId: 'i', presentation: { plotStyle: 'line' } }, {})
  expect(lvh).toBe(plot) // identity: nothing changes
  expect(JSON.stringify(seriesOptionsForPlot(lvh, {}))).toBe(JSON.stringify(seriesOptionsForPlot(line, {})))
  console.log('[WS2 LVH] options identical to Line; lineVisible=', seriesOptionsForPlot(lvh, {}).lineVisible)
})
