import { test } from 'vitest'
import fs from 'node:fs'
import { NATIVE_DEFS, SERVER_DEFS, CARVED_OUT_INDICATOR_KEYS } from '../../components/chart/engine/nativeRegistry'
test('dump', () => {
  const out = [...NATIVE_DEFS, ...SERVER_DEFS].map(d => ({
    id: d.id, name: d.meta?.name, cat: d.meta?.category, kind: d.compute?.kind, fn: d.compute?.fn, rev: d.compute?.rev,
    tier: d.meta?.tier, repaint: d.meta?.repaint, tfs: d.meta?.timeframes, hidden: d.meta?.hidden, discover: d.meta?.discoverable,
    target: d.placement?.target, scale: d.placement?.scale,
    inputs: (d.inputs||[]).filter(i=>i.type!=='color').map(i => `${i.key}:${i.type}=${JSON.stringify(i.default)}${i.min!=null?`[${i.min}-${i.max}]`:''}${i.options?'{'+i.options.map(o=>Array.isArray(o)?o[0]:o).join('|')+'}':''}`),
    plots: (d.plots||[]).map(p => `${p.key}:${p.style}`),
    metaKeys: Object.keys(d.meta||{}),
  }))
  fs.writeFileSync('src/__audit_scratch__/ws1/registry.json', JSON.stringify({ n: out.length, carved: [...CARVED_OUT_INDICATOR_KEYS], out }, null, 1))
})
