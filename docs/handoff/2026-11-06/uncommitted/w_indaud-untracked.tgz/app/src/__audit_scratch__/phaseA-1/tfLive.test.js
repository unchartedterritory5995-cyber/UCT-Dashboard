import { it } from 'vitest'
import fs from 'fs'
import { interpret } from '../../components/chart/engine/ast/interpret.js'
import { parseFormula } from '../../components/chart/engine/ast/parse.js'
import { B } from './bars.js'
const N = B.length, C = B.map((b) => b.c)
const wk = B.map((b) => { const d = new Date(b.t * 1000); const day = (d.getUTCDay() + 6) % 7; return Math.floor((b.t - day * 86400) / 86400 / 7) })
const run = (s) => [...interpret(parseFormula(s).ast, B, {}, undefined, {})]
it('tf_live semantics', () => {
  const live = run("tf_live(close, 'W')")
  const finalOfWeek = B.map((_, i) => { let j = i; while (j + 1 < N && wk[j + 1] === wk[i]) j++; return C[j] })
  let eqC = 0, eqFinal = 0
  const T = 120
  for (let i = N - T; i < N; i++) { if (Math.abs(live[i] - C[i]) < 1e-9) eqC++; if (Math.abs(live[i] - finalOfWeek[i]) < 1e-9) eqFinal++ }
  const smaLive = run("tf_live(sma(close, 10), 'W')")
  // forming SMA as "(sum of 9 prior finals + C[i]) / 10"
  const finals = []; const doneAt = []
  for (let i = 0; i < N; i++) { doneAt.push(finals.length); if (i === N - 1 || wk[i + 1] !== wk[i]) finals.push(C[i]) }
  let eqForm = 0; const sample = []
  for (let i = N - T; i < N; i++) { const p = finals.slice(0, doneAt[i]).slice(-9); const ref = (p.reduce((a, b) => a + b, 0) + C[i]) / 10; if (Math.abs(smaLive[i] - ref) < 1e-9 * ref) eqForm++; if (sample.length < 6) sample.push([wk[i], +(smaLive[i] - ref).toFixed(6)]) }
  fs.writeFileSync('src/__audit_scratch__/phaseA-1/tfLive.json', JSON.stringify({ tail: T, tfLiveEqualsTodayClose: eqC, tfLiveEqualsWeekFinal: eqFinal, smaLiveEqualsFormingRef: eqForm, sample }, null, 1))
})
