import { it } from 'vitest'
import fs from 'fs'
import path from 'path'
import { inspectSource } from '../../components/chart/builder/PineBox.jsx'
import { interpret } from '../../components/chart/engine/ast/interpret.js'
const ROOT = 'C:/w/indaud/docs/indicators/audit-2026-10-13/migration-corpus'

// ---- synthetic daily bars (deterministic), weekdays only, unix seconds ----
function makeBars(n = 420) {
  let s = 12345; const rnd = () => { s = (s * 1103515245 + 12345) % 2147483648; return s / 2147483648 }
  const bars = []; let p = 50; let t = Date.UTC(2024, 0, 2) / 1000
  while (bars.length < n) {
    const d = new Date(t * 1000).getUTCDay()
    if (d !== 0 && d !== 6) {
      const drift = Math.sin(bars.length / 40) * 0.004
      const o = p * (1 + (rnd() - 0.5) * 0.02)
      const c = o * (1 + drift + (rnd() - 0.5) * 0.04)
      const h = Math.max(o, c) * (1 + rnd() * 0.015)
      const l = Math.min(o, c) * (1 - rnd() * 0.015)
      const v = Math.round(1e6 * (0.5 + rnd() * 1.5) * (rnd() < 0.05 ? 3 : 1))
      bars.push({ t, o, h, l, c, v }); p = c
    }
    t += 86400
  }
  return bars
}
export const B = makeBars()
const N = B.length
const C = B.map((b) => b.c), H = B.map((b) => b.h), L = B.map((b) => b.l), O = B.map((b) => b.o), V = B.map((b) => b.v)
const nanA = () => new Array(N).fill(NaN)
const lag = (x, k) => x.map((_, i) => (i - k >= 0 ? x[i - k] : NaN))
const sma = (x, n) => x.map((_, i) => { if (i < n - 1) return NaN; let s = 0; for (let j = i - n + 1; j <= i; j++) s += x[j]; return s / n })
const wma = (x, n) => x.map((_, i) => { if (i < n - 1) return NaN; let s = 0, w = 0; for (let j = 0; j < n; j++) { s += x[i - j] * (n - j); w += n - j } return s / w })
const sum = (x, n) => sma(x, n).map((v) => v * n)
const highest = (x, n) => x.map((_, i) => (i < n - 1 ? NaN : Math.max(...x.slice(i - n + 1, i + 1))))
const lowest = (x, n) => x.map((_, i) => (i < n - 1 ? NaN : Math.min(...x.slice(i - n + 1, i + 1))))
const stdevPop = (x, n) => x.map((_, i) => { if (i < n - 1) return NaN; const w = x.slice(i - n + 1, i + 1); const m = w.reduce((a, b) => a + b) / n; return Math.sqrt(w.reduce((a, b) => a + (b - m) ** 2, 0) / n) })
const stdevSamp = (x, n) => stdevPop(x, n).map((v) => v * Math.sqrt(n / (n - 1)))
// tos ExpAverage: EMA1 = price1 (seed on first finite value)
const emaFirst = (x, n) => { const a = 2 / (n + 1); const out = nanA(); let e = NaN; for (let i = 0; i < N; i++) { if (!Number.isFinite(x[i])) continue; e = Number.isFinite(e) ? e + a * (x[i] - e) : x[i]; out[i] = e } return out }
// Wilder: seed with SMA of first full window
const rma = (x, n) => { const out = nanA(); let e = NaN, cnt = 0, s = 0; for (let i = 0; i < N; i++) { if (!Number.isFinite(x[i])) continue; if (!Number.isFinite(e)) { s += x[i]; cnt++; if (cnt === n) { e = s / n; out[i] = e } continue } e = e + (x[i] - e) / n; out[i] = e } return out }
const hma = (x, n) => { const w2 = wma(x, Math.floor(n / 2)); const wn = wma(x, n); return wma(w2.map((v, i) => 2 * v - wn[i]), Math.floor(Math.sqrt(n))) }
const tr = B.map((b, i) => (i === 0 ? b.h - b.l : Math.max(b.h, C[i - 1]) - Math.min(b.l, C[i - 1])))
const b2 = (x) => x.map((v) => (v ? 1 : 0))
const zip = (f, ...xs) => xs[0].map((_, i) => f(...xs.map((x) => x[i])))
const wilderRsi = (n) => { const ch = C.map((c, i) => (i ? c - C[i - 1] : NaN)); const up = rma(ch.map((v) => Math.max(v, 0)), n); const dn = rma(ch.map((v) => Math.max(-v, 0)), n); return zip((u, d) => (d === 0 ? 100 : 100 - 100 / (1 + u / d)), up, dn) }
// weekly aggregation: forming-week (thinkorswim secondary aggregation) and last-closed-week variants
const weekKey = (t) => { const d = new Date(t * 1000); const day = (d.getUTCDay() + 6) % 7; return Math.floor((t - day * 86400) / 86400 / 7) }
const wk = B.map((b) => weekKey(b.t))
function weeklySma(n, forming) {
  const closes = []
  for (let i = 0; i < N; i++) if (i === N - 1 || wk[i + 1] !== wk[i]) closes.push(C[i])
  return B.map((_, i) => {
    let wIdx = 0; for (let j = 0; j < i; j++) if (wk[j + 1] !== wk[j]) wIdx++
    const done = closes.slice(0, wIdx)
    const series = forming ? [...done, C[i]] : done
    if (series.length < n) return NaN
    return series.slice(-n).reduce((a, b) => a + b) / n
  })
}

const IND = {
  'thinkscript/01-ma-cross-arrows.ts': () => { const f = emaFirst(C, 9), s = sma(C, 21); return { FastMA: f, SlowMA: s, BuySignal: b2(zip((a, b, pa, pb) => a > b && pa <= pb, f, s, lag(f, 1), lag(s, 1))), SellSignal: b2(zip((a, b, pa, pb) => a < b && pa >= pb, f, s, lag(f, 1), lag(s, 1))) } },
  'thinkscript/02-rsi-lower-clouds.ts': () => ({ RSIValue: wilderRsi(14) }),
  'thinkscript/03-macd-hist-valuecolor.ts': () => { const m = zip((a, b) => a - b, emaFirst(C, 12), emaFirst(C, 26)); const sg = emaFirst(m, 9); return { Hist: zip((a, b) => a - b, m, sg) } },
  'thinkscript/04-squeeze-from-math.ts': () => { const mid = sma(C, 20), dv = stdevPop(C, 20), ra = sma(tr, 20); return { SqueezeOn: b2(zip((m, d, r) => m + 2 * d < m + 1.5 * r && m - 2 * d > m - 1.5 * r, mid, dv, ra)), Momentum: zip((c, hh, ll, m) => c - ((hh + ll) / 2 + m) / 2, C, highest(H, 20), lowest(L, 20), mid) } },
  'thinkscript/05b-relvol-label-with-plot.ts': () => ({ RelVol: zip((v, a) => v / a, V, sma(V, 50)) }),
  'thinkscript/07-mtf-weekly-average.ts': () => ({ WeeklyMA: weeklySma(10, true), WeeklyMA__closedVariant: weeklySma(10, false) }),
  'thinkscript/08b-sum-up-days.ts': () => ({ UpDayCount: sum(b2(zip((c, p) => c > p, C, lag(C, 1))), 10) }),
  'thinkscript/09-inside-bar-paint.ts': () => ({ InsideBar: b2(zip((h, ph, l, pl) => h < ph && l > pl, H, lag(H, 1), L, lag(L, 1))) }),
  'thinkscript/10b-study-reference-named.ts': () => ({ Oversold: b2(zip((r, c, m, d) => r < 30 && c < m - 2 * d, wilderRsi(14), C, sma(C, 20), stdevPop(C, 20))) }),
  'thinkscript/11-switch-enum-compoundvalue.ts': () => ({ MA: sma(C, 20) }),
  'thinkscript/12-scan-breakout-alert.ts': () => ({ scan: b2(zip((c, m, v, mv, hh) => c > m && v > 1.5 * mv && c > hh, C, sma(C, 50), V, sma(V, 50), highest(lag(H, 1), 20))) }),
  'thinkscript/13-movingaverage-averagetype.ts': () => ({ MA: wma(C, 20), Hull: hma(C, 20) }),
  'thinkscript/15-isnan-na-crosses-fn.ts': () => ({ Valid: sma(C, 20) }),
  'pcf/01-trend-stack.pcf': () => ({ _: b2(zip((c, a, b) => c > a && a > b, C, sma(C, 50), sma(C, 200))) }),
  'pcf/02-pocket-pivot-ish.pcf': () => ({ _: b2(zip((c, c1, v, mv, a, o) => c > c1 && v > mv && c > a && c > o, C, lag(C, 1), V, lag(highest(V, 10), 1), sma(C, 50), O)) }),
  'pcf/03-inside-day.pcf': () => ({ _: b2(zip((h, ph, l, pl) => h < ph && l > pl, H, lag(H, 1), L, lag(L, 1))) }),
  'pcf/04-three-weeks-tight-ish.pcf': () => ({ _: b2(zip((c, c5, c10, c15) => Math.abs(c - c5) / c5 <= 0.015 && Math.abs(c5 - c10) / c10 <= 0.015 && Math.abs(c10 - c15) / c15 <= 0.015, C, lag(C, 5), lag(C, 10), lag(C, 15))) }),
  'pcf/05-gap-up-volume.pcf': () => ({ _: b2(zip((o, h1, v, av) => o > h1 * 1.02 && v > 2 * av, O, lag(H, 1), V, sma(V, 50))) }),
  'pcf/06-wilder-rsi-oversold-uptrend.pcf': () => ({ _: b2(zip((r, c, a) => r < 30 && c > a, wilderRsi(14), C, sma(C, 200))) }),
  'pcf/08-xup-cross.pcf': () => { const a = sma(C, 50); return { _: b2(zip((c, pc, x, px) => pc < px && c >= x, C, lag(C, 1), a, lag(a, 1))) } },
  'pcf/09-macd-signal.pcf': () => { const m = zip((a, b) => a - b, emaFirst(C, 12), emaFirst(C, 26)); return { _: b2(zip((x, s) => x > s, m, emaFirst(m, 9))) } },
  'pcf/10-stoch-bollinger.pcf': () => { const k = zip((c, hh, ll) => 100 * (c - ll) / (hh - ll), C, highest(H, 14), lowest(L, 14)); return { _: b2(zip((s, c, m, d) => s < 20 && c < m - 2 * d, sma(k, 3), C, sma(C, 20), stdevPop(C, 20))), __sampleStdevVariant: b2(zip((s, c, m, d) => s < 20 && c < m - 2 * d, sma(k, 3), C, sma(C, 20), stdevSamp(C, 20))) } },
  'pcf/11-roc-sort.pcf': () => ({ _: zip((c, c21) => 100 * (c - c21) / c21, C, lag(C, 21)) }),
  'pcf/12-near-high-low-atr.pcf': () => ({ _: b2(zip((c, hh, a) => c >= 0.95 * hh && a / c < 0.04, C, highest(H, 252), rma(tr, 14))) }),
  'pcf/13-counttrue.pcf': () => ({ _: b2(sum(b2(zip((c, p) => c > p, C, lag(C, 1))), 10).map((x) => x >= 7)) }),
  'pcf/15-lowercase-volume.pcf': () => ({ _: b2(zip((c, a, v) => c > a && v > 1e6, C, sma(C, 50), V)) }),
  'pcf/16-dotted-offset.pcf': () => { const a = sma(C, 50); return { _: b2(zip((c, a5, c1, a6) => c > a5 && c1 < a6, C, lag(a, 5), lag(C, 1), lag(a, 6))) } },
}

function compare(eng, ref, from) {
  let n = 0, agree = 0, maxAbs = 0, maxRel = 0, engNaN = 0, refNaN = 0, ones = 0
  for (let i = from; i < N; i++) {
    const e = eng[i], r = ref[i]
    if (!Number.isFinite(e) && !Number.isFinite(r)) continue
    n++
    if (!Number.isFinite(e)) { engNaN++; continue }
    if (!Number.isFinite(r)) { refNaN++; continue }
    if (r === 1) ones++
    const d = Math.abs(e - r); maxAbs = Math.max(maxAbs, d); maxRel = Math.max(maxRel, d / Math.max(1e-12, Math.abs(r)))
    if (d <= 1e-9 * Math.max(1, Math.abs(r))) agree++
  }
  return { compared: n, agree, engNaN, refNaN, maxAbs: +maxAbs.toPrecision(4), maxRel: +maxRel.toPrecision(4), refTrueBars: ones }
}

it('numeric', () => {
  const out = {}
  for (const [k, mk] of Object.entries(IND)) {
    const src = fs.readFileSync(path.join(ROOT, k), 'utf8').replace(/\n$/, '')
    const r = inspectSource(src, 'auto')
    const ref = mk()
    const res = {}
    for (const [name] of Object.entries(ref)) {
      const want = name.split('__')[0]
      let ast = null
      if (k.startsWith('pcf/')) ast = r.outputs[0] && r.outputs[0].downstream && r.outputs[0].downstream.ast
      else { const o = r.outputs.find((x) => x.title === want); ast = o && o.ast }
      if (!ast) { res[name] = 'NO-AST'; continue }
      let eng
      try { eng = [...interpret(ast, B, {}, undefined, {})] } catch (e) { res[name] = 'THROW ' + e.message; continue }
      res[name] = { all: compare(eng, ref[name], 0), tail: compare(eng, ref[name], 300), engTail: eng.slice(-3).map((x) => +Number(x).toPrecision(6)), refTail: ref[name].slice(-3).map((x) => +Number(x).toPrecision(6)) }
    }
    out[k] = res
  }
  fs.writeFileSync('src/__audit_scratch__/ws6/numeric.json', JSON.stringify(out, null, 1))
})
