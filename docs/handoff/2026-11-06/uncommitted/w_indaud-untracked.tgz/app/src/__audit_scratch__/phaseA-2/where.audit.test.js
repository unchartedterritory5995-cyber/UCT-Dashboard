// PA-2 scratch (NOT committed): where in a saved pane document a
// history-dependent name sits, for the captures whose tag did not fire.
import { it, vi } from 'vitest'
import fs from 'node:fs'
import path from 'node:path'
import { memberPaneDefinition } from '../../components/chart/builder/memberPane/memberPaneDefinition.js'

const REPO = path.resolve(__dirname, '../../../..')
const CAPS = path.join(REPO, 'tests/fixtures/vendor/harness')
const FILES = ['mcclellan-indicators-spy-1d-2026-10-03.json', 'average-day-range-adr-pivots-spy-1d-2026-10-03.json',
  'volume-profile-spy-1d-2026-10-03.json', 'atr-trailing-stoploss-spy-1d-2026-10-03.json']
const WANT = new Set(['cum', 'isfirst'])

function paths(node, p, acc) {
  if (!node || typeof node !== 'object') return acc
  if (Array.isArray(node)) { node.forEach((n, i) => paths(n, `${p}[${i}]`, acc)); return acc }
  if ((node.type === 'call' || node.type === 'series') && WANT.has(node.name)) acc.push(p.replace(/\[\d+\]/g, '[]').replace(/(\.args\[\])+/g, '.args…'))
  for (const [k, v] of Object.entries(node)) if (k !== 'type' && k !== 'name') paths(v, `${p}.${k}`, acc)
  return acc
}

it('where', () => {
  vi.stubEnv('VITE_PINE_OBJECTS_ONLY_PANE_ENABLED', '1')
  vi.stubEnv('VITE_PINE_RUNTIME_PANE_ENABLED', '0')
  for (const f of FILES) {
    const cap = JSON.parse(fs.readFileSync(path.join(CAPS, f), 'utf8'))
    const src = cap.source.text || cap.source
    const p = memberPaneDefinition({ source: src, id: 'u_member-pane-pa2w' })
    const inDoc = [...new Set(paths(p.definition, 'def', []))]
    const inOutputs = [...new Set(paths((p.translation.outputs || []).map((o) => o.ast || o.tree || null), 'outputs', []))]
    const drawnKinds = (p.translation.outputs || []).filter((o) => paths(o.ast || null, 'x', []).length).map((o) => `${o.kind}${o.hidden ? '(hidden)' : ''}${o.refusal ? '(refused)' : ''}`)
    console.log('WHERE', f, JSON.stringify({ tags: p.requirementTags, inDoc, inOutputs, drawnKinds, paints: (p.definition.paints || []).length, objects: !!p.definition.objects, rows: (p.rows || []).filter((r) => /out1[56]/.test(r.key || '')).map((r) => ({ key: r.key, kind: r.kind, role: r.role, plot: r.plot && r.plot.kind, keys: Object.keys(r) })), plots: (p.definition.plots || []).filter((x) => JSON.stringify(x).includes('out15') || JSON.stringify(x).includes('out16')).map((x) => JSON.stringify(x).slice(0, 300)) }))
  }
})
