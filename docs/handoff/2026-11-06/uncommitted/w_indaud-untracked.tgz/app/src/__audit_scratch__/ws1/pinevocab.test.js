import { test } from 'vitest'
import fs from 'node:fs'
import * as P from '../../components/chart/engine/ast/pine'
test('pine vocab', () => {
  const o = {}
  for (const k of ['PINE_CALL_SHAPES', 'PINE_NAMESPACED_TREE', 'BUILTIN_CALL_TREE', 'PINE_INEXPRESSIBLE', 'PINE_SHORT_FORM']) {
    const v = P[k]; o[k] = v ? Object.keys(v) : null
  }
  fs.writeFileSync('src/__audit_scratch__/ws1/pinevocab.json', JSON.stringify(o))
})
