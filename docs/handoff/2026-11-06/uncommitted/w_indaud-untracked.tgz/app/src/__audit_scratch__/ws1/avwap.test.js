import { test } from 'vitest'
import fs from 'node:fs'
import { getDefinition, computeFor } from '../../components/chart/engine/nativeRegistry'
test('avwap anchors prefix probe', () => {
  const b = JSON.parse(fs.readFileSync('src/__audit_scratch__/ws1/bars_intraday.json', 'utf8'))
  const d = JSON.parse(fs.readFileSync('src/__audit_scratch__/ws1/bars_daily.json', 'utf8'))
  const out = {}
  for (const [lbl, bars] of [['intraday', b], ['daily', d]]) for (const anchor of ['session', 'week', 'month', 'quarter', 'year', 'swingHigh', 'swingLow']) {
    const def = getDefinition('avwap')
    const full = computeFor(def, bars, { anchor }).avwap
    let changed = 0, cuts = 0, finite = Array.from(full).filter(Number.isFinite).length
    for (const k of [150, 300, 451, 599]) { if (k >= bars.length) continue; cuts++
      const part = computeFor(def, bars.slice(0, k), { anchor }).avwap
      for (let i = 0; i < k; i++) { const x = full[i], y = part[i]; if (!((Number.isNaN(x) && Number.isNaN(y)) || Math.abs(x - y) < 1e-9)) changed++ } }
    out[`${lbl}:${anchor}`] = { finite, changed, cuts }
  }
  fs.writeFileSync('src/__audit_scratch__/ws1/avwap.json', JSON.stringify(out))
})
