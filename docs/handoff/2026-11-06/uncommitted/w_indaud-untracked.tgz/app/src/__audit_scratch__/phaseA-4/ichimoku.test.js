// PA4 scratch probe — NOT COMMITTED. Synthetic bars only.
import { test, expect } from 'vitest'
import fs from 'node:fs'
import { computeFor, getDefinition } from '../../components/chart/engine/nativeRegistry'
import { drawShiftOf } from '../../components/chart/engine/binder'
import { computeIchimoku } from '../../components/chart/indicators'

function lcg(seed) { let s = seed >>> 0; return () => ((s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 4294967296) }
function makeBars(n, seed = 11) {
  const r = lcg(seed); const bars = []; let px = 100; let t = Date.UTC(2023, 0, 2) / 1000
  while (bars.length < n) {
    t += 86400; const d = new Date(t * 1000).getUTCDay(); if (d === 0 || d === 6) continue
    const o = px; const c = Math.max(1, o + (r() - 0.5) * 2); const h = Math.max(o, c) + r() * 0.8; const l = Math.min(o, c) - r() * 0.8
    bars.push({ t, o, h, l, c, v: 1000 }); px = c
  }
  return bars
}
const mid = (b, i, p) => { if (i - p + 1 < 0) return NaN; let hi = -Infinity, lo = Infinity; for (let j = i - p + 1; j <= i; j++) { hi = Math.max(hi, b[j].h); lo = Math.min(lo, b[j].l) } return (hi + lo) / 2 }
// Independent TradingView-convention reference (built-in source: offset = displacement - 1 for spans, -displacement + 1 for chikou)
function tvIchimoku(b, t = 9, k = 26, s = 52, disp = 26) {
  const n = b.length, off = disp - 1
  const tenkan = b.map((_, i) => mid(b, i, t)), kijun = b.map((_, i) => mid(b, i, k))
  const leadA = tenkan.map((x, i) => (x + kijun[i]) / 2), leadB = b.map((_, i) => mid(b, i, s))
  const spanA = new Array(n + off).fill(NaN), spanB = new Array(n + off).fill(NaN) // drawn, incl. future tail
  for (let i = 0; i < n; i++) { spanA[i + off] = leadA[i]; spanB[i + off] = leadB[i] }
  const chikou = new Array(n).fill(NaN); for (let j = 0; j + off < n; j++) chikou[j] = b[j + off].c
  return { tenkan, kijun, leadA, leadB, spanA, spanB, chikou, off }
}
const firstFinite = (a) => { for (let i = 0; i < a.length; i++) if (Number.isFinite(a[i])) return i; return -1 }
const val = (x) => (x && typeof x === 'object' && 'value' in x ? x.value : x)
const arr = (col) => Array.from(col, val)

test('ichimoku legacy vs conventional', () => {
  const out = {}
  const bars = makeBars(600)
  const eng = computeFor(getDefinition('ichimoku'), bars, {})
  const E = Object.fromEntries(Object.entries(eng).map(([k, v]) => [k, arr(v)]))
  const R = tvIchimoku(bars)
  out.firstFinite = { engine: Object.fromEntries(Object.keys(E).map(k => [k, firstFinite(E[k])])),
    tv: { tenkan: firstFinite(R.tenkan), kijun: firstFinite(R.kijun), leadA: firstFinite(R.leadA), leadB: firstFinite(R.leadB), spanA_drawn: firstFinite(R.spanA), spanB_drawn: firstFinite(R.spanB), chikou: firstFinite(R.chikou) } }
  // legacy spanA == undisplaced leadA (Pine leadLine1) wherever engine is finite
  let dA = 0, dB = 0, dT = 0
  for (let i = 0; i < bars.length; i++) if (Number.isFinite(E.spanA[i])) { dA = Math.max(dA, Math.abs(E.spanA[i] - R.leadA[i])); dB = Math.max(dB, Math.abs(E.spanB[i] - R.leadB[i])); dT = Math.max(dT, Math.abs(E.tenkan[i] - R.tenkan[i])) }
  out.legacySpanEqualsUndisplacedLead = { maxAbsA: dA, maxAbsB: dB, maxAbsTenkan: dT }
  // chikou shift: engine writes close[j+26]; TV writes close[j+25]
  let c26 = 0, c25 = 0, nC = 0
  for (let j = 0; j < bars.length; j++) if (Number.isFinite(E.chikou[j])) { nC++; if (E.chikou[j] === bars[j + 26]?.c) c26++; if (E.chikou[j] === bars[j + 25]?.c) c25++ }
  out.chikou = { finite: nC, equalsCloseJplus26: c26, equalsCloseJplus25: c25, trailingNaN: bars.length - 1 - (() => { let i = E.chikou.length - 1; while (i >= 0 && !Number.isFinite(E.chikou[i])) i--; return i })() }
  // classification of close vs cloud at each bar: legacy (undisplaced) vs conventional (drawn at bar)
  const cls = (c, a, b) => (!Number.isFinite(a) || !Number.isFinite(b)) ? null : (c > Math.max(a, b) ? 'above' : c < Math.min(a, b) ? 'below' : 'inside')
  let both = 0, differ = 0, flips = 0; const tally = {}
  for (let i = 0; i < bars.length; i++) {
    const L = cls(bars[i].c, E.spanA[i], E.spanB[i]), Cv = cls(bars[i].c, R.spanA[i], R.spanB[i])
    if (!L || !Cv) continue; both++; if (L !== Cv) { differ++; tally[`${L}->${Cv}`] = (tally[`${L}->${Cv}`] || 0) + 1; if ((L === 'above' && Cv === 'below') || (L === 'below' && Cv === 'above')) flips++ }
  }
  out.priceVsCloud = { barsCompared: both, differ, pct: +(100 * differ / both).toFixed(1), oppositeSide: flips, tally }
  // cloud colour (spanA > spanB) at bar
  let cc = 0, ccd = 0
  for (let i = 0; i < bars.length; i++) if ([E.spanA[i], E.spanB[i], R.spanA[i], R.spanB[i]].every(Number.isFinite)) { cc++; if ((E.spanA[i] > E.spanB[i]) !== (R.spanA[i] > R.spanB[i])) ccd++ }
  out.cloudColour = { compared: cc, differ: ccd, pct: +(100 * ccd / cc).toFixed(1) }
  out.futureTailPoints = R.spanA.length - bars.length
  out.positiveDisplaceDrawnShift = drawShiftOf({ displace: 25 })
  out.negativeDisplaceDrawnShift = drawShiftOf({ displace: -25 })
  // closed-form reference on linear bars: h=10+i, l=9+i
  const lin = Array.from({ length: 120 }, (_, i) => ({ t: 1e9 + i * 86400, o: 9.5 + i, h: 10 + i, l: 9 + i, c: 9.5 + i, v: 1 }))
  const RL = tvIchimoku(lin), EL = Object.fromEntries(Object.entries(computeFor(getDefinition('ichimoku'), lin, {})).map(([k, v]) => [k, arr(v)]))
  out.linear = { tenkan_i30: RL.tenkan[30], expect: 5.5 + 30, kijun_i30: RL.kijun[30], expectK: 30 - 3, spanAdrawn_i60: RL.spanA[60], expectA: 60 - 23.75, spanBdrawn_i80: RL.spanB[80], expectB: 80 - 41, chikou_j10: RL.chikou[10], expectC: 9.5 + 35,
    engine_spanA_i60: EL.spanA[60], engine_tenkan_i30: EL.tenkan[30], engine_tenkan_i8: EL.tenkan[8], tv_tenkan_i8: RL.tenkan[8], tail_spanA_last: RL.spanA[RL.spanA.length - 1], expectTail: 119 + 1.25 }
  // legacy computeIchimoku called directly equals computeFor
  const direct = computeIchimoku(bars)
  out.directEqualsComputeFor = direct.spanA.every((p, i) => Object.is(p.value, E.spanA[i]) || (Number.isNaN(p.value) && Number.isNaN(E.spanA[i])))
  fs.writeFileSync('src/__audit_scratch__/phaseA-4/ichimoku.json', JSON.stringify(out, null, 2))
  expect(dA).toBeLessThan(1e-12)
})
