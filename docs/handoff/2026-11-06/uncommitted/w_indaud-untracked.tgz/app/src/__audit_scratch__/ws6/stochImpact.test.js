import { it } from 'vitest'
import fs from 'fs'
import { evaluateFormula } from '../../components/chart/builder/FormulaField.jsx'
import { BUILDER_INPUT_SCOPE } from '../../components/chart/builder/builderInputs.js'
import { interpret } from '../../components/chart/engine/ast/interpret.js'
import { B } from './numeric.test.js'

it('stoch impact', () => {
  const lines = []
  const run = (s) => { const e = evaluateFormula(s, BUILDER_INPUT_SCOPE); return { e, v: [...interpret(e.ast, B, {}, undefined, {})] } }
  for (const [pcf, nat] of [['STOC14.3 < 20', 'sma(stoch(high, low, close, 14), 3) < 20'], ['STOC14.3 > 80', 'sma(stoch(high, low, close, 14), 3) > 80'], ['STOC14.1 < 20', 'stoch(high, low, close, 14) < 20']]) {
    const a = run(pcf), b = run(nat)
    let n = 0, diff = 0, aTrue = 0, bTrue = 0
    for (let i = 20; i < B.length; i++) { n++; if (a.v[i] !== b.v[i]) diff++; if (a.v[i] === 1) aTrue++; if (b.v[i] === 1) bTrue++ }
    lines.push(`${pcf}: dialect=${a.e.dialect} save-ok=${a.e.ok} readback="${a.e.readback}" | bars=${n} disagree=${diff} PCF-true=${aTrue} correct-true=${bTrue}`)
  }
  fs.writeFileSync('src/__audit_scratch__/ws6/stochImpact.txt', lines.join('\n'))
})
