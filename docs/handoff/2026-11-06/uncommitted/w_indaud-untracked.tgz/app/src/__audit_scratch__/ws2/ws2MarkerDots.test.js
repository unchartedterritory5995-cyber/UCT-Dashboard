// WS2 scratch: does a marker (plotshape-like) plot in an OSCILLATOR pane also draw point-marker dots at its 0/1 values?
import { it, expect } from 'vitest'
import { createBinder } from '../../components/chart/engine/binder'
import { createFakeChart } from '../../components/chart/engine/__tests__/fakeChart'
const N = 6
const BARS = Array.from({ length: N }, (_, i) => ({ t: 1700000000 + i * 60, o: 10, h: 11, l: 9, c: 10 + i, v: 1 }))
const COND = Float64Array.from([0, 1, 0, 0, 1, 0])
it('marker plot in pane 1', () => {
  const def = { id: 'mk', schemaVersion: 2, label: 'mk', inputs: [],
    plots: [{ key: 'buy', label: 'Buy', style: 'markers', color: '#ff9800', legend: { decimals: 2 },
      marker: { shape: 'arrowUp', position: 'aboveBar', size: 2.5 } }] }
  const fake = createFakeChart()
  const binder = createBinder({ chart: fake.chart, LWC: fake.LWC })
  const registry = { getDefinition: (id) => (id === 'mk' ? def : null), computeFor: () => ({ buy: COND }),
    hasAnyFinite: () => true, columnKeys: (d) => d.plots.map((p) => p.key) }
  binder.sync({ enabled: true, instances: [{ instanceId: 'inst:mk:1', defId: 'mk', inputs: {} }], registry, bars: BARS,
    adjustTime: (t) => t, plan: { fresh: true }, applyData: (s, d) => s.setData(d),
    resolvePlacement: () => ({ paneIndex: 1, scaleId: 'right', scaleOptions: {} }),
    priceSeries: () => ({ __price: true }),
    createSeriesMarkers: () => ({ setMarkers: () => {} }) })
  const b = binder.bindings()[0]
  const o = b.series.options()
  console.log('[WS2 MK] pointMarkersVisible=', o.pointMarkersVisible, 'lineWidth=', o.lineWidth, 'radius=', o.pointMarkersRadius)
  const calls = (fake.calls || fake.log || [])
  const sd = (Array.isArray(calls) ? calls : []).filter((c) => c && (c.method === 'setData' || c[2] === 'setData'))
  console.log('[WS2 MK] setData calls=', sd.length, JSON.stringify(sd.slice(-1)).slice(0, 300))
  expect(o.pointMarkersVisible).toBe(true)
})
