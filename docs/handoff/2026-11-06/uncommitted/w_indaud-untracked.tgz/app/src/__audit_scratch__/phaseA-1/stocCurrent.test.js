// PHASE A-1 probe (audit only, never committed): STOC as stored TODAY.
import { it, expect } from 'vitest'
import fs from 'fs'
import { inspectSource } from '../../components/chart/builder/PineBox.jsx'
import { readFormulaSource } from '../../components/chart/engine/ast/pcf.js'
import { parseFormula, astHash } from '../../components/chart/engine/ast/parse.js'
import { interpret } from '../../components/chart/engine/ast/interpret.js'
import { validateUserDefinitions, installUserDefinitions, clearUserDefinitions, AST_LANE_TIER, getDefinition } from '../../components/chart/engine/nativeRegistry.js'
import { SCHEMA_VERSION } from '../../components/chart/engine/defSchema.js'
import { normalizeInstances } from '../../components/chart/engine/instances.js'
import { B } from './bars.js'
import { isSwappedStoch, rewriteSwappedStoch, stochSignature } from './detect.js'

export const docFor = (source, ast, id = 'myFormula') => ({
  schemaVersion: SCHEMA_VERSION, id, version: 1,
  compute: { kind: 'ast', fn: astHash(ast), rev: 1, ast, source },
  meta: { name: 'P', shortName: 'P', category: 'Custom', tier: AST_LANE_TIER, repaint: 'non-repainting', freshness: 'live' },
  placement: { target: 'pane', pane: { height: 0.15 } },
  inputs: [{ key: 'color', type: 'color', label: 'Colour', default: 'token:info' }],
  plots: [{ key: 'out', label: 'P', style: 'line', color: '$color', width: 1, role: 'primary' }],
})

it('STOC today: tree, save shape, reload, detection, rewrite', () => {
  const out = []
  const cases = ['STOC14.3 < 20', 'STOC14 < 20', 'STOC14.1 > 80', 'STOC14.3.1 < 20', 'STOC5.3 > STOC5.3.1', 'C > AVGC50 AND STOC14.3 < 20', 'C > AVGC50']
  for (const src of cases) {
    const r = readFormulaSource(src, 'auto')
    const ins = inspectSource(src, 'auto')
    const o = ins.outputs[0] || {}
    const ast = r.result.ast
    const sig = stochSignature(ast)
    const fixed = rewriteSwappedStoch(ast)
    out.push({
      src, dialect: r.dialect, ok: r.result.ok, importFormula: o.formula, outcome: ins.outcome && ins.outcome.verdict,
      outcomeLabel: ins.outcome && ins.outcome.label, readback: o.downstream && o.downstream.readback,
      hash: astHash(ast), swapped: isSwappedStoch(ast), sig, rewrittenHash: astHash(fixed),
    })
  }
  // the rewrite produces EXACTLY the tree the corrected spelling parses to
  const want = astHash(parseFormula('sma(stoch(high, low, close, 14), 3) < 20').ast)
  const got = astHash(rewriteSwappedStoch(readFormulaSource('STOC14.3 < 20', 'auto').result.ast))
  out.push({ rewriteEqualsCorrectSpelling: want === got })
  // offset form
  const wantOff = astHash(parseFormula('sma(stoch(high, low, close, 14), 3)[1] < 20').ast)
  const gotOff = astHash(rewriteSwappedStoch(readFormulaSource('STOC14.3.1 < 20', 'auto').result.ast))
  out.push({ rewriteOffsetEqualsCorrectSpelling: wantOff === gotOff })
  // a hand-typed correct stoch is NOT flagged; a hand-typed Pine-order one IS (indistinguishable from PCF by tree alone)
  out.push({ handCorrectFlagged: isSwappedStoch(parseFormula('stoch(high, low, close, 14) < 20').ast) })
  out.push({ handPineOrderFlagged: isSwappedStoch(parseFormula('stoch(close, high, low, 14) < 20').ast) })
  out.push({ handOddOrderSig: stochSignature(parseFormula('stoch(low, high, close, 14) < 20').ast) })

  // SAVE SHAPE: the PCF text IS compute.source; the (wrong) tree is compute.ast.
  const src = 'STOC14.3 < 20'
  const ast = readFormulaSource(src, 'auto').result.ast
  const doc = docFor(src, ast)
  const v = validateUserDefinitions([doc])
  out.push({ storedDocValidatesToday: v.defs.length === 1, errors: v.errors })
  // A doc carrying the CORRECTED tree beside the PCF text is refused TODAY (mirror of the post-fix failure)
  const corrected = docFor(src, rewriteSwappedStoch(ast))
  const v2 = validateUserDefinitions([corrected])
  out.push({ correctedTreeWithPcfSourceToday: v2.defs.length, errors: v2.errors.map((e) => e.slice(0, 260)) })
  // native-text spelling of the corrected tree validates today
  const nat = 'sma(stoch(high, low, close, 14), 3) < 20'
  const v3 = validateUserDefinitions([docFor(nat, parseFormula(nat).ast)])
  out.push({ correctedNativeSourceValidates: v3.defs.length === 1 })

  // values: wrong range vs corrected range on synthetic bars
  const wrong = [...interpret(readFormulaSource('STOC14.3 + 0', 'auto').result.ast, B, {}, undefined, {})].filter(Number.isFinite)
  const right = [...interpret(rewriteSwappedStoch(readFormulaSource('STOC14.3 + 0', 'auto').result.ast), B, {}, undefined, {})].filter(Number.isFinite)
  out.push({ wrongMin: Math.min(...wrong).toFixed(1), wrongMax: Math.max(...wrong).toFixed(1), rightMin: Math.min(...right).toFixed(1), rightMax: Math.max(...right).toFixed(1) })
  const cw = [...interpret(ast, B, {}, undefined, {})]
  const cr = [...interpret(rewriteSwappedStoch(ast), B, {}, undefined, {})]
  let diff = 0, fw = 0, fr = 0
  for (let i = 0; i < cw.length; i++) { if (cw[i] !== cr[i]) diff++; if (cw[i] === 1) fw++; if (cr[i] === 1) fr++ }
  out.push({ bars: cw.length, conditionDisagrees: diff, firesWrong: fw, firesRight: fr })

  // INSTALL + INSTANCE today
  clearUserDefinitions()
  const inst = installUserDefinitions([doc])
  const n = normalizeInstances([{ instanceId: 'i1', defId: 'myFormula' }])
  out.push({ installed: inst.installed.length, kept: n.kept.length, dropped: n.dropped.length })
  clearUserDefinitions()
  fs.writeFileSync('src/__audit_scratch__/phaseA-1/stocCurrent.json', JSON.stringify(out, null, 1))
  expect(true).toBe(true)
})
