// WS3 AUDIT SCRATCH — NOT FOR COMMIT. Probes lifecycle / persistence claims.
import { describe, it, expect, beforeAll } from 'vitest'
import fs from 'node:fs'
import path from 'node:path'
import * as registry from '../../components/chart/engine/nativeRegistry'
import { CHART_DEFAULTS, mergeChartSettings } from '../../components/chart/chartDefaults'
import { mergeSettingsOverride } from '../../components/chart/instanceShape'
import {
  addInstance, removeInstance, setInstanceInput, duplicateInstance, findInstance,
  setInstanceCalculationTimeframe, setInstanceVisibility, setInstancePanePosition,
  setInstanceHidden, setInstanceAppearance, setIndicatorEnabled, addInstanceCopy,
} from '../../components/chart/engine/instanceControls'
import { normalizeInstances } from '../../components/chart/engine/instances'

const FIX = JSON.parse(fs.readFileSync(path.resolve(globalThis.process.cwd(), '..', 'tests/fixtures/authoring/batch2_definitions.json'), 'utf8'))
const UDEF = 'u_aaaaaaaa0001'
const json = (v) => JSON.parse(JSON.stringify(v))
const live = (cs) => (cs.indicatorInstances || []).filter(i => i && !i.deleted)
const reload = (cs) => mergeChartSettings(JSON.stringify(cs))

beforeAll(() => {
  const res = registry.installUserDefinitions([{ ...FIX.four_state_histogram, id: UDEF, version: 3 }])
  expect(res.errors, JSON.stringify(res.errors)).toEqual([])
})

describe('WS3 round trip: built-in instance settings survive serialize -> mergeChartSettings', () => {
  it('two RSIs, edited independently, survive a reload byte-for-byte', () => {
    let cs = mergeChartSettings(null)
    cs = addInstance(cs, 'rsi', registry)
    cs = addInstance(cs, 'rsi', registry)
    const [a, b] = live(cs).filter(i => i.defId === 'rsi')
    expect(a.instanceId).not.toBe(b.instanceId)
    cs = setInstanceInput(cs, a.instanceId, 'period', 7, registry)
    cs = setInstanceCalculationTimeframe(cs, b.instanceId, 'W', registry)
    cs = setInstanceVisibility(cs, b.instanceId, 'intraday', registry)
    cs = setInstancePanePosition(cs, a.instanceId, 'above', registry)
    const before = json(live(cs).filter(i => i.defId === 'rsi'))
    const after = json(live(reload(cs)).filter(i => i.defId === 'rsi'))
    expect(after).toEqual(before)
    // independence
    expect(findInstance(cs, b.instanceId).inputs.period).not.toBe(7)
    expect(findInstance(cs, a.instanceId).calculationTimeframe).toBeUndefined()
  })

  it('duplicate copies config under a new id; editing the copy leaves the source', () => {
    let cs = addInstance(mergeChartSettings(null), 'rsi', registry)
    const src = live(cs).find(i => i.defId === 'rsi')
    cs = setInstanceInput(cs, src.instanceId, 'period', 9, registry)
    cs = duplicateInstance(cs, src.instanceId, registry)
    const copies = live(cs).filter(i => i.defId === 'rsi')
    expect(copies.length).toBe(2)
    const copy = copies.find(i => i.instanceId !== src.instanceId)
    expect(copy.inputs.period).toBe(9)
    cs = setInstanceInput(cs, copy.instanceId, 'period', 21, registry)
    expect(findInstance(cs, src.instanceId).inputs.period).toBe(9)
  })

  it('a removed id is never re-minted (tombstone reserves it)', () => {
    let cs = addInstance(mergeChartSettings(null), 'rsi', registry)
    const id1 = live(cs).find(i => i.defId === 'rsi').instanceId
    cs = removeInstance(cs, id1, registry)
    cs = addInstance(cs, 'rsi', registry)
    const id2 = live(cs).find(i => i.defId === 'rsi').instanceId
    expect(id2).not.toBe(id1)
    // and the reload keeps the tombstone
    expect(reload(cs).indicatorInstances.some(i => i.instanceId === id1 && i.deleted === true)).toBe(true)
  })

  it('PROBE: remove has no undo in instanceControls — re-add yields DEFAULT inputs, not the removed settings', () => {
    let cs = addInstance(mergeChartSettings(null), 'rsi', registry)
    const id = live(cs).find(i => i.defId === 'rsi').instanceId
    cs = setInstanceInput(cs, id, 'period', 5, registry)
    cs = removeInstance(cs, id, registry)
    cs = addInstance(cs, 'rsi', registry)
    const back = live(cs).find(i => i.defId === 'rsi')
    expect(back.inputs.period).not.toBe(5)
  })

  it('PROBE: legacy toggle off/on keeps an edited period (mirror rule)', () => {
    let cs = setIndicatorEnabled(mergeChartSettings(null), 'macd', true, registry)
    cs = setInstanceInput(cs, 'legacy:macd', 'fastPeriod', 33, registry)
    cs = setIndicatorEnabled(cs, 'macd', false, registry)
    cs = setIndicatorEnabled(cs, 'macd', true, registry)
    expect(findInstance(reload(cs), 'legacy:macd').inputs.fastPeriod).toBe(33)
  })
})

describe('WS3 user-defined instance lifecycle', () => {
  it('user-def instance round-trips (inputs + presentation) through reload', () => {
    let cs = addInstance(mergeChartSettings(null), UDEF, registry)
    const inst = live(cs).find(i => i.defId === UDEF)
    expect(inst).toBeTruthy()
    cs = setInstanceInput(cs, inst.instanceId, 'hist_csWidth', 3, registry)
    const before = json(findInstance(cs, inst.instanceId))
    const after = json(findInstance(reload(cs), inst.instanceId))
    expect(after).toEqual(before)
  })

  it('PROBE: a stored instance whose definition is NOT installed survives the merge (kept in blob) but is DROPPED at paint', () => {
    let cs = addInstance(mergeChartSettings(null), UDEF, registry)
    const id = live(cs).find(i => i.defId === UDEF).instanceId
    registry.uninstallUserDefinition(UDEF)
    try {
      const merged = reload(cs)
      expect(merged.indicatorInstances.some(i => i.instanceId === id)).toBe(true)   // not destroyed in storage
      const { kept, dropped } = normalizeInstances(merged.indicatorInstances, registry)
      expect(kept.some(i => i.instanceId === id)).toBe(false)
      expect(dropped.some(d => d.inst.instanceId === id)).toBe(true)
      // and an instanceControls writer refuses to touch it (findInstance finds the raw record though)
      const r = setInstanceHidden(merged, id, true, registry)
      expect(r.indicatorInstances.find(i => i.instanceId === id).hidden).toBe(true)
    } finally {
      registry.installUserDefinitions([{ ...FIX.four_state_histogram, id: UDEF, version: 3 }])
    }
  })

  it('PROBE: an edit that REMOVES a declared input the instance had set silently drops the instance at paint', () => {
    let cs = addInstance(mergeChartSettings(null), UDEF, registry)
    const id = live(cs).find(i => i.defId === UDEF).instanceId
    cs = setInstanceInput(cs, id, 'hist_csWidth', 3, registry)
    const edited = json(FIX.four_state_histogram)
    edited.inputs = edited.inputs.filter(i => i.key !== 'hist_csWidth')
    const res = registry.installUserDefinitions([{ ...edited, id: UDEF, version: 4 }])
    try {
      if (res.errors.length) {
        // the edit could not be installed — record and fall back to the generic undeclared-key probe
        const fake = { ...findInstance(cs, id), inputs: { notDeclared: 1 } }
        const r = normalizeInstances([fake], registry)
        expect(r.kept.length).toBe(0)
        return
      }
      const { kept, dropped } = normalizeInstances(cs.indicatorInstances, registry)
      expect(kept.some(i => i.instanceId === id)).toBe(false)
      expect(dropped.find(d => d.inst.instanceId === id).reason).toMatch(/declares no input/)
    } finally {
      registry.installUserDefinitions([{ ...FIX.four_state_histogram, id: UDEF, version: 5 }])
    }
  })
})

describe('WS3 merge semantics used by setPrefMerged / per-cell overrides', () => {
  it('PROBE: mergeSettingsOverride cannot CLEAR an instance field (union-spread keeps the stale key)', () => {
    let cs = addInstance(mergeChartSettings(null), 'rsi', registry)
    const id = live(cs).find(i => i.defId === 'rsi').instanceId
    const withW = setInstanceCalculationTimeframe(cs, id, 'W', registry)
    const cleared = setInstanceCalculationTimeframe(withW, id, null, registry)
    expect(findInstance(cleared, id).calculationTimeframe).toBeUndefined()
    const merged = mergeSettingsOverride(withW, cleared)
    // documents the behaviour: the cleared key comes back
    expect(findInstance(merged, id).calculationTimeframe).toBe('W')
  })

  it('PROBE: mergeSettingsOverride cannot remove an input key (inputs unioned)', () => {
    const base = { indicatorInstances: [{ instanceId: 'x', defId: 'rsi', inputs: { period: 7 } }] }
    const patch = { indicatorInstances: [{ instanceId: 'x', defId: 'rsi', inputs: {} }] }
    expect(mergeSettingsOverride(base, patch).indicatorInstances[0].inputs.period).toBe(7)
  })
})

describe('WS3 template copy', () => {
  it('addInstanceCopy reproduces configured inputs under a fresh id and drops scope', () => {
    const body = { instanceId: 'inst:rsi:9', defId: 'rsi', inputs: { period: 7 }, scope: 'chart-x', calculationTimeframe: 'W' }
    const cs = addInstanceCopy(mergeChartSettings(null), body, registry)
    const got = live(cs).find(i => i.defId === 'rsi')
    expect(got.inputs.period).toBe(7)
    expect(got.scope).toBeUndefined()
    expect(got.instanceId).not.toBe('inst:rsi:9')
  })

  it('addInstanceCopy REFUSES (identity) a body whose user definition is not installed', () => {
    const base = mergeChartSettings(null)
    expect(addInstanceCopy(base, { defId: 'u_ffffffffffff', inputs: {} }, registry)).toBe(base)
  })
})

describe('WS3 allow-list: every CHART_DEFAULTS top-level key survives a merge', () => {
  it('lists CHART_DEFAULTS keys that mergeChartSettings drops', () => {
    const merged = mergeChartSettings(JSON.stringify(CHART_DEFAULTS))
    const dropped = Object.keys(CHART_DEFAULTS).filter(k => !(k in merged))
    // print for the audit record
    console.log('[WS3] CHART_DEFAULTS keys dropped by mergeChartSettings:', JSON.stringify(dropped))
    expect(Array.isArray(dropped)).toBe(true)
  })
  it('an unknown top-level key is destroyed on read (hard allow-list)', () => {
    const merged = mergeChartSettings(JSON.stringify({ ...CHART_DEFAULTS, someNewSetting: 1 }))
    expect('someNewSetting' in merged).toBe(false)
  })
})
