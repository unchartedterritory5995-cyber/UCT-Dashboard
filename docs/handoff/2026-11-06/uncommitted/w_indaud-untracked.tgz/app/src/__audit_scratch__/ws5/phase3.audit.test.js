// WS5 audit scratch (NOT committed): cross-tab the import-box verdict a member
// reads against the vendor-harness verdict for every TradingView capture.
import { describe, it, vi } from 'vitest'
import fs from 'node:fs'
import path from 'node:path'
import { inspectSource } from '../../components/chart/builder/PineBox.jsx'
import { memberPaneDefinition } from '../../components/chart/builder/memberPane/memberPaneDefinition.js'

const REPO = path.resolve(__dirname, '../../../..')
const VERDICTS = process.env.WS5_VERDICTS
const OUT = process.env.WS5_OUT

describe('import verdict vs vendor verdict', () => {
  it('cross-tab', () => {
    vi.stubEnv('VITE_PINE_OBJECTS_ONLY_PANE_ENABLED', '1')
    const v = JSON.parse(fs.readFileSync(VERDICTS, 'utf8'))
    const rows = []
    for (const r of v.results) {
      let cap
      try { cap = JSON.parse(fs.readFileSync(path.join(REPO, r.file), 'utf8')) } catch { continue }
      const src = cap && cap.source && (cap.source.text || cap.source)
      if (typeof src !== 'string') continue
      let rep
      try { rep = inspectSource(src, 'auto') } catch (e) { rep = { outcome: { verdict: 'THREW' } } }
      let pane
      try { pane = memberPaneDefinition({ source: src, id: 'u_member-pane-ws5x' }) } catch { pane = { ok: false } }
      const plots = (r.plots || []).filter((p) => p.title !== 'objects')
      const div = plots.filter((p) => p.verdict === 'DIVERGE')
      rows.push({
        file: path.basename(r.file),
        harness: r.verdict,
        refused: String(r.reason).startsWith('refused on our side'),
        importVerdict: rep.outcome && rep.outcome.verdict,
        importReason: rep.outcome && rep.outcome.reason ? String(rep.outcome.reason).slice(0, 100) : null,
        nSemantic: rep.outcome && rep.outcome.semantic ? rep.outcome.semantic.length : 0,
        nPresentation: rep.outcome && rep.outcome.presentation ? rep.outcome.presentation.length : 0,
        paneOk: !!pane.ok,
        paneNotes: (pane.notes || []).length,
        plotsCompared: plots.length,
        plotsDiverge: div.length,
        divKinds: div.map((p) => (String(p.reason).match(/\((na|value|color)[: ]/) || [])[1] || 'other'),
        objectsVerdict: ((r.plots || []).find((p) => p.title === 'objects') || {}).verdict || null,
      })
    }
    fs.writeFileSync(path.join(OUT, 'phase3.json'), JSON.stringify(rows, null, 1))
  })
})
