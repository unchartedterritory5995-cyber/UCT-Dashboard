import { it } from 'vitest'
import fs from 'fs'
import path from 'path'
import { inspectSource } from '../../components/chart/builder/PineBox.jsx'
const ROOT = 'C:/w/indaud/docs/indicators/audit-2026-10-13/migration-corpus'
const pick = (r) => r && ({ guard: r.guard, message: r.message || r.error, token: r.token, line: r.line })
it('corpus', () => {
  const res = {}
  for (const lang of ['thinkscript', 'pcf']) {
    for (const f of fs.readdirSync(path.join(ROOT, lang)).sort()) {
      const src = fs.readFileSync(path.join(ROOT, lang, f), 'utf8').replace(/\n$/, '')
      const r = inspectSource(src, 'auto')
      res[`${lang}/${f}`] = {
        ok: r.ok, dialect: r.dialect, declaration: r.declaration, rerouted: r.rerouted || null,
        outcome: r.outcome, refusal: pick(r.refusal),
        refusals: (r.refusals || []).map(pick),
        outputs: (r.outputs || []).map((o) => ({ title: o.title, kind: o.kind, formula: o.formula, hidden: o.hidden,
          refusal: pick(o.refusal), pasteInputs: o.pasteInputs, fixedInputs: o.fixedInputs,
          vendorNotes: o.vendorNotes, downstreamOk: o.downstream ? o.downstream.ok : null,
          downstreamErr: o.downstream && !o.downstream.ok ? o.downstream.error : null,
          readback: o.downstream ? o.downstream.readback : null, verdict: o.downstream && o.downstream.verdict ? o.downstream.verdict.mode : null,
          yields: o.downstream ? o.downstream.yields : null })),
        selected: r.selected,
        ignored: (r.ignored || []).map((n) => ({ code: n.code, line: n.line, message: n.message })),
        folded: r.folded, presentation: r.presentation || null, inputParams: r.inputParams,
      }
    }
  }
  fs.writeFileSync('src/__audit_scratch__/ws6/corpus.json', JSON.stringify(res, null, 1))
})
