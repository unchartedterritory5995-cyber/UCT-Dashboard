export function makeBars(n = 420) {
  let s = 12345; const rnd = () => { s = (s * 1103515245 + 12345) % 2147483648; return s / 2147483648 }
  const bars = []; let p = 50; let t = Date.UTC(2024, 0, 2) / 1000
  while (bars.length < n) {
    const d = new Date(t * 1000).getUTCDay()
    if (d !== 0 && d !== 6) {
      const drift = Math.sin(bars.length / 40) * 0.004
      const o = p * (1 + (rnd() - 0.5) * 0.02)
      const c = o * (1 + drift + (rnd() - 0.5) * 0.04)
      const h = Math.max(o, c) * (1 + rnd() * 0.015)
      const l = Math.min(o, c) * (1 - rnd() * 0.015)
      const v = Math.round(1e6 * (0.5 + rnd() * 1.5) * (rnd() < 0.05 ? 3 : 1))
      bars.push({ t, o, h, l, c, v }); p = c
    }
    t += 86400
  }
  return bars
}
export const B = makeBars()
