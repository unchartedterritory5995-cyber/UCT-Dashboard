| # | id | Name | Category | Lane | Inputs (non-colour) = default [min-max] | Source | Outputs (plot:style) | Placement | TF limits | Alertable (server) | Status |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | `rsi` | Relative Strength Index | momentum | native | period:int=14[2-100] | close | rsi:line, bands:hlines, midline:hlines (single) | pane fixed 0..100 | any | yes | 1 |
| 2 | `macd` | MACD | momentum | native | fastPeriod:int=12[1-100]; slowPeriod:int=26[1-200]; signalPeriod:int=9[1-50] | close | macd:line, signal:line, histogram:histogram, zero:hlines (multi) | pane | any | yes | 1 |
| 3 | `bb` | Bollinger Bands | volatility | native | period:int=20[2-200]; stdDev:float=2[0.5-5] | close | upper:line, middle:band, lower:line (multi) | overlay | any | yes | 1 |
| 4 | `vwap` | Session VWAP | volume (VWAP) | native | opacity:int=100[5-100]; lineStyle:enum="solid"{solid/dashed/dotted}; lineWidth:int=1[1-4]; bands:enum="off"{off/1/2/3} | OHLCV | vwap:line, upper1:line, lower1:line, upper2:line, lower2:line, upper3:line, lower3:line (multi) | overlay | 1,5,15,30,60 | yes | 2 |
| 5 | `stoch` | Stochastic Oscillator | momentum | native | kPeriod:int=14[1-100]; smoothK:int=1[1-20]; dPeriod:int=3[1-20] | OHLC | k:line, d:line, overbought:hlines, oversold:hlines (multi) | pane fixed 0..100 | any | yes | 2 |
| 6 | `atr` | Average True Range | volatility | native | period:int=14[1-100] | OHLC | atr:line (single) | pane | any | yes | 1 |
| 7 | `sar` | Parabolic SAR | trend | native | step:float=0.02[0.001-0.1]; maxStep:float=0.2[0.01-1] | OHLC | sar:markers (single) | overlay | any | yes | 1 |
| 8 | `ichimoku` | Ichimoku Cloud | trend | native | tenkanPeriod:int=9[1-100]; kijunPeriod:int=26[1-200]; senkouBPeriod:int=52[1-400] | OHLC | tenkan:line, kijun:line, spanA:line, spanB:line, chikou:line (multi) | overlay | any | yes | 3 |
| 9 | `mfi` | Money Flow Index | volume | native | period:int=14[2-100] | OHLCV | mfi:line, bands:hlines (single) | pane fixed 0..100 | any | yes | 1 |
| 10 | `cci` | Commodity Channel Index | momentum | native | period:int=20[2-200] | OHLC | cci:line, bands:hlines, zero:hlines (single) | pane | any | yes | 1 |
| 11 | `williamsR` | Williams %R | momentum | native | period:int=14[2-100] | OHLC | williams_r:line, bands:hlines (single) | pane fixed -100..0 | any | yes | 1 |
| 12 | `adx` | Average Directional Index | trend | native | period:int=14[2-100] | OHLC | adx:line, plusDI:line, minusDI:line, trend:hlines (multi) | pane fixed 0..100 | any | yes | 1 |
| 13 | `obv` | On-Balance Volume | volume | native | — | OHLCV | obv:line (single) | pane | any | yes | 1 |
| 14 | `donchian` | Donchian Channels | volatility | native | period:int=20[2-200] | OHLC | upper:line, middle:band, lower:line (multi) | overlay | any | yes | 1 |
| 15 | `avwap` | Anchored VWAP | volume (VWAP) | native | anchor:enum="session"{session/week/month/quarter/year/swingHigh/swingLow}; lineStyle:enum="solid"{solid/dashed/dotted}; lineWidth:int=1[1-4] | OHLCV | avwap:line (single) | overlay | 1,5,15,30,60 | no | 2 |
| 16 | `atrBands` | ATR Bands | volatility | native | period:int=14[2-200]; multiplier:float=2[0.1-10] | OHLC | upper:line, middle:band, lower:line (multi) | overlay | any | no | 2 |
| 17 | `movingAverage` | Moving Average | trend | native | source:source="close"; period:int=5[1-500]; maType:enum="sma"{sma/ema/wma/vwma/hma/smma/dema/tema/lsma} | selectable source (default close) | ma:line (single) | overlay | any | no | 2 |
| 18 | `dataSeries` | Data Series | data | native | source:source="close" | selectable source (default close) | value:line (single) | pane | any | no | 1 |
| 19 | `dollarVolume` | Dollar Volume | volume | native | — | OHLCV | dv:histogram (single) | pane | any | no | 2 |
| 20 | `superTrend` | SuperTrend | trend · Tier1 | native | atrPeriod:int=10[1-100]; multiplier:float=3[0.5-10] | OHLC | up:line, down:line (multi) | overlay | any | no | 2 |
| 21 | `aroon` | Aroon | trend · Tier1 | native | period:int=14[1-200] | OHLC | up:line, down:line, bands:hlines (multi) | pane fixed 0..100 | any | no | 2 |
| 22 | `vortex` | Vortex Indicator | trend · Tier1 | native | period:int=14[2-200] | OHLC | plus:line, minus:line, one:hlines (multi) | pane | any | no | 2 |
| 23 | `choppiness` | Choppiness Index | trend · Tier1 | native | period:int=14[2-200] | OHLC | chop:line, bands:hlines (single) | pane fixed 0..100 | any | no | 2 |
| 24 | `stochRsi` | Stochastic RSI | momentum · Tier1 | native | source:source="close"; rsiPeriod:int=14[2-200]; stochPeriod:int=14[1-200]; kSmooth:int=3[1-50]; dSmooth:int=3[1-50] | selectable source (default close) | k:line, d:line, bands:hlines (multi) | pane fixed 0..100 | any | no | 2 |
| 25 | `ppo` | Percentage Price Oscillator | momentum · Tier1 | native | source:source="close"; fastPeriod:int=12[1-200]; slowPeriod:int=26[1-400]; signalPeriod:int=9[1-100] | selectable source (default close) | ppo:line, signal:line, histogram:histogram, zero:hlines (multi) | pane | any | no | 2 |
| 26 | `roc` | Rate of Change | momentum · Tier1 | native | source:source="close"; period:int=12[1-500] | selectable source (default close) | roc:line, zero:hlines (single) | pane | any | no | 2 |
| 27 | `momentum` | Momentum | momentum · Tier1 | native | source:source="close"; period:int=10[1-500] | selectable source (default close) | mom:line, zero:hlines (single) | pane | any | no | 2 |
| 28 | `tsi` | True Strength Index | momentum · Tier1 | native | source:source="close"; longPeriod:int=25[1-200]; shortPeriod:int=13[1-200]; signalPeriod:int=13[1-100] | selectable source (default close) | tsi:line, signal:line, zero:hlines (multi) | pane | any | no | 2 |
| 29 | `cmo` | Chande Momentum Oscillator | momentum · Tier1 | native | source:source="close"; period:int=14[1-200] | selectable source (default close) | cmo:line, bands:hlines, zero:hlines (single) | pane fixed -100..100 | any | no | 2 |
| 30 | `trix` | TRIX | momentum · Tier1 | native | source:source="close"; period:int=15[1-200]; signalPeriod:int=9[1-100] | selectable source (default close) | trix:line, signal:line, zero:hlines (multi) | pane | any | no | 2 |
| 31 | `awesome` | Awesome Oscillator | momentum · Tier1 | native | fastPeriod:int=5[1-100]; slowPeriod:int=34[1-300] | OHLC | ao:histogram, rising:line, zero:hlines (multi) | pane | any | no | 2 |
| 32 | `ultimate` | Ultimate Oscillator | momentum · Tier1 | native | fastPeriod:int=7[1-100]; midPeriod:int=14[1-200]; slowPeriod:int=28[1-400] | OHLC | uo:line, bands:hlines (single) | pane fixed 0..100 | any | no | 2 |
| 33 | `balanceOfPower` | Balance of Power | momentum · Tier1 | native | smoothing:int=14[1-200] | OHLC | bop:histogram, zero:hlines (single) | pane | any | no | 2 |
| 34 | `bullBearPower` | Bull/Bear Power | momentum · Tier1 | native | period:int=13[1-200] | OHLC | bull:histogram, bear:histogram, zero:hlines (multi) | pane | any | no | 2 |
| 35 | `keltner` | Keltner Channels | volatility · Tier1 | native | period:int=20[1-400]; multiplier:float=2[0.1-10]; atrPeriod:int=10[1-200] | OHLC | upper:line, middle:band, lower:line (multi) | overlay | any | no | 2 |
| 36 | `envelope` | MA Envelope | volatility · Tier1 | native | source:source="close"; period:int=20[1-500]; percent:float=2.5[0.1-50]; maType:enum="sma"{sma/ema/wma/vwma/hma/smma/dema/tema/lsma} | selectable source (default close) | upper:line, middle:band, lower:line (multi) | overlay | any | no | 2 |
| 37 | `bbPercentB` | Bollinger %B | volatility · Tier1 | native | period:int=20[2-200]; stdDev:float=2[0.5-5] | OHLC | percentB:line, bands:hlines, midline:hlines (single) | pane | any | no | 2 |
| 38 | `bbWidth` | Bollinger BandWidth | volatility · Tier1 | native | period:int=20[2-200]; stdDev:float=2[0.5-5] | OHLC | bandwidth:line (single) | pane | any | no | 2 |
| 39 | `atrPercent` | ATR % | volatility · Tier1 | native | period:int=14[1-100] | OHLC | atrPct:line (single) | pane | any | no | 2 |
| 40 | `adrPercent` | ADR % | volatility · Tier1 | native | period:int=20[1-200] | OHLC | adrPct:line (single) | pane | any | no | 2 |
| 41 | `historicalVolatility` | Historical Volatility | volatility · Tier1 | native | period:int=20[2-400] | OHLC | hv:line (single) | pane | D,W,M | no | 2 |
| 42 | `squeeze` | Squeeze | volatility · Tier1 | native | period:int=20[2-200]; bbMult:float=2[0.5-5]; kcMult:float=1.5[0.5-5] | OHLC | momentum:histogram, state:line, on:line (multi) | pane | any | no | 2 |
| 43 | `relativeVolume` | Relative Volume | volume · Tier1 | native | period:int=50[1-500] | OHLCV | rvol:histogram, one:hlines (single) | pane | any | no | 2 |
| 44 | `accumDist` | Accumulation/Distribution | volume · Tier1 | native | — | OHLCV | ad:line (single) | pane | any | no | 2 |
| 45 | `chaikinMoneyFlow` | Chaikin Money Flow | volume · Tier1 | native | period:int=20[1-200] | OHLCV | cmf:histogram, zero:hlines (single) | pane | any | no | 2 |
| 46 | `chaikinOscillator` | Chaikin Oscillator | volume · Tier1 | native | fastPeriod:int=3[1-100]; slowPeriod:int=10[1-200] | OHLCV | osc:line, zero:hlines (single) | pane | any | no | 2 |
| 47 | `forceIndex` | Elder Force Index | volume · Tier1 | native | period:int=13[1-200] | OHLCV | efi:line, zero:hlines (single) | pane | any | no | 2 |
| 48 | `pvt` | Price Volume Trend | volume · Tier1 | native | — | OHLCV | pvt:line (single) | pane | any | no | 2 |
| 49 | `upDownVolume` | Up/Down Volume Ratio | volume · Tier1 | native | period:int=50[2-500] | OHLCV | ratio:line, one:hlines (single) | pane | any | no | 2 |
| 50 | `percentFromMa` | % From MA | RS · Tier1 | native | source:source="close"; period:int=50[1-500]; maType:enum="sma"{sma/ema/wma/vwma/hma/smma/dema/tema/lsma} | selectable source (default close) | pct:line, zero:hlines (single) | pane | any | no | 2 |
| 51 | `fiftyTwoWeek` | 52-Week High/Low | RS · Tier1 | native | — | OHLC | fromHigh:line, fromLow:line, zero:hlines (multi) | pane | D,W,M | no | 2 |
| 52 | `standardDeviation` | Standard Deviation | statistical · Tier1 | native | source:source="close"; period:int=20[2-500] | selectable source (default close) | stdev:line (single) | pane | any | no | 2 |
| 53 | `rsLine` | Relative Strength Line | RS | server (premium) | benchmark:enum="SPY"{SPY/QQQ/IWM}; lineWidth:int=1[1-4] | close + benchmark close (server) | rsLine:line (single) | pane | any | no | 2 |
