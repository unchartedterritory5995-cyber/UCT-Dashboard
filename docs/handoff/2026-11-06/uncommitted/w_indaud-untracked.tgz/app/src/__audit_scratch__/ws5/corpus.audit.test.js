// WS5 audit scratch harness (NOT committed). Runs the audit corpus through the
// REAL import doors: ImportBox's `inspectSource` (what the paste box shows) and
// `memberPaneDefinition` (what "Add this script to my chart" builds).
import { describe, it } from 'vitest'
import fs from 'node:fs'
import path from 'node:path'
import { inspectSource } from '../../components/chart/builder/PineBox.jsx'
import { memberPaneDefinition } from '../../components/chart/builder/memberPane/memberPaneDefinition.js'
import { interpret } from '../../components/chart/engine/ast/interpret.js'
import { makeBars, refs } from './refs.js'

const CORPUS = path.resolve(__dirname, '../../../../docs/indicators/audit-2026-10-13/migration-corpus/pine')
const OUT = process.env.WS5_OUT || path.resolve(__dirname, 'out')

const files = fs.readdirSync(CORPUS).filter((f) => f.endsWith('.pine')).sort()

const slim = (o) => o && ({
  kind: o.kind, title: o.title, handle: o.handle, line: o.line, hidden: !!o.hidden,
  hiddenReason: o.hiddenReason, formula: o.formula,
  refusal: o.refusal ? { guard: o.refusal.guard, message: o.refusal.message } : null,
  presentation: o.presentation,
  memberInputs: (o.memberInputs || []).map((m) => ({ key: m.key, label: m.label, default: m.default })),
  pasteInputs: (o.pasteInputs || []).map((k) => ({ name: k.name, folded: k.folded })),
  fixedInputs: (o.fixedInputs || []).map((k) => ({ name: k.name || k.call, title: k.title, folded: k.folded })),
  vendorNotes: o.vendorNotes,
  downstream: o.downstream ? { ok: o.downstream.ok, error: o.downstream.error, guard: o.downstream.guard } : null,
})

function finiteStats(a) {
  let n = 0
  for (const v of a) if (Number.isFinite(v)) n++
  return n
}

function maxDiff(ours, ref, from = 0) {
  let worst = 0; let compared = 0; let naMismatch = 0
  for (let i = from; i < ref.length; i++) {
    const a = ours[i]; const b = ref[i]
    const fa = Number.isFinite(a); const fb = Number.isFinite(b)
    if (fa !== fb) { naMismatch++; continue }
    if (!fa) continue
    compared++
    const d = Math.abs(a - b) / Math.max(1e-12, Math.abs(b))
    if (d > worst) worst = d
  }
  return { worstRel: worst, compared, naMismatch }
}

describe('WS5 corpus through the real doors', () => {
  const bars = makeBars(1500, 7)
  const spy = makeBars(1500, 99)
  const all = {}
  for (const f of files) {
    it(f, () => {
      const src = fs.readFileSync(path.join(CORPUS, f), 'utf8')
      const rec = { file: f }
      const rep = inspectSource(src, 'auto')
      rec.import = {
        ok: rep.ok, dialect: rep.dialect, version: rep.version, declaration: rep.declaration, title: rep.title,
        outcome: rep.outcome, refusal: rep.refusal ? { guard: rep.refusal.guard, message: rep.refusal.message, line: rep.refusal.line } : null,
        selected: rep.selected, outputs: (rep.outputs || []).map(slim),
        ignored: (rep.ignored || []).map((n) => ({ code: n.code, line: n.line, message: n.message })),
        presentationKeys: rep.presentation ? Object.keys(rep.presentation) : null,
        presentation: rep.presentation,
        objects: rep.objects ? { ops: (rep.objects.ops || []).length } : null,
        objectDiagnostics: rep.objectDiagnostics,
        inputParams: rep.inputParams,
      }
      let pane
      try { pane = memberPaneDefinition({ source: src, id: 'u_member-pane-ws5' }) } catch (e) { pane = { threw: String(e && e.stack) } }
      rec.pane = {
        ok: pane.ok, reason: pane.reason, guard: pane.guard, notes: pane.notes,
        hostOk: pane.translation ? pane.translation.ok : null,
        hostRefusal: pane.translation && pane.translation.refusal ? { guard: pane.translation.refusal.guard, message: pane.translation.refusal.message, line: pane.translation.refusal.line } : null,
        hostRefusals: pane.translation && pane.translation.refusals ? pane.translation.refusals.map((r) => ({ guard: r.guard, message: r.message, line: r.line, route: r.route })) : null,
        hostOutputs: pane.translation ? (pane.translation.outputs || []).map(slim) : null,
        definition: pane.definition ? {
          meta: pane.definition.meta, placement: pane.definition.placement,
          inputs: pane.definition.inputs,
          plots: (pane.definition.plots || []).map((p) => ({ key: p.key, label: p.label, style: p.style, color: p.color, hidden: p.hidden, colorMode: p.colorMode, colorUp: p.colorUp, colorDown: p.colorDown, colorPalette: p.colorPalette, fill: p.fill, fillColor: p.fillColor, fillOpacity: p.fillOpacity, marker: p.marker, opacity: p.opacity, lineWidth: p.lineWidth })),
          paints: pane.definition.paints, levels: pane.definition.levels,
          objects: pane.definition.objects ? { ops: (pane.definition.objects.ops || []).length } : null,
          computeKind: pane.definition.compute && pane.definition.compute.kind,
          computeKeys: pane.definition.compute ? Object.keys(pane.definition.compute) : null,
          paramManifest: pane.definition.compute && pane.definition.compute.paramManifest,
          keys: Object.keys(pane.definition),
        } : null,
      }
      // numeric: evaluate every carried plot tree on synthetic bars
      const ref = refs[f] ? refs[f](bars, spy) : null
      rec.numeric = {}
      const def = pane.definition
      const trees = def && def.compute && def.compute.trees
      const plotRows = (def && def.plots) || []
      const evalTree = (ast) => {
        try { return Array.from(interpret(ast, bars, undefined, undefined, undefined, { symbols: { SPY: spy, 'AMEX:SPY': spy } })) } catch (e) { return String(e && e.message) }
      }
      const hostOutputs = pane.translation ? (pane.translation.outputs || []) : []
      for (const o of hostOutputs) {
        if (!o || !o.ast) continue
        const vals = evalTree(o.ast)
        const name = o.title || o.handle || `line${o.line}`
        const entry = { finite: Array.isArray(vals) ? finiteStats(vals) : vals, hidden: !!o.hidden }
        if (ref && ref[name] && Array.isArray(vals)) entry.vsRef = maxDiff(vals, ref[name], 300)
        rec.numeric[name] = entry
      }
      // lenient (import box) lane too
      for (const o of rep.outputs || []) {
        if (!o || !o.ast) continue
        const name = `import:${o.title || o.handle || `line${o.line}`}`
        const vals = evalTree(o.ast)
        const entry = { finite: Array.isArray(vals) ? finiteStats(vals) : vals }
        const base = o.title || o.handle || `line${o.line}`
        if (ref && ref[base] && Array.isArray(vals)) entry.vsRef = maxDiff(vals, ref[base], 300)
        rec.numeric[name] = entry
      }
      rec.numericTreesKeys = trees ? Object.keys(trees) : null
      rec.plotRowCount = plotRows.length
      all[f] = rec
      fs.mkdirSync(OUT, { recursive: true })
      fs.writeFileSync(path.join(OUT, f.replace('.pine', '.json')), JSON.stringify(rec, (k, v) => (v instanceof Set ? [...v] : v), 1))
    })
  }
})
