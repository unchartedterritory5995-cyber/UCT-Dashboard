// PA-2 scratch (NOT committed): what the chart door answers for a non-Pine paste,
// and what each verdict producer says for the same text.
import { it, vi } from 'vitest'
import { inspectSource } from '../../components/chart/builder/PineBox.jsx'
import { memberPaneDefinition } from '../../components/chart/builder/memberPane/memberPaneDefinition.js'
import { inspectScript } from '../../components/chart/builder/libraryIntake.js'

const CASES = [
  ['thinkscript', 'plot avg = Average(close, 20);'],
  ['thinkscript-mtf', 'plot w = Average(close(period = AggregationPeriod.WEEK), 10);'],
  ['pcf', 'C > AVGC50'],
  ['pcf-stoc', 'STOC14.3 < 20'],
  ['formula', 'sma(close, 20)'],
  ['pine-cum', '//@version=5\nindicator("p")\nplot(ta.cum(volume), "C")'],
  ['pine-strategy', '//@version=5\nstrategy("s")\nf = ta.ema(close, 10)\nplot(f, "F")\nif ta.crossover(close, f)\n    strategy.entry("L", strategy.long)'],
]

it('dialects through every verdict producer', () => {
  vi.stubEnv('VITE_PINE_MEMBER_PANE_ENABLED', '1')
  for (const [id, src] of CASES) {
    const box = inspectSource(src, 'auto')
    const pane = memberPaneDefinition({ source: src, id: 'u_member-pane-pa2d' })
    const lib = inspectScript(src, id)
    console.log('DIA', id, JSON.stringify({
      dialect: box.dialect, box: box.outcome.verdict, boxReason: String(box.outcome.reason || '').slice(0, 80),
      boxSemantic: box.outcome.semantic.map((n) => String(n.name).slice(0, 30)),
      pane: pane.ok, paneReason: pane.ok ? null : String(pane.reason || '').slice(0, 110), paneTags: pane.requirementTags || [],
      lib: { dialect: lib.dialect, translates: lib.translates, saves: lib.saves, screens: lib.screens, refusal: lib.refusal ? String(lib.refusal.message).slice(0, 80) : null },
    }))
  }
})
