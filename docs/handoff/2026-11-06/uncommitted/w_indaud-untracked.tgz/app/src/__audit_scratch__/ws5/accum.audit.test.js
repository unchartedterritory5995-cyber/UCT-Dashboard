import { it, vi } from 'vitest'
import { memberPaneDefinition } from '../../components/chart/builder/memberPane/memberPaneDefinition.js'
import { inspectSource } from '../../components/chart/builder/PineBox.jsx'
import { interpret } from '../../components/chart/engine/ast/interpret.js'
import { makeBars } from './refs.js'
const L = String.fromCharCode(10)
const bars = makeBars(1500, 7)
it('accum approximation', () => {
  for (const a of [0.1, 0.02, 0.005]) {
    const src = ['//@version=5', 'indicator("p")', 'var float e = na', `e := na(e[1]) ? close : ${a} * close + ${1 - a} * e[1]`, 'plot(e, "E")'].join(L)
    const pane = memberPaneDefinition({ source: src, id: 'u_member-pane-acc' })
    const rep = inspectSource(src, 'auto')
    const ref = []; let p = NaN
    for (const b of bars) { p = Number.isFinite(p) ? a * b.c + (1 - a) * p : b.c; ref.push(p) }
    let info = ''
    const o = pane.translation && pane.translation.outputs.find((x) => x && x.ast)
    if (pane.ok && o) {
      for (const opts of [{ tf: 'D' }, { tf: 'D', newestBarIsForming: false, historyFromListing: true }]) {
        const v = Array.from(interpret(o.ast, bars, {}, undefined, undefined, opts))
        let worst = 0; let n = 0; let nan = 0
        for (let i = 300; i < bars.length; i++) { if (!Number.isFinite(v[i])) { nan++; continue } n++; worst = Math.max(worst, Math.abs(v[i] - ref[i]) / ref[i]) }
        info += ` | opts=${JSON.stringify(opts)} compared=${n} na=${nan} worstRel=${worst.toExponential(2)}`
      }
    }
    console.log('ALPHA', a, 'import', rep.outcome.verdict, 'pane', pane.ok, pane.guard || '', o && o.formula, info)
  }
})
