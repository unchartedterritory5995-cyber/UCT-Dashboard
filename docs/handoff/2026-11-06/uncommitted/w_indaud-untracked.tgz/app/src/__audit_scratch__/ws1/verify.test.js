// WS1 audit scratch harness — NOT COMMITTED. Independent textbook implementations
// vs the engine's native + formula lanes on synthetic bars.
import { test, expect } from 'vitest'
import fs from 'node:fs'
import { getDefinition, computeFor, NATIVE_DEFS, SERVER_DEFS } from '../../components/chart/engine/nativeRegistry'
import { parseFormula } from '../../components/chart/engine/ast/parse'
import { interpret } from '../../components/chart/engine/ast/interpret'

// ── synthetic data ──────────────────────────────────────────────────────────
function lcg(seed) { let s = seed >>> 0; return () => ((s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 4294967296) }
function makeBars({ n, start, step, seed = 7, sessionFilter = null }) {
  const r = lcg(seed); const bars = []; let px = 100
  for (let t = start; bars.length < n; t += step) {
    if (sessionFilter && !sessionFilter(t)) continue
    const o = px; const drift = (r() - 0.5) * 2
    const c = Math.max(1, o + drift); const h = Math.max(o, c) + r() * 0.8; const l = Math.min(o, c) - r() * 0.8
    const v = Math.round(1000 + r() * 9000)
    bars.push({ t, o, h, l, c, v }); px = c
  }
  return bars
}
const etParts = new Intl.DateTimeFormat('en-US', { timeZone: 'America/New_York', hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', weekday: 'short' })
function et(t) { const o = {}; for (const p of etParts.formatToParts(new Date(t * 1000))) o[p.type] = p.value; return o }
// 5m bars 04:00-20:00 ET on weekdays, crossing the 2026-03-08 DST change.
const intraday = makeBars({ n: 900, start: Date.UTC(2026, 2, 4, 0, 0) / 1000, step: 300, sessionFilter: (t) => {
  const p = et(t); if (p.weekday === 'Sat' || p.weekday === 'Sun') return false
  const m = +p.hour * 60 + +p.minute; return m >= 240 && m < 1200 } })
// daily bars (weekday 16:00 UTC stamps as unix seconds)
const daily = makeBars({ n: 600, start: Date.UTC(2023, 0, 2, 0, 0) / 1000, step: 86400, seed: 11, sessionFilter: (t) => { const d = new Date(t * 1000).getUTCDay(); return d !== 0 && d !== 6 } })

// ── textbook references (TradingView/Pine conventions unless named) ─────────
const NaNs = (n) => new Array(n).fill(NaN)
const C = (b) => b.map((x) => x.c)
function tbSma(s, n) { const o = NaNs(s.length); for (let i = n - 1; i < s.length; i++) { let a = 0; for (let j = i - n + 1; j <= i; j++) a += s[j]; o[i] = a / n } return o }
function tbEmaSmaSeed(s, n, alpha = 2 / (n + 1)) { // Pine ta.ema / ta.rma: seed = SMA of first n
  const o = NaNs(s.length); let first = s.findIndex(Number.isFinite); if (first < 0) return o
  let prev = NaN
  for (let i = first; i < s.length; i++) {
    if (Number.isNaN(prev)) { if (i - first + 1 === n) { let a = 0; for (let j = first; j <= i; j++) a += s[j]; prev = a / n; o[i] = prev } continue }
    prev = alpha * s[i] + (1 - alpha) * prev; o[i] = prev
  }
  return o
}
function tbEmaFirstValueSeed(s, n) { const o = NaNs(s.length); const k = 2 / (n + 1); let p = s[0]; o[0] = p; for (let i = 1; i < s.length; i++) { p = k * s[i] + (1 - k) * p; o[i] = p } return o }
function tbRsi(s, n) { // Wilder: change from bar1, rma seeded with SMA of first n changes
  const g = NaNs(s.length), l = NaNs(s.length)
  for (let i = 1; i < s.length; i++) { const d = s[i] - s[i - 1]; g[i] = Math.max(d, 0); l[i] = Math.max(-d, 0) }
  const ag = tbEmaSmaSeed(g, n, 1 / n), al = tbEmaSmaSeed(l, n, 1 / n)
  return ag.map((a, i) => (Number.isFinite(a) ? (al[i] === 0 ? 100 : 100 - 100 / (1 + a / al[i])) : NaN))
}
function tbTr(b, pineBar0) { return b.map((x, i) => (i === 0 ? (pineBar0 ? x.h - x.l : NaN) : Math.max(x.h - x.l, Math.abs(x.h - b[i - 1].c), Math.abs(x.l - b[i - 1].c)))) }
const tbAtrWilder = (b, n) => tbEmaSmaSeed(tbTr(b, false), n, 1 / n)
const tbAtrPine = (b, n) => tbEmaSmaSeed(tbTr(b, true), n, 1 / n)
function tbStdev(s, n, sample) { const m = tbSma(s, n); const o = NaNs(s.length); for (let i = n - 1; i < s.length; i++) { let q = 0; for (let j = i - n + 1; j <= i; j++) q += (s[j] - m[i]) ** 2; o[i] = Math.sqrt(q / (sample ? n - 1 : n)) } return o }
function tbMacd(s, f, sl, sg) { const a = tbEmaSmaSeed(s, f), b = tbEmaSmaSeed(s, sl); const m = a.map((x, i) => x - b[i]); const sig = tbEmaSmaSeed(m, sg); return { m, sig, h: m.map((x, i) => x - sig[i]) } }
function tbVwap(b, anchorMinute = 0) { // ET-date anchored (anchorMinute 0) or RTH-anchored (570)
  const o = NaNs(b.length); let key = null, pv = 0, vv = 0
  for (let i = 0; i < b.length; i++) {
    const p = et(b[i].t); const m = +p.hour * 60 + +p.minute
    if (m < anchorMinute) { continue }
    const k = `${p.year}-${p.month}-${p.day}`
    if (k !== key) { key = k; pv = 0; vv = 0 }
    const tp = (b[i].h + b[i].l + b[i].c) / 3; pv += tp * b[i].v; vv += b[i].v; o[i] = pv / vv
  }
  return o
}
function tbStoch(b, n, d) { const k = NaNs(b.length); for (let i = n - 1; i < b.length; i++) { let hh = -Infinity, ll = Infinity; for (let j = i - n + 1; j <= i; j++) { hh = Math.max(hh, b[j].h); ll = Math.min(ll, b[j].l) } k[i] = 100 * (b[i].c - ll) / (hh - ll) } return { k, d: tbSma(k, d) } }
function tbObv(b) { const o = [0]; for (let i = 1; i < b.length; i++) o.push(o[i - 1] + Math.sign(b[i].c - b[i - 1].c) * b[i].v); return o }

// ── comparison ──────────────────────────────────────────────────────────────
function diff(a, b) {
  let max = 0, both = 0, onlyA = 0, onlyB = 0, firstA = -1, firstB = -1
  const n = Math.max(a.length, b.length)
  for (let i = 0; i < n; i++) {
    const x = a[i], y = b[i]; const fx = Number.isFinite(x), fy = Number.isFinite(y)
    if (fx && firstA < 0) firstA = i; if (fy && firstB < 0) firstB = i
    if (fx && fy) { both++; max = Math.max(max, Math.abs(x - y)) } else if (fx) onlyA++; else if (fy) onlyB++
  }
  return { maxAbs: max, compared: both, onlyEngine: onlyA, onlyRef: onlyB, firstEngine: firstA, firstRef: firstB }
}
function diffAfter(a, b, from) { return diff(Array.from(a).map((x, i) => (i >= from ? x : NaN)), b.map((x, i) => (i >= from ? x : NaN))) }
const arr = (col) => Array.from(col)
const native = (id, bars, inputs, ctx) => computeFor(getDefinition(id), bars, inputs || {}, ctx)
const formula = (src, bars) => { const p = parseFormula(src); if (!p.ok) return { err: p.error }; try { return arr(interpret(p.ast, bars, {})) } catch (e) { return { err: String(e.message || e).slice(0, 200) } } }

const results = {}
test('calculation verification', () => {
  const b = intraday, d = daily, cl = C(b), dc = C(d)
  const R = results
  R.bars = { intraday: b.length, daily: d.length }
  // SMA / EMA via movingAverage native + formula lane
  R.sma20_native = diff(arr(native('movingAverage', d, { period: 20, maType: 'sma' }, { source: dc }).ma), tbSma(dc, 20))
  R.sma20_formula = diff(formula('sma(close, 20)', d), tbSma(dc, 20))
  R.ema20_native = diff(arr(native('movingAverage', d, { period: 20, maType: 'ema' }, { source: dc }).ma), tbEmaSmaSeed(dc, 20))
  R.ema20_formula = diff(formula('ema(close, 20)', d), tbEmaSmaSeed(dc, 20))
  R.ema20_vs_firstValueSeed_after100 = diffAfter(native('movingAverage', d, { period: 20, maType: 'ema' }, { source: dc }).ma, tbEmaFirstValueSeed(dc, 20), 100)
  R.ema20_vs_firstValueSeed_at19 = diffAfter(native('movingAverage', d, { period: 20, maType: 'ema' }, { source: dc }).ma, tbEmaFirstValueSeed(dc, 20), 19)
  R.rsi14_native = diff(arr(native('rsi', d).rsi), tbRsi(dc, 14))
  R.rsi14_formula = diff(formula('rsi(close, 14)', d), tbRsi(dc, 14))
  R.atr14_native_vs_wilder = diff(arr(native('atr', d).atr), tbAtrWilder(d, 14))
  R.atr14_native_vs_pine = diff(arr(native('atr', d).atr), tbAtrPine(d, 14))
  R.atr14_native_vs_pine_after100 = diffAfter(native('atr', d).atr, tbAtrPine(d, 14), 100)
  R.atr14_native_vs_pine_after300 = diffAfter(native('atr', d).atr, tbAtrPine(d, 14), 300)
  R.atrPine14_formula_vs_pine = diff(formula('atrPine(high, low, close, 14)', d), tbAtrPine(d, 14))
  R.atr14_formula_vs_wilder = diff(formula('atr(high, low, close, 14)', d), tbAtrWilder(d, 14))
  const bb = native('bb', d)
  const pop = tbStdev(dc, 20, false), smp = tbStdev(dc, 20, true), mid = tbSma(dc, 20)
  R.bb_upper_vs_population = diff(arr(bb.upper), mid.map((m, i) => m + 2 * pop[i]))
  R.bb_upper_vs_sample = diff(arr(bb.upper), mid.map((m, i) => m + 2 * smp[i]))
  R.bb_middle = diff(arr(bb.middle), mid)
  R.stdev20_native_vs_population = diff(arr(native('standardDeviation', d, {}, { source: dc }).stdev), pop)
  R.stdev20_formula_vs_population = diff(formula('stdev(close, 20)', d), pop)
  const mac = native('macd', d), tm = tbMacd(dc, 12, 26, 9)
  R.macd_line = diff(arr(mac.macd), tm.m); R.macd_signal = diff(arr(mac.signal), tm.sig); R.macd_hist = diff(arr(mac.histogram), tm.h)
  R.macd_formula = diff(formula('macd(close, 12, 26)', d), tm.m)
  // VWAP on intraday (ET-day anchor incl. pre-market) and the RTH-anchored reading
  const vw = arr(native('vwap', b).vwap)
  R.vwap_vs_etDayAnchor = diff(vw, tbVwap(b, 0))
  R.vwap_vs_rthAnchor_0930 = diff(vw, tbVwap(b, 570))
  R.vwap_formula_vs_etDay = diff(formula('vwap()', b), tbVwap(b, 0))
  R.vwap_on_daily_native_finite = arr(native('vwap', d).vwap).filter(Number.isFinite).length
  const st = native('stoch', d), ts = tbStoch(d, 14, 3)
  R.stoch_k = diff(arr(st.k), ts.k); R.stoch_d = diff(arr(st.d), ts.d)
  const st3 = native('stoch', d, { smoothK: 3 }), slowK = tbSma(ts.k, 3)
  R.stoch_slow_k3 = diff(arr(st3.k), slowK); R.stoch_slow_d = diff(arr(st3.d), tbSma(slowK, 3))
  R.stoch_formula_k = diff(formula('stoch(high, low, close, 14)', d), ts.k)
  R.obv = diff(arr(native('obv', d).obv), tbObv(d))
  // determinism: two runs bit-identical
  const runA = JSON.stringify(Object.fromEntries(NATIVE_DEFS.map((def) => [def.id, Object.fromEntries(Object.entries(computeFor(def, d, {}, { source: dc })).map(([k, v]) => [k, Array.from(v || [])]))])))
  const runB = JSON.stringify(Object.fromEntries(NATIVE_DEFS.map((def) => [def.id, Object.fromEntries(Object.entries(computeFor(def, d, {}, { source: dc })).map(([k, v]) => [k, Array.from(v || [])]))])))
  R.deterministic = runA === runB
  fs.writeFileSync('src/__audit_scratch__/ws1/bars_daily.json', JSON.stringify(d))
  fs.writeFileSync('src/__audit_scratch__/ws1/bars_intraday.json', JSON.stringify(b))
  // engine columns for Python parity
  fs.writeFileSync('src/__audit_scratch__/ws1/js_cols.json', JSON.stringify({
    rsi: arr(native('rsi', d).rsi), atr: arr(native('atr', d).atr), bb_upper: arr(bb.upper), macd: arr(mac.macd), signal: arr(mac.signal),
    stoch_k: arr(st.k), stoch_d: arr(st.d), obv: arr(native('obv', d).obv), vwap: vw, cci: arr(native('cci', d).cci), mfi: arr(native('mfi', d).mfi),
    williams_r: arr(native('williamsR', d).williams_r), adx: arr(native('adx', d).adx), sar: arr(native('sar', d).sar),
    spanA: arr(native('ichimoku', d).spanA), chikou: arr(native('ichimoku', d).chikou), donchian_upper: arr(native('donchian', d).upper),
    atrBands_upper: arr(native('atrBands', d).upper), avwap_week: arr(native('avwap', b, { anchor: 'week' }).avwap),
  }, (k, v) => (typeof v === 'number' && !Number.isFinite(v) ? null : v)))
})

// ── lookahead / repaint by prefix truncation, every native def ──────────────
test('prefix-truncation lookahead probe (every native)', () => {
  const out = {}
  for (const [label, bars] of [['daily', daily], ['intraday', intraday]]) {
    for (const def of NATIVE_DEFS) {
      const full = computeFor(def, bars, {}, { source: C(bars) })
      let worst = { cuts: 0, changed: 0, maxAbs: 0, cols: new Set() }
      for (const k of [120, 250, 400, 551]) {
        if (k >= bars.length) continue
        const pre = bars.slice(0, k)
        const part = computeFor(def, pre, {}, { source: C(pre) })
        worst.cuts++
        for (const key of Object.keys(full)) {
          if (key.startsWith('__')) continue
          const A = full[key], B = part[key]; if (!A || !B || typeof A.length !== 'number') continue
          for (let i = 0; i < k; i++) {
            const x = A[i], y = B[i]
            const same = (Number.isNaN(x) && Number.isNaN(y)) || x === y || Math.abs(x - y) < 1e-9
            if (!same) { worst.changed++; worst.cols.add(key); if (Number.isFinite(x) && Number.isFinite(y)) worst.maxAbs = Math.max(worst.maxAbs, Math.abs(x - y)) }
          }
        }
      }
      if (worst.changed) out[`${label}:${def.id}`] = { changed: worst.changed, maxAbs: worst.maxAbs, cols: [...worst.cols] }
    }
  }
  results.prefixProbe = out
})

// ── warm-up: first finite index per native column (daily, defaults) ────────
test('warm-up census', () => {
  const out = {}
  for (const def of NATIVE_DEFS) {
    const cols = computeFor(def, daily, {}, { source: C(daily) })
    out[def.id] = Object.fromEntries(Object.entries(cols).filter(([k]) => !k.startsWith('__')).map(([k, v]) => [k, Array.from(v).findIndex(Number.isFinite)]))
  }
  results.warmup = out
})

// ── NaN / gap behaviour: a NaN close mid-series ──────────────────────────────
test('NaN hole policy census', () => {
  const holed = daily.slice(0, 200).map((x, i) => (i === 100 ? { ...x, c: NaN } : x))
  const src = C(holed)
  const first = (a, from) => { for (let i = from; i < a.length; i++) if (Number.isFinite(a[i])) return i; return -1 }
  const out = {}
  out.native_sma20 = first(arr(native('movingAverage', holed, { period: 20, maType: 'sma' }, { source: src }).ma), 100)
  out.native_ema20 = first(arr(native('movingAverage', holed, { period: 20, maType: 'ema' }, { source: src }).ma), 100)
  out.formula_sma20 = first(formula('sma(close, 20)', holed), 100)
  out.formula_ema20 = first(formula('ema(close, 20)', holed), 100)
  out.native_rsi14 = first(arr(native('rsi', holed).rsi), 100)
  out.native_macd = first(arr(native('macd', holed).macd), 100)
  out.native_bb = first(arr(native('bb', holed).middle), 100)
  out.native_atr = first(arr(native('atr', holed).atr), 100)
  out.native_obv_at100 = arr(native('obv', holed).obv)[100]
  out.native_stoch = first(arr(native('stoch', holed).k), 100)
  out.formula_stdev = first(formula('stdev(close, 20)', holed), 100)
  out.formula_highest = first(formula('highest(close, 20)', holed), 100)
  // NaN volume inside an intraday session
  const vh = intraday.slice(0, 300).map((x, i) => (i === 50 ? { ...x, v: NaN } : x))
  const vwh = arr(native('vwap', vh).vwap)
  out.vwap_after_nan_volume_finite_in_rest_of_session = vwh.slice(51, 120).filter(Number.isFinite).length
  out.vwap_after_nan_volume_first_finite = first(vwh, 50)
  results.nanPolicy = out
})

// ── out-of-range / non-integer inputs straight into computeFor ──────────────
test('input domain probe', () => {
  const out = {}
  for (const [id, inp] of [['rsi', { period: 0 }], ['rsi', { period: 14.5 }], ['rsi', { period: -3 }], ['bb', { period: 1, stdDev: 2 }], ['atr', { period: 0 }], ['macd', { fastPeriod: 26, slowPeriod: 12 }], ['stoch', { kPeriod: 0 }]]) {
    try {
      const cols = native(id, daily, inp)
      const k = Object.keys(cols).find((x) => !x.startsWith('__'))
      const a = arr(cols[k]); out[`${id}:${JSON.stringify(inp)}`] = { finite: a.filter(Number.isFinite).length, nonFinite: a.filter((x) => !Number.isNaN(x) && !Number.isFinite(x)).length }
    } catch (e) { out[`${id}:${JSON.stringify(inp)}`] = { threw: String(e.message).slice(0, 120) } }
  }
  results.inputDomain = out
  fs.writeFileSync('src/__audit_scratch__/ws1/verify.json', JSON.stringify(results, null, 1))
  expect(true).toBe(true)
})
