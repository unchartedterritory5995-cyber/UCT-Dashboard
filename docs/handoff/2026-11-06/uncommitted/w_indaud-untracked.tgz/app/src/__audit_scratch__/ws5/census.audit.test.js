import { it, vi } from 'vitest'
import fs from 'node:fs'
import path from 'node:path'
import { inspectSource } from '../../components/chart/builder/PineBox.jsx'
import { memberPaneDefinition } from '../../components/chart/builder/memberPane/memberPaneDefinition.js'
const DIR = path.resolve(__dirname, '../../../../corpus/committed')
const OUT = process.env.WS5_OUT
it('committed corpus census', () => {
  const rows = []
  for (const f of fs.readdirSync(DIR).filter((x) => x.endsWith('.pine')).sort()) {
    const src = fs.readFileSync(path.join(DIR, f), 'utf8')
    const row = { f, strategy: /^\s*strategy\s*\(/m.test(src), version: (src.match(/\/\/@version=(\d)/) || [])[1] || null }
    try { const r = inspectSource(src, 'auto'); row.imp = r.outcome.verdict; row.impGuard = r.refusal && r.refusal.guard } catch { row.imp = 'THREW' }
    vi.stubEnv('VITE_PINE_OBJECTS_ONLY_PANE_ENABLED', '1'); vi.stubEnv('VITE_PINE_RUNTIME_PANE_ENABLED', '0')
    try { const p = memberPaneDefinition({ source: src, id: 'u_member-pane-cen' }); row.host = p.ok; row.hostGuard = p.guard; row.hostNotes = (p.notes || []).length; row.drawn = p.ok ? { plots: (p.definition.plots || []).filter((x) => !x.hidden).length, objects: !!p.definition.objects, paints: (p.definition.paints || []).length } : null } catch (e) { row.host = 'THREW' }
    if (row.host !== true) {
      vi.stubEnv('VITE_PINE_RUNTIME_PANE_ENABLED', '1')
      try { const p = memberPaneDefinition({ source: src, id: 'u_member-pane-cer' }); row.rt = p.ok ? (p.definition.compute.kind) : `no:${(p.runtimeDeclined && p.runtimeDeclined.code) || p.guard}` } catch { row.rt = 'THREW' }
    }
    rows.push(row)
  }
  fs.writeFileSync(path.join(OUT, 'census.json'), JSON.stringify(rows, null, 1))
})
