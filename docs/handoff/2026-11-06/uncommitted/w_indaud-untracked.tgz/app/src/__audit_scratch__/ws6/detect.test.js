import { it } from 'vitest'
import fs from 'fs'
import { inspectSource } from '../../components/chart/builder/PineBox.jsx'
import { evaluateFormula } from '../../components/chart/builder/FormulaField.jsx'
import { BUILDER_INPUT_SCOPE } from '../../components/chart/builder/builderInputs.js'
import { inspectScript, splitPaste } from '../../components/chart/builder/libraryIntake.js'

it('detect', () => {
  const lines = []
  const probes = {
    tosScanOneLinerAnd: 'close > Average(close, 50) and volume > 500000',
    tosScanOneLinerUpper: 'close > Average(close, 50) AND volume > 500000',
    tosScanSingle: 'close > Average(close, 50)',
    tosScanRSI: 'RSI(length = 14, price = close) < 30',
    tosScanBracket: 'close > close[1] and volume > volume[1]',
    tosExpAverageCross: 'ExpAverage(close, 9) crosses above ExpAverage(close, 21)',
    pcfLower: 'c > avgc50',
    pcfMixed: 'C > AVGC50 and V > 1.5 * AVGV50',
    nativeAndWord: 'close > sma(close, 50) and volume > 1000000',
  }
  for (const [n, s] of Object.entries(probes)) {
    const r = inspectSource(s, 'auto')
    lines.push(`${n} [${s}] -> dialect=${r.dialect} ok=${r.ok} rerouted=${JSON.stringify(r.rerouted || null)} verdict=${r.outcome.verdict} formula=${(r.outputs[0] || {}).formula || '-'} | ${r.refusal ? r.refusal.guard + ': ' + String(r.refusal.message).slice(0, 300) : ''}`)
  }
  // formula tab (FormulaField) path for PCF and thinkScript text
  for (const s of ['C > AVGC50', 'plot x = close > Average(close, 50);', 'close > Average(close, 50)']) {
    const e = evaluateFormula(s, BUILDER_INPUT_SCOPE)
    lines.push(`FORMULA TAB [${s}] ok=${e.ok} dialect=${e.dialect} ${e.ok ? '' : e.guard + ': ' + String(e.error).slice(0, 200)}`)
  }
  // library intake of two thinkScripts pasted together and a PCF
  const two = 'def a = Average(close, 10);\nplot p = a;\n\ndef b = ExpAverage(close, 20);\nplot q = b;'
  lines.push('splitPaste two TS -> ' + JSON.stringify(splitPaste(two).found))
  lines.push('inspectScript PCF -> ' + JSON.stringify(inspectScript('C > AVGC50')).slice(0, 300))
  lines.push('inspectScript TS -> ' + JSON.stringify(inspectScript('plot p = Average(close, 10);')).slice(0, 300))
  fs.writeFileSync('src/__audit_scratch__/ws6/detect.txt', lines.join('\n'))
})
