import { it } from 'vitest'
import fs from 'fs'
import { inspectSource } from '../../components/chart/builder/PineBox.jsx'
import { interpret } from '../../components/chart/engine/ast/interpret.js'
import { B } from './numeric.test.js'

const run = (src, dialect = 'auto') => {
  const r = inspectSource(src, dialect)
  const o = r.outputs[r.selected >= 0 ? r.selected : 0]
  const ast = o && (o.ast || (o.downstream && o.downstream.ast))
  return { r, ast, vals: ast ? [...interpret(ast, B, {}, undefined, {})] : null, formula: o && o.formula }
}

it('debug', () => {
  const N = B.length
  const C = B.map((b) => b.c), H = B.map((b) => b.h), L = B.map((b) => b.l)
  const lines = []
  // stoch component
  const k = run('STOC14.3 < 200 AND STOC14.3 > -1')
  const kv = run('STOC14.3 + 0')
  const raw = []
  for (let i = 0; i < N; i++) {
    if (i < 13) { raw.push(NaN); continue }
    const hh = Math.max(...H.slice(i - 13, i + 1)), ll = Math.min(...L.slice(i - 13, i + 1))
    raw.push(100 * (C[i] - ll) / (hh - ll))
  }
  const sm = raw.map((_, i) => (i < 15 ? NaN : (raw[i] + raw[i - 1] + raw[i - 2]) / 3))
  lines.push('STOC formula ' + (kv.formula) + ' ok=' + kv.r.ok + ' ' + JSON.stringify(kv.r.refusal))
  if (kv.vals) lines.push('STOC tail eng ' + kv.vals.slice(-4).map((x) => x.toFixed(4)) + ' ref ' + sm.slice(-4).map((x) => x.toFixed(4)))
  // ref closes stoch variant (stoch(close, high, low) vs close-only)
  // stdev check
  const sd = run('STDDEV20 + 0')
  const pop = C.map((_, i) => { if (i < 19) return NaN; const w = C.slice(i - 19, i + 1); const m = w.reduce((a, b) => a + b) / 20; return Math.sqrt(w.reduce((a, b) => a + (b - m) ** 2, 0) / 20) })
  if (sd.vals) lines.push('STDDEV tail eng ' + sd.vals.slice(-3).map((x) => x.toFixed(6)) + ' pop ' + pop.slice(-3).map((x) => x.toFixed(6)) + ' samp ' + pop.slice(-3).map((x) => (x * Math.sqrt(20 / 19)).toFixed(6)))
  // weekly: engine == sma over 10 DAILY bars of tf(close,W)?
  const tfw = run('plot p = close(period = AggregationPeriod.WEEK);', 'thinkscript')
  const sma10ofTf = tfw.vals.map((_, i) => (i < 9 ? NaN : tfw.vals.slice(i - 9, i + 1).reduce((a, b) => a + b) / 10))
  const wma = run(fs.readFileSync('C:/w/indaud/docs/indicators/audit-2026-10-13/migration-corpus/thinkscript/07-mtf-weekly-average.ts', 'utf8'))
  lines.push('tf(close,W) tail ' + tfw.vals.slice(-8).map((x) => x.toFixed(3)) + ' | daily close tail ' + C.slice(-8).map((x) => x.toFixed(3)))
  lines.push('engine WeeklyMA tail ' + wma.vals.slice(-3).map((x) => x.toFixed(4)) + ' == sma(tf,10 DAILY) ' + sma10ofTf.slice(-3).map((x) => x.toFixed(4)))
  // Pine equivalent for contrast
  const pine = inspectSource('//@version=5\nindicator("w")\nplot(request.security(syminfo.tickerid, "W", ta.sma(close, 10)))', 'auto')
  lines.push('PINE weekly sma formula: ' + (pine.outputs[0] && pine.outputs[0].formula) + ' ok=' + pine.ok)
  if (pine.outputs[0] && pine.outputs[0].ast) lines.push('PINE weekly tail ' + [...interpret(pine.outputs[0].ast, B, {}, undefined, {})].slice(-3).map((x) => x.toFixed(4)))
  // close(period=WEEK)[1] semantics
  const off = run('plot p = close(period = AggregationPeriod.WEEK)[1];', 'thinkscript')
  lines.push('weekly[1] formula ' + off.formula + ' -> tail ' + (off.vals || []).slice(-6).map((x) => x.toFixed(3)))
  // misc thinkScript probes
  const probes = {
    macdStudy: 'plot d = MACD(12, 26, 9).Diff;',
    macdNamed: 'plot d = MACD(fastLength = 12, slowLength = 26, MACDLength = 9, averageType = AverageType.EXPONENTIAL).Diff;',
    rsiNoArgs: 'plot r = RSI();',
    rsiPositional: 'plot r = RSI(14);',
    stochFull: 'plot k = StochasticFull(80, 20, 14, 3, high, low, close, 3).FullK;',
    keltner: 'plot u = KeltnerChannels().Upper_Band;',
    simpleAvgStudy: 'plot s = SimpleMovingAvg(price = close, length = 50, displace = 0);',
    adx: 'plot a = ADX(14);',
    vwap: 'plot v = vwap();',
    crossesFn: 'plot x = Crosses(close, Average(close, 20), CrossingDirection.ABOVE);',
    crossesWord: 'plot x = close crosses above Average(close, 20);',
    getvalue: 'plot x = GetValue(close, 3);',
    highestBars: 'plot x = GetMaxValueOffset(high, 20);',
    symbolSpy: 'plot rs = close / close(symbol = "SPY");',
    symbolOther: 'plot rs = close / close("QQQ");',
    lowerTf: 'plot x = close(period = AggregationPeriod.HOUR);',
    dayAgg: 'plot x = close(period = AggregationPeriod.DAY)[1];',
    getAgg: 'plot x = if GetAggregationPeriod() == AggregationPeriod.DAY then close else open;',
    barNumber: 'plot x = BarNumber();',
    script: 'script f { input x = 1; plot y = x * 2; }\nplot z = f(close);',
    reference: 'plot r = reference RSI(length = 14, price = close);',
    ohlc4: 'plot x = ohlc4;',
    vwapField: 'plot x = vwap;',
    nz: 'plot x = if IsNaN(close[1]) then 0 else close - close[1];',
    ifElseIf: 'def x = if close > open then 1 else if close < open then -1 else 0;\nplot y = x;',
    recSeedless: 'rec cnt = if close > close[1] then cnt[1] + 1 else 0;\nplot y = cnt;',
    recReplace: 'def hiSince = if high > hiSince[1] then high else hiSince[1];\nplot y = hiSince;',
    compoundStreak: 'def s = CompoundValue(1, if close > open then s[1] + 1 else 0, 0);\nplot y = s;',
    totalSum: 'plot y = TotalSum(volume);',
    lowerCaseAll: 'plot y = average(close, 10) > expaverage(close, 20);',
    stdevAll: 'plot y = StDevAll(close);',
    linRegCurve: 'plot y = Inertia(close, 20);',
    wildersBuiltin: 'plot y = WildersAverage(close, 14);',
    atrStudy: 'plot y = ATR(14);',
    alertOnly: 'Alert(close > open, "up", Alert.BAR, Sound.Ding);',
    exp_neg: 'plot y = close[-1];',
    fpl: 'plot y = Fundamental(FundamentalType.CLOSE, period = AggregationPeriod.WEEK);',
  }
  for (const [n, s] of Object.entries(probes)) {
    const r = inspectSource(s, 'thinkscript')
    const o = (r.outputs || [])[0] || {}
    lines.push(`PROBE ${n}: ok=${r.ok} verdict=${r.outcome && r.outcome.verdict} formula=${o.formula || '-'} | ${r.refusal ? r.refusal.guard + ': ' + String(r.refusal.message).slice(0, 260) : (r.outcome && r.outcome.reason) || ''}`)
  }
  // PCF probes
  const pcf = {
    rsiPlain: 'RSI14 < 30', avgv: 'AVGV50 > 500000', xavgv: 'XAVGV20 > 1', ma1: 'C > AVGC50.1',
    bars: 'BARSSINCE(C > C1) > 1', sincetrue: 'SINCETRUE(C > MAXC20.1, 50) < 5', trueinrow: 'TRUEINROW(C > C1, 5) = 5',
    lowercaseAnd: 'c > avgc50 and v > 2 * avgv50', paren: '(C - MINL52) / (MAXH52 - MINL52) > 0.8',
    bb: 'C > BB20.2', pe: 'PE < 20', eps: 'EPS > 0', mcap: 'Capitalization > 1000', sector: 'Sector = 1',
    vperc: 'V / AVGV50 * 100 > 150', dollarvol: 'AVGC20 * AVGV20 > 20000000', ratio: 'C / C252 > 1.5',
    xupNumber: 'XUP(WRSI14, 30)', iif: 'IIF(C > O, 1, -1) > 0', weekly: 'C > AVGC10W', offsetExpr: 'C(3) > C',
    stoc: 'STOC14.3.1 < 20', notOp: 'NOT (C < O)', percentDown: 'C <= 0.75 * MAXH252', truerange: 'ABS(H - L) > 2 * AVG(H - L, 20)',
  }
  for (const [n, s] of Object.entries(pcf)) {
    const r = inspectSource(s, 'auto')
    lines.push(`PCF ${n} [${s}]: dialect=${r.dialect} ok=${r.ok} verdict=${r.outcome && r.outcome.verdict} | ${r.refusal ? r.refusal.guard + ': ' + String(r.refusal.message).slice(0, 240) : ''} | readback=${r.outputs[0] && r.outputs[0].downstream ? String(r.outputs[0].downstream.readback).slice(0, 160) : ''}`)
  }
  fs.writeFileSync('src/__audit_scratch__/ws6/debug.txt', lines.join('\n'))
})
