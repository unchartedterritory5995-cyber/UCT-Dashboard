// WS1 audit scratch — MTF projection lookahead probe + timeframe eligibility. NOT COMMITTED.
import { test } from 'vitest'
import fs from 'node:fs'
import { projectFrameColumns } from '../../components/chart/engine/mtfProjection'
import { eligibleInstances } from '../../components/chart/engine/eligibility'
import * as registry from '../../components/chart/engine/nativeRegistry'

test('mtf + eligibility', () => {
  const out = {}
  // daily frame bars: ISO dates Mon-Fri for 3 weeks; value = day ordinal
  const days = []
  for (let d = new Date(Date.UTC(2026, 2, 2)); days.length < 15; d = new Date(d.getTime() + 86400000)) {
    const w = d.getUTCDay(); if (w === 0 || w === 6) continue
    days.push(d.toISOString().slice(0, 10))
  }
  const frameBars = days.map((iso) => ({ t: iso }))
  const col = Float64Array.from(days.map((_, i) => i))
  // 5m chart bars 09:30-16:00 ET (EST, UTC-5 until Mar 8; EDT after)
  const chart = []
  for (const iso of days) {
    const [y, m, dd] = iso.split('-').map(Number)
    const off = (m === 3 && dd >= 8) || m > 3 ? 4 : 5
    for (let k = 0; k < 78; k++) chart.push({ t: Date.UTC(y, m - 1, dd, 9 + off, 30) / 1000 + k * 300, iso })
  }
  for (const newestFinal of [true, false]) {
    const r = projectFrameColumns(frameBars, { v: col }, 'D', chart, '5', { newestFinal })
    let lookahead = 0, sameDay = 0, prevDay = 0, nan = 0
    chart.forEach((b, i) => {
      const v = r.columns.v[i]; const di = days.indexOf(b.iso)
      if (Number.isNaN(v)) { nan++; return }
      if (v > di) lookahead++; else if (v === di) sameDay++; else if (v === di - 1) prevDay++
    })
    out[`dailyOn5m_newestFinal=${newestFinal}`] = { lookahead, sameDay, prevDay, nan, stale: r.stale }
  }
  // eligibility: which chart TFs hide which defs
  const ids = ['vwap', 'avwap', 'historicalVolatility', 'fiftyTwoWeek', 'rsi']
  const insts = ids.map((defId, i) => ({ instanceId: `i${i}`, defId, inputs: {} }))
  for (const tf of ['1', '2', '3', '5', '10', '45', '65', '195', '60', '120', '240', 'D', '2D', 'W', '2W', 'M', '3M', '12M']) {
    const r = eligibleInstances(insts, registry, { tf })
    const kept = Array.isArray(r) ? r : (r.kept || r.instances || [])
    const hidden = (r.hidden || []).map((h) => h.inst.defId)
    out[`tf:${tf}`] = { hidden }
  }
  fs.writeFileSync('src/__audit_scratch__/ws1/mtf.json', JSON.stringify(out, null, 1))
})
