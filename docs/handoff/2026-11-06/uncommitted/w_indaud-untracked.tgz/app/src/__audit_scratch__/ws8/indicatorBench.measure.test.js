// WS8 audit scratch micro-benchmark — NOT committed. Measured under SHARED CPU load
// (8 concurrent auditors); report RELATIVE numbers only.
import { describe, it, expect } from 'vitest'
import { parseFormula } from '../../components/chart/engine/ast/parse'
import { interpret } from '../../components/chart/engine/ast/interpret'
import { checkBudget } from '../../components/chart/engine/ast/budget'
import { computeRuntimeColumns } from '../../components/chart/engine/runtime/runtimeColumns'

const N = 5000
function mkBars(n, seed = 1) {
  let x = seed
  const rnd = () => { x = (x * 16807) % 2147483647; return x / 2147483647 }
  const out = []
  let c = 100
  for (let i = 0; i < n; i += 1) {
    const d = new Date(Date.UTC(2006, 0, 2) + i * 86400000).toISOString().slice(0, 10)
    c = Math.max(1, c * (1 + (rnd() - 0.5) * 0.04))
    out.push({ t: d, o: c * 0.995, h: c * 1.01, l: c * 0.99, c, v: 1e6 + Math.floor(rnd() * 1e6) })
  }
  return out
}
const BARS = mkBars(N)

const FORMULAS = [
  'sma(close, 20)',
  'ema(close, 50)',
  'rsi(close, 14)',
  'close > sma(close, 50)',
  'sma(close, 50) - sma(close, 200)',
  '(close - lowest(low, 14)) / (highest(high, 14) - lowest(low, 14)) * 100',
  'atr(14)',
  'stdev(close, 20) * 2 + sma(close, 20)',
  'crossOver(ema(close, 9), ema(close, 21))',
  'volume / sma(volume, 50)',
]

const median = (a) => { const s = [...a].sort((p, q) => p - q); return s[Math.floor(s.length / 2)] }
const time = (fn, reps) => { const t = []; for (let r = 0; r < reps; r += 1) { const t0 = performance.now(); fn(); t.push(performance.now() - t0) } return median(t) }

describe('WS8 micro-benchmark (shared-CPU, relative only)', () => {
  it('parse + 10-indicator set over 5,000 bars: cold vs pass-memo vs re-eval after a tick', () => {
    const t0 = performance.now()
    const parsed = FORMULAS.map((f) => parseFormula(f))
    const parseMs = performance.now() - t0
    const bad = parsed.map((p, i) => (p.ok ? null : `${FORMULAS[i]} -> ${p.error}`)).filter(Boolean)
    const trees = []
    parsed.forEach((p, i) => {
      if (!p.ok) return
      try { checkBudget(p.ast); interpret(p.ast, BARS.slice(0, 300), {}, undefined, undefined, { tf: 'D' }); trees.push(p.ast) }
      catch (e) { bad.push(`${FORMULAS[i]} -> ${e && (e.guard || e.message)}`) }
    })

    const cold = time(() => { for (const t of trees) interpret(t, BARS, {}, undefined, undefined, { tf: 'D' }) }, 7)
    const shared = time(() => {
      const crossMemo = new Map()
      for (const t of trees) interpret(t, BARS, {}, undefined, undefined, { tf: 'D', crossMemo })
    }, 7)
    // a "tick": same history, last close nudged, NEW array identity (what the binder memo keys on)
    const ticked = BARS.slice(); ticked[N - 1] = { ...ticked[N - 1], c: ticked[N - 1].c * 1.001 }
    const afterTick = time(() => { for (const t of trees) interpret(t, ticked, {}, undefined, undefined, { tf: 'D' }) }, 7)
    console.log(JSON.stringify({ bench: 'ten-formulas', bars: N, parsedOk: trees.length, refused: bad, parseMsAll10: +parseMs.toFixed(2),
      coldMedianMs: +cold.toFixed(1), passMemoMedianMs: +shared.toFixed(1), reEvalAfterTickMs: +afterTick.toFixed(1) }))
    expect(trees.length).toBeGreaterThan(5)
  })

  it('worst case at the formula budget cap (nested windows near maxLookback / maxNodes)', () => {
    // nested windows: each sma adds lookback; stop at the largest that the budget admits
    let src = 'close'
    let last = null
    for (let k = 0; k < 40; k += 1) {
      const next = `sma(${src}, 13)`
      const p = parseFormula(next)
      if (!p.ok) break
      const v = (() => { try { checkBudget(p.ast); return true } catch (e) { last = e && (e.guard || e.message); return false } })()
      if (!v) break
      try { interpret(p.ast, BARS.slice(0, 50), {}, undefined, undefined, { tf: 'D' }) } catch (e) { last = `interpret:${e && (e.guard || e.message)}`; break }
      src = next
    }
    const ast = parseFormula(src).ast
    let nestedErr = null
    const ms = time(() => { try { interpret(ast, BARS, {}, undefined, undefined, { tf: 'D' }) } catch (e) { nestedErr = e && (e.guard || e.message) } }, 5)
    // a wide tree near maxNodes: sum of many distinct windows
    const terms = []
    let wide = null
    for (let k = 2; k < 200; k += 1) {
      const cand = [...terms, `sma(close, ${k})`].join(' + ')
      const p = parseFormula(cand)
      let ok = p.ok
      if (ok) { try { checkBudget(p.ast); interpret(p.ast, BARS.slice(0, 50), {}, undefined, undefined, { tf: 'D' }) } catch (e) { ok = false; last = e && (e.guard || e.message) } }
      if (!ok) break
      terms.push(`sma(close, ${k})`); wide = p.ast
    }
    const wideMs = wide ? time(() => interpret(wide, BARS, {}, undefined, undefined, { tf: 'D' }), 5) : null
    console.log(JSON.stringify({ bench: 'budget-cap', nestedDepthAdmitted: (src.match(/sma\(/g) || []).length, nestedMedianMs: +ms.toFixed(1), nestedErr,
      wideTermsAdmitted: terms.length, wideMedianMs: wideMs && +wideMs.toFixed(1), refusedBy: last }))
    expect(true).toBe(true)
  })

  it('runtime lane: a runaway loop is stopped by name, and how long that takes', () => {
    const head = '//@version=6\nindicator("t", overlay = true)\n'
    const cases = {
      runawayFor: 'float s = 0.0\nfor i = 0 to 100000\n    s += i\nplot(s)\n',
      runawayWhile: 'int k = 0\nwhile k >= 0\n    k += 1\nplot(k)\n',
      honest: 'plot(ta.sma(close, 20))\n',
    }
    const rows = BARS.map((b, i) => ({ t: 1136160000 + i * 86400, o: b.o, h: b.h, l: b.l, c: b.c, v: b.v }))
    const out = {}
    for (const [k, src] of Object.entries(cases)) {
      const t0 = performance.now()
      let guard = null
      try {
        computeRuntimeColumns({ id: `b_${k}`, compute: { fn: `b_${k}`, source: head + src, outputs: { v: 0 } } }, rows, { tf: 'D' }, { budgetMs: 1000, incremental: false })
      } catch (e) { guard = `${e && e.guard} :: ${String(e && e.message).slice(0, 120)}` }
      out[k] = { ms: +(performance.now() - t0).toFixed(1), stoppedBy: guard }
    }
    console.log(JSON.stringify({ bench: 'runtime-limits', bars: N, ...out }))
    expect(out.runawayWhile.stoppedBy).not.toBeNull()
  })
})
