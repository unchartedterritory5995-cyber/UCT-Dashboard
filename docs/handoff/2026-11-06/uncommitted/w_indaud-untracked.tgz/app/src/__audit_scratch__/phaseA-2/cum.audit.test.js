// PA-2 scratch (NOT committed): both doors on history-dependent constructs.
import { it, vi } from 'vitest'
import { inspectSource } from '../../components/chart/builder/PineBox.jsx'
import { memberPaneDefinition } from '../../components/chart/builder/memberPane/memberPaneDefinition.js'
import { requirementNote } from '../../components/chart/engine/ast/parse.js'

const L = String.fromCharCode(10)
const v5 = (body) => ['//@version=5', 'indicator("p")', ...body].join(L)
const CASES = [
  ['ta.cum(volume)', v5(['plot(ta.cum(volume), "C")'])],
  ['ta.cum(1)', v5(['plot(ta.cum(1), "C")'])],
  ['obv-style', v5(['plot(ta.cum(math.sign(ta.change(close)) * volume), "OBV")'])],
  ['cum diff', v5(['c = ta.cum(volume)', 'plot(c - c[10], "D")'])],
  ['cum ema', v5(['c = ta.cum(volume)', 'plot(c - ta.ema(c, 20), "D")'])],
  ['v4 bare cum', ['//@version=4', 'study("p")', 'plot(cum(sign(change(close)) * volume), "OBV")'].join(L)],
  ['v3 bare cum', ['//@version=3', 'study("p")', 'plot(cum(volume))'].join(L)],
  ['cum + alertcondition', v5(['c = ta.cum(volume)', 'plot(c, "C")', 'alertcondition(c > 0, "pos")'])],
  ['bar_index', v5(['plot(bar_index, "B")'])],
  ['var counter', v5(['var c = 0', 'c += 1', 'plot(c, "C")'])],
  ['barstate.isfirst', v5(['plot(barstate.isfirst ? 1 : 0, "F")'])],
  ['barssince', v5(['plot(ta.barssince(close > open), "B")'])],
  ['valuewhen occ0', v5(['plot(ta.valuewhen(ta.crossover(close, ta.sma(close, 20)), close, 0), "V")'])],
  ['valuewhen occ1', v5(['plot(ta.valuewhen(ta.crossover(close, ta.sma(close, 20)), close, 1), "V")'])],
  ['strategy', ['//@version=5', 'strategy("s")', 'f = ta.ema(close, 10)', 'plot(f, "F")', 'if ta.crossover(close, f)', '    strategy.entry("L", strategy.long)'].join(L)],
]

it('cum and history-dependent constructs through both doors', () => {
  vi.stubEnv('VITE_PINE_MEMBER_PANE_ENABLED', '1')
  vi.stubEnv('VITE_PINE_OBJECTS_ONLY_PANE_ENABLED', '1')
  vi.stubEnv('VITE_PINE_RUNTIME_PANE_ENABLED', '0')
  const rows = []
  for (const [id, src] of CASES) {
    const box = inspectSource(src, 'auto')
    const p = memberPaneDefinition({ source: src, id: 'u_member-pane-pa2' })
    const meta = (p.definition && p.definition.meta) || {}
    rows.push({
      id,
      box: box.outcome.verdict,
      boxReason: String(box.outcome.reason || '').slice(0, 90),
      boxIgnoredCodes: (box.ignored || []).map((n) => n.code),
      boxRefusalGuard: (box.refusal && box.refusal.guard) || ((box.outputs || []).find((o) => o.refusal) || {}).refusal?.guard || null,
      pane: p.ok,
      paneGuard: p.guard,
      paneReason: p.ok ? null : String(p.reason || '').slice(0, 90),
      hostNoteCodes: ((p.translation && p.translation.notes) || []).map((n) => n.code),
      paneNotes: (p.notes || []).length,
      disclosures: (meta.disclosures || []).length,
      requirementTags: p.requirementTags || [],
      metaTags: meta.requirementTags || [],
      formula: p.definition ? String((p.definition.compute && p.definition.compute.source) || '').slice(0, 60) : null,
      repaint: meta.repaint || null,
      recurrenceOrigin: meta.recurrenceOrigin || null,
    })
  }
  console.log('PA2CUM ' + JSON.stringify(rows, null, 1))
  console.log('BADGE ' + JSON.stringify(requirementNote('window_dependent', 5000)))
})
