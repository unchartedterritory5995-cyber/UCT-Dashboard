// app/src/components/chart/engine/__tests__/vendorHarness/uieRuntimeAcceptance.measure.test.js
//
// ⭐⭐ UIE PHASE B (2026-10-11) — RUNTIME ACCEPTANCE: grade the six runtime-only scripts
// of `docs/pine/runtime-pane-switch-on-plan.md` against EVERY TradingView capture
// committed for them, with the runtime pane switched on IN THIS TEST ONLY (`vi.stubEnv`,
// the pattern every runtime measure in this directory uses). Nothing is enabled anywhere
// else and no pinned verdict file is rewritten: it PRINTS the harness's own verdicts.
//
// ⛔ OPT-IN (UIE_RUNTIME_ACCEPTANCE=1), like every *.measure test here:
//   cd app && UIE_RUNTIME_ACCEPTANCE=1 node node_modules/vitest/vitest.mjs run --maxWorkers=1 \
//     src/components/chart/engine/__tests__/vendorHarness/uieRuntimeAcceptance.measure.test.js
import { it, vi, expect } from 'vitest'
import fs from 'node:fs'
import path from 'node:path'
import { gradeCapture, loadCapture, HARNESS_DIR } from './harness'
import { cap3Signature } from './cap3Signature'

const SCRIPTS = [
  'adx-and-di-for-v4', 'inside-bar-range-mother-candle', 'delta-rsi-oscillator-strategy',
  'fibonacci-dolphintradebot', 'trend-targets-algoalpha', 'wyckoff-accumulation-distribution',
]

it.skipIf(!process.env.UIE_RUNTIME_ACCEPTANCE)('grades every capture of the six runtime-only scripts, runtime pane on', () => {
  const files = fs.readdirSync(HARNESS_DIR).filter((f) => f.endsWith('.json') && SCRIPTS.some((s) => f.startsWith(s))).sort()
  expect(files.length).toBeGreaterThanOrEqual(SCRIPTS.length)
  const rows = []
  for (const f of files) {
    vi.stubEnv('VITE_PINE_OBJECTS_ONLY_PANE_ENABLED', '1')
    vi.stubEnv('VITE_PINE_RUNTIME_PANE_ENABLED', '1')
    const loaded = loadCapture(path.join(HARNESS_DIR, f))
    if (!loaded.capture) { rows.push({ id: f, verdict: 'NOT-A-CAPTURE', reason: loaded.reason }); vi.unstubAllEnvs(); continue }
    const t0 = Date.now()
    let sig
    try { sig = cap3Signature(gradeCapture(loaded.capture).verdict) } catch (e) { sig = { verdict: 'ERROR', reason: String(e && e.message).slice(0, 200) } }
    rows.push({ id: f.replace(/\.json$/, ''), ms: Date.now() - t0, ...sig })
    vi.unstubAllEnvs()
  }
  console.log(`UIE_ACCEPTANCE ${JSON.stringify(rows)}`)
}, 3600000)
